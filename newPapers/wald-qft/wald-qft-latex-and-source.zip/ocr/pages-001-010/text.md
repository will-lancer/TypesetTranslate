

{0}------------------------------------------------

## Chicago Lectures in Physics

Robert M. Wald, Editor Henry J. Frisch Gene F. Mazenko Sidney R. Nagel

{1}------------------------------------------------

# Quantum Field Theory in Curved Spacetime and Black Hole Thermodynamics

Robert M. Wald

The University of Chicago Press Chicago and London 

{2}------------------------------------------------

The University of Chicago Press, Chicago 60637
The University of Chicago Press, Ltd., London
© 1994 by The University of Chicago
All rights reserved. Published 1994
Printed in the United States of America
03 02 01 00 99 98 97 96 95 94 1 2 3 4 5

ISBN: 0-226-87025-1 (cloth) 0-226-87027-8 (paper)

Library of Congress Cataloging-in-Publication Data Wald. Robert M.

Quantum field theory in curved spacetime and black hole thermodynamics / Robert M. Wald.

- p. cm. -- (Chicago lectures in physics) Includes bibliographical references and index.
- 1. Quantum field theory. 2. Black holes (Astronomy)
- 3. Gravitational fields. 4. Space and time. 5. Thermodynamics.

I. Title. II. Series.

OC174.45.W35 1994

530.1'43--dc20

94-11065

CIP

The paper used in this publication meets the minimum requirements of the American National Standard for Information Sciences—Permanence of Paper for Printed Library Materials, ANSI Z39.48-1984.

{3}------------------------------------------------

To Barbara, Sarah, and Kristina

{4}------------------------------------------------

{5}------------------------------------------------

## **Contents**

5.2 Killing Horizons 118

5.3 The Unruh Effect in Curved Spacetimes 123

| Preface ix                                                        |
|-------------------------------------------------------------------|
| Notation, Conventions, and Terminology xii                        |
| Introduction and Overview 1                                       |
| 1.1 The Formulation of Quantum Field Theory in Curved Spacetime   |
| 1.2 Classical Black Hole Thermodynamics 6                         |
| 1.3 The Hawking Effect and Its Ramifications 8                    |
| Quantum Mechanical Preliminaries 10                               |
| 2.1 Classical Dynamics of Particle Systems 10                     |
| 2.2 Quantum Mechanics 17                                          |
| 2.3 Harmonic Oscillators 21                                       |
| Quantum Fields in Flat Spacetime 31                               |
| 3.1 Basic Construction 31                                         |
| 3.2 Reformulation 35                                              |
| 3.3 Particle Interpretation 46                                    |
| Quantum Fields in Curved Spacetime 53                             |
| 4.1 Curved Spacetimes; Global Hyperbolicity 54                    |
| 4.2 Construction of Quantum Field Theory in a Curved Spacetime 57 |
| 4.3 Quantum Field Theory in Stationary Spacetimes 61              |
| 4.4 Unitary Equivalence; the S-Matrix 66                          |
| 4.5 The Algebraic Approach 73                                     |
| 4.6 The Stress-Energy Tensor 85                                   |
| 4.7 Other Linear Fields 100                                       |
| The Unruh Effect 105                                              |
| 5.1 The Unruh Effect in Flat Spacetime 106                        |

{6}------------------------------------------------

#### viii CONTENTS

- 6 Classical Black Hole Thermodynamics 133
  - 6.1 Classical Black Holes and the Area Theorem 133
  - 6.2 The Laws of Black Hole Mechanics 139
- 7 The Hawking Effect 151
  - 7.1 Particle Creation by Black Holes 152
  - 7.2 The Generalized Second Law 163
  - 7.3 Evaporation of Black Holes and Loss of Quantum Coherence 175

Appendix: Some Basic Definitions and Constructions Pertaining to Hilbert Spaces 188

- A.1 Some Basic Definitions 188
- A.2 Some Basic Constructions 190
- A.3 Index Notation 192

References 195 Notation Index 201 General Index 203

{7}------------------------------------------------

#### **Preface**

The subject of quantum field theory in curved spacetime is the study of the behavior of quantum fields propagating in a classical gravitational field. It is used to analyze phenomena where the quantum nature of fields and the effects of gravitation are both important, but where the quantum nature of gravity itself is assumed not to play a crucial role, so that gravitation can be described by a classical, curved spacetime, as in the framework of general relativity. Its two applications of greatest interest are to phenomena occurring in the very early universe and to phenomena occurring in the vicinity of black holes. During the past twenty-five years such phenomena have been explored theoretically, and some unexpected and intriguing results have been obtained. Most prominent among these was the discovery by Hawking that particle creation occurs in the vicinity of black holes. As a direct consequence, a deep connection was obtained between the laws of black hole physics and the ordinary laws of thermodynamics. The Hawking effect and its implications are probably the most valuable clues we have, at present, as to the fundamental features that a quantum theory of gravity is likely to possess.

A student or researcher wishing to learn these developments faces a number of impediments. In my view, the most serious among these is the fact that the standard treatments of quantum field theory in flat spacetime rely heavily on Poincaré symmetry (usually entering the analysis implicitly via plane-wave expansions) and interpret the theory primarily in terms of a notion of "particles". Neither Poincaré (or other) symmetry nor a useful notion of "particles" exists in a general, curved spacetime, so a number of the familiar tools and concepts of field theory must be "unlearned" in order to have a clear grasp of quantum field theory in curved spacetime.

One of the main goals of these lecture notes is to provide a coherent, pedagogical introduction to the formulation of quantum field theory in curved spacetime. We begin with a treatment of the ordi

{8}------------------------------------------------

nary, one-dimensional, quantum harmonic oscillator and logically progress, through the construction of quantum field theory in flat spacetime, to the possible constructions of quantum field theory in curved spacetime, and, ultimately, to the algebraic formulation of the theory. It is my hope that this presentation will help disentangle the essential features of the theory from some inessential ones (such as a particle interpretation), and that it will help clarify the relationships between the various different approaches that have been taken toward the formulation of the theory.

The other main goal of these lecture notes is to provide a comprehensive, up-to-date account of the Unruh effect, the Hawking effect, and some of the ramifications of the Hawking effect, particularly with regard to black hole thermodynamics. Although the key results on these topics were obtained in the 1970's, they remain an active area of current research.

The reader should be made aware that it has *not* been my goal to present a balanced, comprehensive review of all research on quantum field theory in curved spacetime. In particular, it should be noted that, with the exception of some brief discussion of quantum field effects in deSitter spacetime (see section 5.3), there is very little discussion relating to the applications of the theory to cosmology.

In writing these notes, I have assumed that the reader has a knowledge of classical general relativity comparable to the level of a one-term, graduate, introductory course. This amounts to assuming that the reader is comfortable with the notion of spacetime as a manifold together with a Lorentz signature metric, and is familiar with such concepts as tensor fields, covariant derivatives, and geodesics. An introduction to the needed "advanced topics" of global hyperbolicity, Killing horizons, and black holes is given in these notes in a basically self-contained manner.

I also have assumed that the reader has a knowledge of quantum field theory comparable to the level of an introductory graduate course. In principle, only a basic knowledge of ordinary quantum mechanics actually should be necessary, since quantum field theory in flat spacetime is developed *ab initio* in these notes. Indeed, for some of the discussion, it may be more useful for the reader *not* to have had a prior knowledge of standard presentations of quantum field theory. However, readers who are entirely unfamiliar with concepts

{9}------------------------------------------------

such as Fock space, annihilation and creation operators, etc., may have a relatively difficult time reading portions of these notes.

I wish to thank Steve Fulling and Ted Jacobson for reading the entire manuscript with great care, and making many valuable suggestions for improvements. Similar thanks are due Rainier Verch for reading chapter 4, and I also wish to thank Bernard Kay for a number of helpful comments. I am greatly indebted to Miles Blencowe for carefully proofreading the entire manuscript and suggesting some improvements in the exposition. Chapters 2, 3, and 4 of these notes as well as parts of chapters 5 and 7 correspond closely to my lectures presented at the 1992 Les Houches School on Gravitation and Quantization. I wish to thank Elsevier Science Publishers for waiving any time restrictions on my use of this material from my Les Houches lectures. Support from NSF grant PHY-9220644 to the University of Chicago also is gratefully acknowledged.