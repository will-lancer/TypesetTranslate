

{40}------------------------------------------------

It is not difficult to check that there are many choices of subspace,  $\Re$ , which satisfy these three properties.

These properties imply that every  $z \in \mathcal{A}^{\mathbb{C}}$  can be uniquely expressed as  $z = z^+ + z^-$ , with  $z^+ \in \mathcal{H}$ ,  $z^- \in \overline{\mathcal{H}}$ . Hence, given a choice of  $\mathcal{H}$  satisfying these properties, we again obtain a real-linear, one-to-one, onto map  $K: \mathcal{A} \to \mathcal{H}$ , defined for all  $y \in \mathcal{A}$  by  $Ky = y^+$ . We note that for all  $y_1, y_2 \in \mathcal{A}$ , we have

$$\begin{split} \text{Im}(\mathsf{K} \mathsf{y}_1, \ \mathsf{K} \mathsf{y}_2)_{\Re} &= - \, \mathsf{Re} \{ \Omega(\overline{\mathsf{K}} \mathsf{y}_1, \ \mathsf{K} \mathsf{y}_2) \} \\ &= - \, \frac{1}{2} \, \Omega(\overline{\mathsf{K}} \mathsf{y}_1, \ \mathsf{K} \mathsf{y}_2) - \frac{1}{2} \, \Omega(\mathsf{K} \mathsf{y}_1, \ \overline{\mathsf{K}} \mathsf{y}_2) \\ &= - \, \frac{1}{2} \, \Omega(\mathsf{y}_1, \ \mathsf{y}_2) \end{split} \tag{2.3.22}$$

where in the last step we used condition (iii) together with the fact that for all  $y \in \mathcal{S}$ , we have  $y = Ky + \overline{Ky}$ .

To define the quantum theory, we choose the Hilbert space to be  $\mathcal{F}_s(\mathfrak{R})$ . In analogy with eq. (2.3.21), for each  $y \in \mathcal{S}$  we define the quantum Heisenberg observable at time t corresponding to  $\Omega(y, \cdot)$  to be

$$\widehat{\Omega}_{H}(y,\cdot) = ia(\overline{Ky_t}) - ia^{\dagger}(Ky_t)$$
 (2.3.23)

This construction defines a quantum theory of a general linear dynamical system. However, the construction has the potentially unsatisfactory feature that it appears to depend on our choice of \$\mathbb{K}\$, and—as already noted above—in the absence of time translation symmetry, no natural, "preferred" choice of % is available. Fortunately, this turns out not to be a difficulty for the case considered here of a system with finitely many degrees of freedom: the Stone-von Neumann theorem together with the dynamical behavior (2.3.23) of the Heisenberg operators, it follows that for any choice of  $\Re$  satisfying (i)-(iii) above— $(\Im_s(\Re); \widehat{\Omega}_H(\mathsf{y},\cdot))$  is unitarily equivalent to the standard tensor product construction of the quantum theory. Thus, in particular, for any two subspaces, % and %', of  $\mathcal{S}^{\mathfrak{C}}$ , satisfying (i)-(iii), the theories  $(\mathfrak{F}_{s}(\mathfrak{K}); \widehat{\Omega}_{H}(y,\cdot))$  and  $(\mathfrak{F}_{s}(\mathfrak{K}');$  $\hat{\Omega}'_{H}(y,\cdot)$ ) are unitarily equivalent. Indeed, a direct proof of this unitary equivalence will follow from the analysis we shall give in section 4.4 below.

Thus, we obtain a fully satisfactory alternate construction of

{41}------------------------------------------------

the quantum theory of a linear dynamical system (with finitely many degrees of freedom) possessing a time-dependent Hamiltonian. However, it is worth noting here that—as we shall see explicitly in section 4.4—the situation changes dramatically when & is infinite dimensional, since in that case different choices of % will, in general, yield unitarily inequivalent theories. This poses a potential serious difficulty for the formulation of quantum field theory in curved spacetime. As we shall see in section 4.5 this difficulty can be resolved by formulating the theory via the algebraic approach.

It is worth pointing out that even in the case of n decoupled, time-independent oscillators, we also are free to make a choice,  $\mathfrak{K}'$ , of subspace of  $\mathfrak{S}^{\mathfrak{T}}$  (satisfying (i)-(iii)) different from the standard choice,  $\mathfrak{K}$ , of positive frequency solutions. The Hamiltonian on  $\mathfrak{T}'=\mathfrak{T}_s(\mathfrak{K}')$  then will no longer have the simple form (2.3.5) in terms of annihilation and creation operators on  $\mathfrak{T}_s(\mathfrak{K}')$ —it will also have "aa" and "a†a†" terms—and the "vacuum state"  $|0>^{!}\in\mathfrak{T}_s(\mathfrak{K}')$  will not be an eigenstate of the Hamiltonian. Nevertheless,  $|0>^{!}$  will possess all of the "kinematical properties" of a ground state. In the literature on atomic physics and optics, a state of the form  $|0>^{!}$  usually is referred to as a *squeezed vacuum state*. As a by-product of the analysis given in section 4.4 below (see eq. (4.4.23)), we will obtain an explicit expression for  $|0>^{!}$  as a state in the standard Hilbert space  $\mathfrak{F}_s(\mathfrak{K})$ .

Finally, we point out a useful way of characterizing the freedom available in the choice of  $\Re$ . First, we note that a specification of a complex subspace,  $\Re$ , of  $\mathscr{A}^{\mathbb{C}}$  satisfying (i)-(iii) allows us to obtain a real inner product  $\mu: \mathscr{A} \times \mathscr{A} \to \mathbb{R}$  on the original ("uncomplexified") vector space of real solutions as follows: For  $y_1, y_2 \in \mathscr{A}$ , we define

$$\mu(y_1, y_2) = \text{Re}(Ky_1, Ky_2)_{\Re}$$

$$= \text{Im } \Omega(\overline{Ky}_1, Ky_2) \qquad (2.3.24)$$

where K:  $\&\to \Re$  denotes the "projection map" onto  $\Re$ . Note that by eq. (2.3.22), we have for all  $y_1,y_2\in \&$ ,

$$(Ky_1, Ky_2)_{\Re} = \mu(y_1, y_2) - \frac{i}{2} \Omega(y_1, y_2)$$
 (2.3.25)

Now, by the Schwarz inequality, for all  $z_1, z_2 \in \mathcal{K}$  we have

{42}------------------------------------------------

$$||z_1||^2 ||z_2||^2 \ge |(z_1, z_2)|^2 \ge |Im(z_1, z_2)|^2$$
 (2.3.26)

Hence, writing  $z_1=Ky_1$ ,  $z_2=Ky_2$ , we find that  $\mu$  must satisfy

$$\mu(y_1, y_1) \ \mu(y_2, y_2) \ge \frac{1}{4} [\Omega(y_1, y_2)]^2$$
 (2.3.27)

for all  $y_1,y_2 \in \mathcal{S}$ . Indeed, since K is one-to-one and onto and since the Schwarz inequality (2.3.26) on  $\mathfrak{R}$  always can be "saturated", we obtain the following stronger version of eq. (2.3.27): For each  $y_1 \in \mathcal{S}$  we have

$$\mu(y_1, y_1) = \frac{1}{4} \max_{y_2 \neq 0} \frac{[\Omega(y_1, y_2)]^2}{\mu(y_2, y_2)}$$
 (2.3.28)

Note that  $\mu$  appears on both sides of eq. (2.3.28), and this equation provides a condition on  $\mu$  which does not determine  $\mu$  uniquely.

Conversely, suppose we are given a positive-definite, symmetric, bilinear map  $\mu: A \times A \to \mathbb{R}$  satisfying eq. (2.3.28). Then, for each  $y_1 \in A$ , there exists a unique  $y_2 \in A$  such that

$$\frac{1}{2}\Omega(y_1,y_2) = \mu(y_1,y_1) \tag{2.3.29}$$

and

$$\mu(y_2, y_2) = \mu(y_1, y_1)$$
 (2.3.30)

(Uniqueness of  $y_2$  follows from the fact that if  $y_2' \neq y_2$  also satisfied eqs. (2.3.29) and (2.3.30), then linear combinations of  $y_2$  and  $y_2'$  would violate eq. (2.3.28).) The association

$$y_1 \rightarrow \frac{1}{2} (y_1 + iy_2)$$
 (2.3.31)

then maps & onto an n-complex-dimensional subspace,  $\Re$ , of  $\&^{\mathbb{C}}$ . It is not difficult to show that  $\Re$  satisfies properties (i)-(iii) (see the discussion following eq. (3.2.16) below). Furthermore, this choice of  $\Re$  reproduces the given  $\mu$  via eq. (2.3.24). Thus, we see that a specification of  $\Re$  satisfying properties (i)-(iii) is completely equivalent to a specification of real inner product,  $\mu$ , on & satisfying eq. (2.3.28). As we shall see, in the field theory case there are significant technical advantages to specifying the quantum theory via a choice of  $\mu$  rather than via a choice of  $\Re$ .

{43}------------------------------------------------

## 3 Quantum Fields in Flat Spacetime

This chapter constructs the quantum theory of a free (i.e., linear) Klein-Gordon field in Minkowski spacetime. Section 3.1 presents the construction in a manner that corresponds closely to what is found in standard textbook treatments. This approach relies heavily upon a "plane wave expansion", in which the field assumes the explicit form of an infinite system of decoupled, time-independent, harmonic oscillators. Section 3.2 reformulates this construction without using a plane wave expansion, thereby enabling us to distinguish clearly between the essential input in the construction (namely, the choice of the subspace of "positive frequency solutions" to the Klein-Gordon equation) and inessential input (namely, the choice of a particular basis for these positive frequency solutions). A generalization of this construction which allows one to make more general choices of a subspace of (complex) solutions to the Klein-Gordon equation then will be presented. Since no analog of either a plane wave basis or a choice of "positive frequency subspace" is available in a general curved spacetime, this reformulation is of crucial importance for the construction of quantum field theory in curved spacetime given in the next chapter. Indeed, the reformulation given in section 3.2 comprises most of the "hard work" related to the construction of quantum field theory in curved spacetime. The chapter concludes in section 3.3 with an analysis showing how a particle interpretation can be given to the states of the Klein-Gordon field in Minkowski spacetime. This analysis generalizes straightforwardly to stationary, curved spacetimes (see section 4.3), but in a general, nonstationary spacetime, the states of the quantum field typically will not possess a physically meaningful particle interpretation, except in an approximate or asymptotic sense.

## 3.1 Basic Construction

In this section, we shall construct the quantum theory of a real, linear (i.e., non-self-interacting) Klein-Gordon field in

{44}------------------------------------------------

Minkowski spacetime. We shall do so by "putting the field in a box", noting that its normal modes comprise an infinite system of decoupled harmonic oscillators, and then applying an appropriate version of the construction of the previous chapter.

The action of the Klein-Gordon field in Minkowski spacetime is

$$S = -\frac{1}{2} \int (\partial_a \phi \ \partial^a \phi \ + \ m^2 \phi^2) \ d^4 x \eqno(3.1.1)$$

The classical equations of motion arising from S are

$$\partial^{a}\partial_{a}\phi - m^{2}\phi = 0 \tag{3.1.2}$$

By introducing a global inertial coordinate system, we can re-write eq. (3.1.1) as

$$S = \int \mathcal{Z} dt \qquad (3.1.3)$$

with

$$\mathfrak{Z} = \frac{1}{2} \int [\dot{\phi}^2 - (\overrightarrow{\nabla}\phi)^2 - m^2\phi^2] d^3x \qquad (3.1.4)$$

where the dot denotes a time derivative.

In order to simplify the technical details of the initial discussion, we now (provisionally) replace the infinite Euclidean space,  $\mathbb{R}^3$ , by a flat 3-torus,  $\mathsf{T}^3$ , of side L, i.e., we "put the field in a box with periodic boundary conditions." A reformulation of this construction without using this artifice will be given in the next section. We then expand  $\phi$  in a Fourier series,

$$\phi(t,\mathbf{x}) = L^{-3/2} \sum_{\mathbf{k}} \phi_{\mathbf{k}}(t) \exp(i\mathbf{k} \cdot \mathbf{x})$$
 (3.1.5)

where the vector k is of the form

$$\mathbf{k} = \frac{2\pi}{L} (n_1, n_2, n_3)$$
 (3.1.6)

with  $n_1$ ,  $n_2$ ,  $n_3$  integers, and where, in this section, boldface letters will indicate (three-dimensional) spatial vectors. The coefficients  $\phi_{\bf k}(t)$  are given in terms of  $\phi$  by

$$\phi_{\mathbf{k}}(t) = L^{-3/2} \int \phi(t, \mathbf{x}) \exp(-i\mathbf{k} \cdot \mathbf{x}) d^3x$$
 (3.1.7)

{45}------------------------------------------------

The reality of \$\phi\$ implies that

$$\overline{\phi}_{\mathbf{k}} = \phi_{-\mathbf{k}} \tag{3.1.8}$$

The Lagrangian, I, then can be expressed as

$$\mathfrak{X} = \sum_{\mathbf{k}} \left\{ \frac{1}{2} |\dot{\phi}_{\mathbf{k}}|^2 - \frac{1}{2} \omega_{\mathbf{k}}^2 |\phi_{\mathbf{k}}|^2 \right\}$$
 (3.1.9)

where

$$\omega_{\mathbf{k}^2} = \mathbf{k}^2 + m^2 \tag{3.1.10}$$

Comparing eq. (3.1.9) with eq. (2.3.1), we see that the Klein-Gordon field may be viewed as an infinite collection of decoupled, time-independent, harmonic oscillators. More precisely,  $\sqrt{2}$  Re  $(\phi_{\mathbf{k}})$  and  $\sqrt{2}$  Im  $(\phi_{\mathbf{k}})$  are the "position observables" for a countably infinite set of independent, real harmonic oscillators. (Here the factor of  $\sqrt{2}$  arises from the fact that the oscillator labeled by  $\mathbf{k}$  is the same oscillator as the one labeled by  $-\mathbf{k}$  on account of eq. (3.1.8), so the sum over all  $\mathbf{k}$  in eq. (3.1.9) double-counts the oscillators.) Thus, in order to construct the quantum field theory of the free Klein-Gordon scalar field, we simply need to generalize the construction of the previous chapter for finitely many decoupled, time independent oscillators to the case of a countably infinite number of oscillators.

In the previous chapter, we gave two equivalent prescriptions for constructing the Hilbert space for the quantum theory of finitely many oscillators: (1) Take the tensor product space of the Hilbert spaces for the individual oscillators. (2) Construct a Fock space based upon a Hilbert space of (complex) classical solutions. In the present case of infinitely many oscillators, this first prescription is no longer available. Although the tensor product of infinitely many Hilbert spaces can be defined (von Neumann 1938), it is "too large" to be suitable for use in a (normal type of) quantum theory in that it is not separable and the representation it provides of the canonical commutation relations is reducible.

On the other hand, the second prescription generalizes straightforwardly to the present case. We define  $\Re$  to be the Hilbert space of positive frequency solutions to the Klein-Gordon equation (3.1.2), with inner product defined by eq. (2.3.16). In the next section, we shall state more precisely and generally how  $\Re$  is constructed, but in the present context (where "space" is  $T^3$ ), it suffices to say that an orthonormal basis of  $\Re$  is provided by "plane-

{46}------------------------------------------------

wave" solutions of the form

$$\psi_{\mathbf{k}} = \frac{\exp(i\mathbf{k} \cdot \mathbf{x} - i\omega_{\mathbf{k}}t)}{(2\omega_{\mathbf{k}})^{1/2}L^{3/2}}$$
(3.1.11)

with **k** given by eq. (3.1.6) and  $\omega_{\mathbf{k}} > 0$  given by eq. (3.1.10).

We choose the Hilbert space,  $\mathfrak{F}$ , to be  $\mathfrak{F}_s(\mathfrak{K})$ . (The fact that  $\mathfrak{K}$  is now infinite dimensional poses no problem for the definition of  $\mathfrak{F}_s(\mathfrak{K})$ ; see Appendix A.2 for further discussion of the Fock space construction.) Let  $b_k$  and  $c_k$  denote, respectively, the annihilation operators associated with the normalized positive frequency solutions corresponding to excitations of the oscillators  $\sqrt{2}$  Re  $(\phi_k)$  and  $\sqrt{2}$  Im  $(\phi_k)$ , respectively. (By the reality condition (3.1.8),  $b_k$  and  $c_k$  are not independent of  $b_{-k}$  and  $c_{-k}$ ; indeed, we have  $b_{-k} = b_k$ ,  $c_{-k} = -c_k$ .) The "position observables" of the theory are then represented in the Schrodinger picture by the operators

$$\sqrt{2} \operatorname{Re} \phi_{\mathbf{k}} = \frac{1}{\sqrt{2\omega_{\mathbf{k}}}} (b_{\mathbf{k}} + b_{\mathbf{k}}^{\dagger})$$
 (3.1.12)

$$\sqrt{2} \text{ Im } \phi_{\mathbf{k}} = \frac{1}{\sqrt{2\omega_{\mathbf{k}}}} (c_{\mathbf{k}} + c_{\mathbf{k}}^{\dagger})$$
 (3.1.13)

Analogs of eqs. (2.3.18) and (2.3.19) then hold for the Heisenberg position and momentum operators. This specifies the key observables—namely, "position", "momentum", and the Hamiltonian up to a multiple of the identity operator—of the quantum field theory. It should be emphasized that there are no mathematical difficulties whatsoever at this stage of the construction.

It is convenient to define the operator  $a_k$  by

$$a_{\mathbf{k}} = \frac{1}{\sqrt{2}} (b_{\mathbf{k}} + ic_{\mathbf{k}})$$
 (3.1.14)

Then  $a_{\mathbf{k}}$  and  $a_{-\mathbf{k}}$  can be viewed as independent, and we have (for all  $\mathbf{k}$  of the form (3.1.6))

$$[a_{\mathbf{k}}, a_{\mathbf{k}'}] = 0, [a_{\mathbf{k}}, a_{\mathbf{k}'}] = \delta_{\mathbf{k}\mathbf{k}'} I$$
 (3.1.15)

It follows directly from eqs. (3.1.12)-(3.1.14) that the Schrodinger picture observable  $\hat{\phi}_{\mathbf{k}}$  corresponding to the classical complex ob-

{47}------------------------------------------------

servable  $\phi_{\mathbf{k}}$  defined by eq. (3.1.7) is given by

$$\hat{\phi}_{\mathbf{k}} = \frac{1}{\sqrt{2\omega_{\mathbf{k}}}} (a_{\mathbf{k}} + a_{-\mathbf{k}}^{\dagger})$$
 (3.1.16)

Equations (3.1.5) and (3.1.16) now yield the following formal expression for a (Schrodinger picture) operator  $\hat{\phi}(\mathbf{x})$  representing the value of the field at spatial point  $\mathbf{x}$ :

$$\begin{split} \widehat{\phi}\left(\boldsymbol{x}\right) &= L^{-3/2} \sum_{\boldsymbol{k}} \exp\left(i\,\boldsymbol{k}\cdot\boldsymbol{x}\right) \, \widehat{\phi}_{\boldsymbol{k}} \\ &= \sum_{\boldsymbol{k}} \left\{ \frac{\exp\left(i\,\boldsymbol{k}\cdot\boldsymbol{x}\right)}{\left(2\,\omega_{\,\boldsymbol{k}}\right)^{1/2}L^{\,3/2}} \, a_{\boldsymbol{k}} + \frac{\exp\left(-i\,\boldsymbol{k}\cdot\boldsymbol{x}\right)}{\left(2\,\omega_{\,\boldsymbol{k}}\right)^{1/2}L^{\,3/2}} a_{\boldsymbol{k}} \, ^{\dagger} \right\} \quad (3.1.17) \end{split}$$

The corresponding Heisenberg operator  $\hat{\phi}(t; \mathbf{x})$  is given by

$$\hat{\phi}(t; \mathbf{x}) = \sum_{k} \{ \frac{\exp(i\mathbf{k} \cdot \mathbf{x} - i\omega_{k}t)}{(2\omega_{k})^{1/2} L^{3/2}} a_{k} + \text{h.c.} \}$$
 (3.1.18)

where "h.c." denotes "hermitian conjugate", i.e., the adjoint of the preceding operator. Note that eq. (3.1.18) has the form

$$\widehat{\phi}(t; \mathbf{x}) = \sum_{i} \{ \psi_{i}(t, \mathbf{x}) \ a_{i} + \overline{\psi}_{i}(t, \mathbf{x}) \ a_{i}^{\dagger} \}$$
 (3.1.19)

where  $\{\psi_i\}$  is the orthonormal basis (3.1.11) of  $\Re$ , and  $a_i$  is the annihilation operator associated with  $\psi_i$ . However, although all of the steps preceding eq. (3.1.17) are mathematically well defined, the infinite sums appearing in eqs. (3.1.17)-(3.1.19) do not converge, and the theory actually does not admit an observable corresponding to the value of the field at spacetime point  $(t, \mathbf{x})$ . Nevertheless, as we shall see at the end of the next section, a well defined expression can be given for the quantum field as an operator-valued distribution, which formally corresponds to eq. (3.1.19).

## 3.2 Reformulation

In the previous section, we constructed a quantum theory of a real Klein-Gordon scalar field by using a plane wave basis of solutions to explicitly express the field as a collection of decoupled, 

{48}------------------------------------------------

time-independent harmonic oscillators. In this section we shall reformulate this construction in a manner that does not rely upon having such a plane wave basis. As already mentioned above, this reformulation is essential for generalizing the construction to curved spacetime, where no analog of such a plane wave basis is available in general. (Indeed, such a reformulation also is needed to make the construction rigorous in flat spacetime when we do not "put the field in a box", since plane waves in  $\mathbb{R}^3$  are not normalizable.) We then shall define (distributional) field observables in the theory corresponding to eq. (3.1.19).

To begin, we must define more precisely the classical phase space,  $\mathfrak{M}$ , and solution space,  $\mathfrak{B}$ , of the Klein-Gordon field. From the Lagrangian density (3.1.4), we see that the momentum density,  $\pi$ , of the Klein-Gordon field on the three-dimensional hypersurface,  $\Sigma_0$ , corresponding to global inertial time t=0 is given by

$$\pi = \frac{\delta S}{\delta \dot{\phi}} = \dot{\phi} \tag{3.2.1}$$

Thus, a point in phase space corresponds to a specification of the pair of functions  $\varphi(x)$  and  $\pi(x)$  on  $\Sigma_0$ . However, in order to define  $\mathfrak{M}$  precisely, we must specify precisely what class of functions are permitted. This is largely at our discretion, limited only by the following considerations: We need a sufficiently "nice" class of functions in order that mathematical structures such as the symplectic form (see below) are well defined. However, the choice of functions cannot be so restrictive that the local degrees of freedom of the system are inhibited. The class of functions comprised by "Schwartz space" (see, e.g., Reed and Simon (1980)) meets these criteria and is most commonly chosen for quantum field theory in Minkowski spacetime. However, the notion of Schwartz space does not generalize to a general, curved spacetime. Hence, we shall define  $\mathfrak{M}$  to consist of initial data which are smooth and of compact support on  $\Sigma_0$ , i.e.,

$$\mathfrak{M} \equiv \{ [\phi, \pi] \mid \phi: \Sigma_0 \to \mathbb{R}, \ \pi: \Sigma_0 \to \mathbb{R}; \ \phi, \pi \in C_0^{\infty}(\Sigma_0) \}$$
 (3.2.2)

By the well posedness of the initial value formulation for eq. (3.1.2) (see section 4.1 below), it follows that every point of  $\mathfrak{M}$  uniquely determines a solution to the Klein-Gordon equation. We define & to

{49}------------------------------------------------

be the space of solutions which arise from initial data in  $\mathfrak M$ .

The Lagrangian (3.1.4) gives rise to a symplectic structure  $\Omega: \mathfrak{N} \times \mathfrak{N} \to \mathbb{R}$  via

$$\Omega\{[\phi_1, \, \pi_1], \, [\phi_2, \, \pi_2] \} = \int_{\Sigma_0} d^3x \, (\pi_1 \, \phi_2 - \pi_2 \, \phi_1) \tag{3.2.3}$$

Again, the "symplectic product" is conserved for solutions, thus giving rise to a natural symplectic structure (also denoted  $\Omega$ ) on  $\delta$ .

The fundamental Poisson brackets on  $\mathfrak{M}$  can be expressed as (see eq. (2.1.10) above)

$$\left\{\Omega([\phi_1, \, \pi_1], \cdot), \, \Omega([\phi_2, \, \pi_2], \cdot)\right\} = -\Omega([\phi_1, \, \pi_1], \, [\phi_2, \, \pi_2]) \tag{3.2.4}$$

Note that the significant advantage of eq. (2.1.10) over eqs. (2.1.7)-(2.1.8) now can be seen, since no natural choice of basis of  $\mathfrak{N}$ , exists; in particular, the (real and imaginary parts of) plane wave solutions do not lie in  $\mathfrak{N}$ . Note also that if we choose  $[\phi_1, \pi_1] = [0, f_1]$  and  $[\phi_2, \pi_2] = [f_2, 0]$ , eq. (3.2.4) takes the form

$$\left\{ \int f_1 \phi, \int f_2 \pi \right\} = \int f_1 f_2 \tag{3.2.5}$$

(Here " $\int f_1 \phi$ " means the function on  $\mathfrak M$  whose value at point  $[\phi, \pi]$  is  $\int f_1 \phi$ .) Equation (3.2.5) can be re-expressed more loosely in the familiar form

$$\{\phi(x_1), \pi(x_2)\} = \delta(x_1 - x_2) \tag{3.2.6}$$

We wish to construct a quantum theory in which the functions  $\Omega\left([\phi,\pi],\cdot\right)$  on the classical phase space  $\mathfrak{M}$  are represented (irreducibly) by operators  $\hat{\Omega}([\phi,\pi],\cdot)$  satisfying the commutation relations corresponding to (3.2.4), namely,

$$\left[\hat{\Omega}([\phi_1, \pi_1], \cdot), \hat{\Omega}([\phi_2, \pi_2], \cdot)\right] = -i \Omega([\phi_1, \pi_1], [\phi_2, \pi_2]) I$$
 (3.2.7)

As in the finite dimensional case, we will freely make use of the correspondence between  $\mathfrak{M}$  and  $\mathfrak{L}$ . Thus, equivalently, we seek to obtain operators  $\hat{\Omega}(\psi,\cdot)$  satisfying the analog of eq. (3.2.7) for all  $\psi \in \mathfrak{L}$ . Motivated by the ideas and results of the previous subsection