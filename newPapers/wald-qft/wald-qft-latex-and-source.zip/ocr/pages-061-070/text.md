

{60}------------------------------------------------

stant  $\epsilon(t)$  is smoothly "turned on" and "turned off" at finite times, so that  $\epsilon \in C_0^\infty(\mathbb{R})$ .

We wish to calculate—to lowest order in  $\epsilon$ —the transitions of the two-level system induced by its coupling to the field, as well as the resulting changes in the state of the field. As in most calculations in time-dependent perturbation theory, it is convenient to work in the "interaction picture". From the definition, (3.3.3), of A, it follows immediately that in the interaction picture, we have

$$A_{I}(t) = e^{-i\sigma t} A_{s}$$
 (3.3.5)

where  $A_s$  denotes the (time-independent) Schrodinger picture operator. Hence, in the interaction representation, the interaction Hamiltonian can be expressed as

$$(H_{int})_{I} = \int d^{3}x \left[ \epsilon(t) e^{-i\sigma t} F(\mathbf{x}) \phi_{I}(t, \mathbf{x}) A_{s} + h.c. \right]$$
 (3.3.6)

We consider the case where initially (i.e., before the interaction is "turned on"), the two-level system is in an arbitrary state 1% > and the field is in the state

$$ln_{\psi} > \equiv (0,..., 0, \psi^{a_1} ... \psi^{a_n}, 0,...)$$
 (3.3.7)

for some  $\psi \in \Re$  with unit norm, where the Fock space index notation used here is explained in Appendix A.3. (In standard terminology, the state (3.3.7) normally would be called an "n-particle state", with all the individual particles in state  $\psi$ . However, I shall refrain from using such terminology at this stage, since the goal of the analysis here is precisely to investigate to what extent this terminology is justified.) Thus, we assume that the initial state of the full system is

$$|\Psi_i\rangle = |\mathfrak{T}\rangle |n_{\psi}\rangle \tag{3.3.8}$$

Then, from the standard formulas of time-dependent perturbation theory, we find that to first order in  $\epsilon$ , the final joint state of the two-level and field system is

$$|\Psi_{f}\rangle = \left[I - i \int_{-\infty}^{\infty} dt \left(H_{int}\right)_{I}\right] |\Psi_{f}\rangle \tag{3.3.9}$$

{61}------------------------------------------------

From eq. (3.3.6), we may write

$$\int_{-\infty}^{\infty} dt \ (H_{int})_{I} = \phi_{I}(f)A_{s} + h.c.$$
 (3.3.10)

where

$$f(t,\mathbf{x}) = \varepsilon(t) e^{-i\sigma t} F(\mathbf{x})$$
 (3.3.11)

so that f is a (complex) test function, and by  $\phi_I(f)$  we mean,

$$\phi_{I}(f) = \phi_{I}(Re \ f) + i \ \phi_{I}(Im \ f) \ .$$
 (3.3.12)

Since the interaction representation coincides with the Heisenberg representation for the noninteracting theory, from eq. (3.2.28) we obtain

$$\phi_{\rm I}({\sf f}) = {\sf ia}(\overline{\sf KEf}) - {\sf ia}^{\dagger}({\sf KEf}) \tag{3.3.13}$$

where we have extended the action of K from & to  $\mathbb{A}^{\mathbb{C}}$  by complex linearity. Now, if the interaction is "turned on" and "turned off" very slowly—i.e., if  $\varepsilon$  is a very slowly varying function of time compared with the frequency  $\sigma$ —then f will very nearly be purely positive frequency (see eq. (3.3.11)). In that case, Ef also will be very nearly purely positive frequency, and we obtain

$$KEf \approx Ef, KE\bar{f} \approx 0$$
 (3.3.14)

Hence, writing

$$\lambda = -KEf \tag{3.3.15}$$

we find that in the case where the interaction is turned on and off sufficiently slowly, we have

$$\phi_I(f) \approx ia^{\dagger}(\lambda)$$
 (3.3.16)

(Note that our definition of  $\lambda$  is such that  $||\lambda||$  is proportional to  $\epsilon$ .) Thus, combining eqs. (3.3.9), (3.3.10), and (3.3.16), we find that the final state is

{62}------------------------------------------------

$$\begin{split} |\Psi_{f}\rangle &= (I + a^{\dagger}(\lambda)A - a(\bar{\lambda})A^{\dagger}) |\Psi_{i}\rangle \\ &= |n_{\psi}\rangle|\mathfrak{X}\rangle + \sqrt{n+1} ||\lambda|| (A|\mathfrak{X}\rangle) |(n+1)'\rangle \\ &- \sqrt{n} (\lambda, \psi) (A^{\dagger}|\mathfrak{X}\rangle) |(n-1)_{\psi}\rangle \end{split}$$
(3.3.17)

where

$$|(n+1)'\rangle \equiv (0,..., 0, \psi^{(a_1}...\psi^{a_n} \lambda^{a_{n+1}})/||\lambda||, 0,...)$$
 (3.3.18)

Now consider the case where the quantum mechanical system initially is in its ground state, i.e.  $|\mathfrak{T}>=|\mathfrak{T}_0>$ , so that  $A|\mathfrak{T}>=0$ . Equation (3.3.17) shows that as a result of its interaction with the field, the two-level system may make a transition to its excited state. Furthermore, eq. (3.3.17) shows that—to lowest order in perturbation theory—this transition always is accompanied by a transition of the field from state  $|n_{\psi}>$  to state  $|(n-1)_{\psi}>$ . The probability that this joint transition occurs is proportional to n.

Similarly, we find that if the quantum mechanical system initially is in its excited state 1%<sub>1</sub>>, a transition to its ground state can occur. To lowest order, this transition always is accompanied by a transition of the field to the state 1(n+1), and, in the simple case in which 1 is proportional to 10, the probability of making such a transition is proportional to 11.

A "particle language" can be usefully employed to describe the results summarized in the previous two paragraphs. We interpret any Fock space state with a nonzero component only in  $\mathring{\otimes}_s \mathfrak{R}$  as corresponding to the presence of precisely n "particles" (or "quanta") of the field  $\varphi$ . In particular, the initial state  $|n_{\psi}\rangle$  we have chosen for the field is interpreted as describing n particles, each in state  $\psi$ . The transition  $|n_{\psi}\rangle|\mathfrak{L}_0\rangle\rightarrow|(n-1)_{\psi}\rangle|\mathfrak{L}_1\rangle$  then can be interpreted as corresponding to the "absorption of a particle". This fits in well with the fact that this transition probability is proportional to n. In a similar manner, the transition  $|n_{\psi}\rangle|\mathfrak{L}_1\rangle\rightarrow|(n+1)^{\prime}\rangle|\mathfrak{L}_0\rangle$  can be interpreted as describing the emission of a particle in mode  $\lambda/||\lambda||$ .

Thus, the behavior of the quantum field interacting with the quantum mechanical system is modeled quite well by the following simple picture: One views the quantum field theory as actually being a theory of "particles", with the states of the field given the particle interpretation described above. One views the interactions of the field with the quantum mechanical system as enabling the quantum mechanical system to absorb or emit these particles—mak-

{63}------------------------------------------------

ing appropriate energy conserving transitions of its state when it does so.

This naive particle interpretation of the theory does a remarkably good job of modeling the main features of the interactions of the quantum field with other systems. Note, however, that even in the context of the above model, there are some features which are not well described by the naive particle picture. In particular, as already noted, the probability of making a downward transition is proportional to (n+1). The fact that this probability is nonvanishing even when n=0 is normally described in the particle interpretation by saying that the quantum mechanical system has the ability to "spontaneously" emit a particle. To explain the enhanced probability of making a downward transition when particles are initially present, one invents some new "intuition" and language; the term "stimulated emission" is used to describe this particular effect.

Probably the most misleading aspect of the particle viewpoint is the promotion of a naive view of the vacuum state as an entirely inert entity. The statement that "no particles are present" strongly suggests that the quantum field exerts no influence on other systems when it is in the vacuum state. The fact that it does is then further hidden by the use of terminology like the above-mentioned "spontaneous" emission. In fact, as our calculation explicitly demonstrates, it is the interaction of the quantum mechanical system with the quantum field occurring when the field initially is in its vacuum state which is entirely responsible for the phenomenon of "spontaneous" emission by the quantum mechanical system. The misleading picture of the vacuum state promoted by the particle interpretation is probably the greatest barrier which must be overcome in order to understand the Unruh effect (see chapter 5).

Nevertheless, the particle interpretation is quite useful for describing many phenomena in quantum field theory in flat spacetime, and I shall freely make use of this language below. In particular, henceforth I shall refer to the Hilbert space % occurring in the construction of the quantum field theory as the "one-particle Hilbert space". However, it always should be borne in mind that the notion of "particles"—while quite useful in certain contexts—plays no fundamental role in the formulation of quantum field theory. As we shall see in section 4.3 below, in a curved stationary spacetime, a similar particle interpretation of quantum field theory also can be given. In a curved spacetime which is asymptotically stationary in

{64}------------------------------------------------

## 52 CHAPTER 3

the past or future, a natural particle interpretation of states can be given in these asymptotic regions. However, in a general, curved spacetime, it does not appear that any natural notion of particles exists. Nevertheless, as we shall see explicitly in the next chapter, the lack of a useful particle interpretation of quantum field theory in a general curved spacetime does not prevent one from giving a completely satisfactory formulation of the theory.

{65}------------------------------------------------

## 4 Quantum Fields in Curved Spacetime

In the previous chapter, we formulated quantum field theory in Minkowski spacetime in a way that eliminated any reference to a "plane wave basis". Indeed, the construction given in section 3.2 above relied upon only the structure naturally present in the classical theory, together with the choice of % as the space of "positive frequency solutions". We also described how this construction could be generalized to allow other suitable choices of %. Consequently, we now are in a position to formulate quantum field theory in curved spacetime by a straightforward adaptation of this prescription. However, in order to do so, it is necessary that the causal behavior of the curved spacetime be sufficiently well behaved that the space of solutions to the classical field equations have the same basic structure as in Minkowski spacetime. As we shall see in section 4.1, the condition of global hyperbolicity ensures that this is the case. We shall construct quantum field theory in curved, globally hyperbolic spacetimes in section 4.2. The only significant difference from the Minkowski spacetime case is that, in general, we now do not have a preferred choice of \$6, so we must consider (on an essentially equal footing) the entire class of constructions. tant exception to this statement occurs for the special case of stationary spacetimes, where—as we shall see in section 4.3—a natural prescription exists for defining % as the space of "positive frequency solutions". Section 4.4 analyzes the unitary equivalence of the different constructions and—as a very important byproduct—obtains an explicit construction of the S-matrix describing particle creation and scattering in situations where asymptotic notions of particles exist. The fact that different constructions can yield unitarily inequivalent quantum field theories is then faced directly in section 4.5. It is shown there how the algebraic approach allows one to give a fully satisfactory formulation of quantum field theory in curved spacetime which encompasses all of the different, unitarily inequivalent constructions. However, the theory is still a "minimal" one in that only the primary field observables,  $\hat{\Omega}(\psi,\cdot)$ , are di

{66}------------------------------------------------

rectly represented. An additional observable of great importance for determining the "back-reaction" effects of the quantum field on the curved spacetime is the stress-energy tensor of the field. In section 4.6, we show how the expected stress-energy of states may be determined (up to some "local curvature" ambiguity), and we discuss the back-reaction problem. The Hadamard condition on states is introduced in section 4.6 as a necessary condition for a state to have a finite expected stress-energy, and it also is noted that the imposition of the Hadamard condition greatly restricts the number of unitarily inequivalent Hilbert space constructions of the theory. The chapter concludes with a brief discussion in section 4.7 of the formulation of quantum field theory in curved spacetime for other linear fields.

## 4.1 Curved Spacetimes; Global Hyperbolicity

In the framework of general relativity, spacetime structure is described by a four-dimensional manifold, M, on which there is present a Lorentz metric,  $g_{ab}$ . In addition, in general relativity  $g_{ab}$  is related to the matter distribution by Einstein's equation. However, except for issues related to "back-reaction" (to be discussed in section 4.6), the dynamics of  $g_{ab}$  will not concern us here. Thus, in the following, we shall view the spacetime structure (M,  $g_{ab}$ ) as being given, and focus upon the formulation of the quantum theory of a Klein-Gordon scalar field,  $\phi$ , in this fixed, curved background. Unless otherwise stated, we shall assume throughout these notes that  $g_{ab}$  is smooth.

The classical action of a Klein-Gordon field in curved spacetime is

$$S = -\frac{1}{2} \int (\nabla_a \phi \nabla^a \phi + m^2 \phi^2) \sqrt{-g} d^4x \qquad (4.1.1)$$

and the curved spacetime version of the Klein-Gordon equation thus is

$$\nabla^{a}\nabla_{a}\phi - m^{2}\phi = 0 \tag{4.1.2}$$

where  $\nabla_a$  is the derivative operator compatible with  $g_{ab}$ . Other natural generalizations of eq. (3.1.2) to curved spacetime involving the addition of a term  $\xi R \phi$  to eq. (4.1.2) are possible (where  $\xi$  is a con-

{67}------------------------------------------------

stant and R denotes the scalar curvature). All of our discussion below would apply with equal validity to such modified versions of eq.(4.1.2).

In an arbitrary curved spacetime, the classical existence and uniqueness properties of solutions to eq. (4.1.2) can be very different from that of Minkowski spacetime. Two examples will suffice to illustrate this point: (i) Let spacetime be a flat 4-torus, with spatial periodicity L and time periodicity T, with  $T^2/L^2$  irrational. Then in this spacetime, eq. (4.1.2) with m=0 admits only the solution  $\phi=$  constant. (ii) Consider any spacetime with a "timelike singularity", such as Minkowski spacetime with a timelike line removed, or the Schwarzschild solution with negative mass. Since eq. (4.1.2) does not restrict what can emerge from a singularity, there is no possibility that uniqueness can hold for solutions to eq. (4.1.2) with given initial conditions on a spacelike hypersurface.

We wish to restrict attention here to spacetimes where the classical dynamics governed by eq. (4.1.2) has a well posed initial value formulation analogous to that of Minkowski spacetime. In such cases, we shall be able to formulate quantum field theory constructions in a manner completely analogous to our construction of the previous chapter for a general choice of  $\Re$ . Generalizations of quantum field theory to spacetimes which do not admit a well posed classical initial value formulation may then be considered (see, in particular, Kay (1992)), although we shall not do so in these notes.

Fortunately, there is a simple condition on a spacetime (M,  $g_{ab}$ ) which guarantees that equations of the general form (4.1.2) have a well posed initial value formulation. First, we restrict attention to spacetimes which are time orientable, i.e., such that a continuous choice can be made throughout the spacetime of which half of each light cone constitutes the "future" direction and which half constitutes the "past." Let  $\Sigma \subset M$  be any closed set which is achronal, i.e., no pair of points  $p,q \in \Sigma$  can be joined by a timelike curve. We define the *domain of dependence* of  $\Sigma$  by

$$D(\Sigma) = \{ p \in M | \text{ every (past and future) inextendible causal curve} \\ \text{through p intersects } \Sigma \}$$
 (4.1.3)

(See, e.g., Wald (1984a) for the definition of extendibility of causal curves and further discussion of issues relating to the causal structure of spacetimes.) If  $D(\Sigma) = M$ , then  $\Sigma$  is said to be a *Cauchy* 

{68}------------------------------------------------

surface for the spacetime (M,  $g_{ab}$ ). It then follows that a Cauchy surface is automatically a 3-dimensional,  $C^0$ , hypersurface. If a spacetime admits a Cauchy surface, then the spacetime is said to be globally hyperbolic.

A key theorem regarding the structure of globally hyperbolic spacetimes is the following:

Theorem 4.1.1 (Geroch 1970; Dieckmann 1988) : If  $(M, g_{ab})$  is globally hyperbolic with Cauchy surface  $\Sigma$ , then M has topology  $\mathbb{R} \times \Sigma$ . Furthermore, M can be foliated by a one-parameter family of smooth Cauchy surfaces  $\Sigma_t$ , i.e., a smooth "time coordinate" t can be chosen on M such that each surface of constant t is a Cauchy surface.

Since every causal curve "registers" on a Cauchy surface  $\Sigma$ , one might expect to have a well defined, deterministic classical evolution from initial conditions given on  $\Sigma$ . That this is indeed the case for eq. (4.1.2) is stated in the following theorem (see, e.g., Hawking and Ellis (1973)):

Theorem 4.1.2: Let (M,  $g_{ab}$ ) be a globally hyperbolic spacetime with smooth, spacelike Cauchy surface  $\Sigma$ . Then the Klein-Gordon equation (4.1.2) has a well posed initial value formulation in the following sense: Given any pair of smooth ( $C^{\infty}$ ) functions ( $\phi_0$ ,  $\dot{\phi}_0$ ), on  $\Sigma$ , there exists a unique solution,  $\phi$ , to (4.1.2), defined on all of M, such that on  $\Sigma$  we have  $\phi = \phi_0$  and  $n^a \nabla_a \phi = \dot{\phi}_0$ , where  $n^a$  denotes the unit (future-directed) normal to  $\Sigma$ . Furthermore, for any closed subset  $S \subset \Sigma$ , the solution,  $\phi$ , restricted to D(S) depends only upon the initial data on S. In addition,  $\phi$  is smooth and varies continuously with the initial data (with a suitable, Sobolev space topology defined on the initial data).

Similar results hold for a much more general class of linear wave equations and systems of linear wave equations.

The above theorem continues to hold if a (fixed, smooth) "source term", f, is inserted on the right side of eq. (4.1.2). It then follows directly from the domain of dependence property of this theorem that there exist unique advanced and retarded solutions to the Klein-Gordon equation with source, i.e., in a globally hyperbolic spacetime there exist unique advanced and retarded Green's functions for the Klein-Gordon equation.

In the following, we shall restrict consideration to globally hyperbolic spacetimes.

{69}------------------------------------------------

## 4.2 Construction of Quantum Field Theory in a Curved Spacetime

Let  $(M, g_{ab})$  be a globally hyperbolic spacetime. To obtain a phase space formulation of classical dynamical evolution for the Klein-Gordon field, we first introduce a "slicing" of M by spacelike Cauchy surfaces  $\Sigma_t$ , labeled by the parameter t. We then introduce a "time evolution" vector field,  $t^a$ , on M, satisfying  $t^a \nabla_a t = 1$ . We decompose  $t^a$  as

$$t^a = Nn^a + N^a \tag{4.2.1}$$

where na is the unit normal to  $\Sigma_t$  and Na is tangential to  $\Sigma_t$ . (We refer to N as the *lapse function* and Na as the *shift vector.*) We introduce local coordinates t,  $x^1$ ,  $x^2$ ,  $x^3$  with  $t^a\nabla_a x^\alpha=0$  for  $\alpha=1,2,3$ , so that  $t^a=(\partial/\partial t)^a$ . The Klein-Gordon action (4.1.1) then takes the form

$$S = \int \mathfrak{D} dt \qquad (4.2.2)$$

with

$$\mathfrak{B} = \frac{1}{2} \int_{\Sigma_t} [(n^a \nabla_a \phi)^2 - h^{ab} \nabla_a \phi \nabla_b \phi - m^2 \phi^2] N \sqrt{h} d^3x \qquad (4.2.3)$$

where  $h_{ab}$  is the induced (Riemannian) metric on  $\Sigma_t$ . Using the relation

$$n^{a}\nabla_{a}\phi = \frac{1}{N}(t^{a} - N^{a})\nabla_{a}\phi = \frac{1}{N}\dot{\phi} - \frac{1}{N}N^{a}\nabla_{a}\phi \qquad (4.2.4)$$

we find that the momentum density,  $\pi$ , canonically conjugate to the configuration variable  $\phi$  on  $\Sigma_t$  is given by

$$\pi = \frac{\delta S}{\delta \dot{\phi}} = (n^a \nabla_a \phi) \sqrt{h}$$
 (4.2.5)

Thus, a point in the classical phase space,  $\mathfrak{N}$ , of Klein-Gordon theory in curved spacetime consists of the specification of functions  $\phi(x)$  and  $\pi(x)$  on a Cauchy surface  $\Sigma_0$ . In order that all structures be mathematically well defined, we specify  $\mathfrak{N}$  precisely by again requiring that  $\phi$  and  $\pi$  be smooth and of compact support. Again, we define  $\mathscr{A}$  to be the space of solutions to eq. (4.1.2) which arise from initial