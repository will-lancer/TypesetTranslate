

{50}------------------------------------------------

(as well as those for the finite degree of freedom case), we construct the quantum theory as follows: Given any  $\psi \in \mathcal{A}$ , we decompose it into its parts which oscillate with positive and negative frequency with respect to time:

$$\psi = \psi^+ + \psi^- \tag{3.2.8}$$

(A mathematically precise prescription for this decomposition will be given in section 4.3 in the more general context of a Klein-Gordon field in a curved, stationary spacetime.) Let  $\mathcal{A}^{\mathbb{C}+}$  denote the subspace spanned by the positive frequency parts of solutions in  $\mathcal{A}$ . (Note, however, that since a positive frequency solution can be extended to a holomorphic function in the lower-half complex-t plane, it follows from the "edge of the wedge" theorem (see Streater and Wightman (1964)) that any nonzero element of  $\mathcal{A}^{\mathbb{C}+}$  cannot have initial data of compact support, and hence cannot lie in the complexification,  $\mathcal{A}^{\mathbb{C}}$ , of  $\mathcal{A}$ . The awkwardness caused by this would have been alleviated if we had chosen  $\mathcal{A}$  to be the space of solutions with initial data in Schwartz space.) On  $\mathcal{A}^{\mathbb{C}+}$ , we define the Klein-Gordon inner product by

$$(\psi^+, \chi^+) = -i\Omega(\overline{\psi}^+, \chi^+) \tag{3.2.9}$$

Here the definition of  $\Omega$  has been extended to  $\mathcal{A}^{\mathbb{C}^+}$  using eq. (3.2.3), and it can be shown that this extension is well defined and that the right side of eq. (3.2.9) is positive-definite, provided that, in the case of a massless Klein-Gordon field, the Minkowski spacetime dimension is greater than two. ("Infra-red divergences" occur for the massless Klein-Gordon field in two spacetime dimensions, i.e., in general,  $\psi^+$  will fall off too slowly at infinity to allow  $\Omega$  to be defined.) We then Cauchy-complete  $\mathcal{A}^{\mathbb{C}^+}$  in the norm defined by this inner product to obtain a complex Hilbert space  $\mathfrak{R}$  (see Appendix A.1). This provides a mathematically precise definition of  $\mathfrak{R}$  without the need to "put the field in a box". Note that the association  $\psi \to \psi^+$  yields a (real) linear one-to-one map K: $\mathcal{A} \to \mathfrak{R}$  which takes  $\mathcal{A}$  into a dense subspace of  $\mathfrak{R}$ .

The quantum theory is specified as follows: We take the Hilbert space to be  $\mathfrak{F}_s(\mathfrak{F})$ . For each  $\psi \in \mathcal{S}$ , we define the operator  $\hat{\Omega}(\psi,\cdot)$  on  $\mathfrak{F}_s(\mathfrak{F})$  by

{51}------------------------------------------------

$$\widehat{\Omega}(\psi,\cdot) = ia(\overline{K\psi}) - ia^{\dagger}(K\psi) \qquad (3.2.10)$$

(see eq. (2.3.20) above). We take the Heisenberg representative of this observable to be

$$\widehat{\Omega}_{H}(\psi, \cdot) = ia(\overline{K\psi_{t}}) - ia^{\dagger}(K\psi_{t})$$
 (3.2.11)

(see eq. (2.3.21)) where  $\psi_t$  is the solution whose initial data at time t equals the initial data for  $\psi$  at t=0. As before, eq. (3.2.11) determines the Hamiltonian up to a multiple of the identity operator.

To compare this construction with that of the previous section, suppose again that "space" is a 3-torus of side L. Let  $\psi$  be the solution whose initial data at t=0 is  $[0, L^{-3/2}\cos \mathbf{k}\cdot\mathbf{x}]$ . Then by eqs. (3.2.3) and (3.1.7), the value of function  $\Omega(\psi,\cdot)$  at a point  $[\phi,\pi]$  of  $\mathfrak{M}$  is just Re  $(\phi_{\mathbf{k}})$ . Now, the positive and negative frequency parts of the solution  $\psi$  are

$$\psi^{+} = i(2\omega_{\mathbf{k}})^{-1}L^{-3/2}\cos(\mathbf{k}\cdot\mathbf{x})\exp(-i\omega_{\mathbf{k}}t) \qquad (3.2.12)$$

$$\psi^{-} = -i(2\omega_{\mathbf{k}})^{-1}L^{-3/2}\cos(\mathbf{k}\cdot\mathbf{x}) \exp(+i\omega_{\mathbf{k}}t) \qquad (3.2.13)$$

Hence, we have

$$a(\overline{K\psi}) = -\frac{i}{2} (2\omega_{\mathbf{k}})^{-1/2} (a_{\mathbf{k}} + a_{-\mathbf{k}})$$
 (3.2.14)

where  $a_{\bf k}$  denotes the annihilation operator associated with the normalized solution  $(2\omega_{\bf k})^{-1/2}$  L<sup>-3/2</sup> exp (i ${\bf k}\cdot{\bf x}$ -i $\omega_{\bf k}$ t). Thus, eq. (3.2.10) reduces to

$$\widehat{\Omega}(\psi, \cdot) = \frac{1}{2} (2\omega_{\mathbf{k}})^{-1/2} (a_{\mathbf{k}} + a_{-\mathbf{k}}) + \text{h.c.}$$
 (3.2.15)

This agrees precisely with the expression for Re  $(\phi_{\mathbf{k}})$  obtained from eq. (3.1.16). Similar results hold for Im  $(\phi_{\mathbf{k}})$ . Thus, our reformulation reproduces the quantum theory constructed in the previous section. However, the necessity of choosing a preferred, plane wave basis now has been completely eliminated, and we also have dispensed with the artifice of "putting the field in a box".

Although we have eliminated the need to choose a plane wave basis, it should be emphasized that there does remain one important

{52}------------------------------------------------

choice in our reformulation of the quantum theory: the specification of an appropriate subspace of (complex) solutions which is to serve as the Hilbert space, %. As discussed in section 2.3, in the case of finitely many oscillators, the choice of % actually is irrelevant in that different choices of % (satisfying properties (i)-(iii)) give rise to unitarily equivalent theories. Indeed, our choice of % as the subspace of positive frequency solutions for finitely many, time-independent oscillators is "preferred" only in that it has the convenient feature of making the state  $10 > \in \mathcal{F}_s(\mathcal{K})$  a ground state of the Hamiltonian. However, as we shall see explicitly in section 4.4 below, the choice of % is not irrelevant in field theory. If our interest was solely to define quantum field theory in Minkowski spacetime, we could justify our selection of % as the subspace of positive frequency solutions as being the natural one arising from the time translation invariance of the classical theory, which, in turn, is a consequence of the Poincaré invariance of the theory. However, in a general, nonstationary, curved spacetime, we will not have any criterion available (like Poincaré invariance) to select a unique, preferred choice of \$\mathfrak{H}\$, and we will have to deal with the large class of unitarily inequivalent constructions arising from our freedom to choose 兆

Therefore, it is important to understand exactly what freedom is available in the choice of \$\mathbb{K}\$, i.e., to state precisely what conditions on % are necessary and sufficient for the above construction of a quantum field theory to be mathematically well defined. case of finitely many oscillators, the freedom involved in choosing % was characterized in a very direct and simple fashion as the freedom of choosing a subspace of & satisfying properties (i)-(iii) of section 2.3. However, when & is infinite dimensional, there is considerable awkwardness in attempting to characterize % in this manner. The main reason for this awkwardness is that, unlike the finite-dimensional case, & must first be suitably "enlarged" (by Cauchy-completion) before \( \mathbb{K} \) can be viewed as a subspace of  $\( \&^{\mathbb{C}} \)$ . Indeed, we have already encountered this phenomenon in our construction above: No (nonzero) element of the Hilbert space, \$\%, of the standard Minkowski spacetime quantum field theory actually lies in & C, since all the solutions in & C have initial data of compact support, whereas no positive frequency solution can have this property. However, the required choice of "enlargement" of & makes use of the inner product of %, and thus is really part of the specification of %.

{53}------------------------------------------------

Consequently, there is considerable potential for "circularity" in attempting to define  $\Re$  as a subspace of an enlarged  $\mathscr{E}^{\mathbb{C}}$ , and there is considerable advantage to a construction which, in effect, simultaneously specifies both the enlargement of  $\mathscr{E}$  and the choice of  $\Re$ .

A much more satisfactory way of specifying the freedom involved in the choice of  $\mathfrak R$  is obtained by proceeding in the manner described at the end of chapter 2: We specify a real inner product  $\mu: \mathcal S \times \mathcal S \to \mathbb R$  satisfying, for all  $\psi_1 \in \mathcal S$ ,

$$\mu(\psi_1, \psi_1) \ = \frac{1}{4} \ \frac{\text{l.u.b.}}{\psi_2 \neq 0} \ \frac{[\Omega(\psi_1, \psi_2)]^2}{\mu(\psi_2, \psi_2)} \eqno(3.2.16)$$

Note that eq. (3.2.16) differs from eq. (2.3.28) only in that we have replaced "max" by "least upper bound" (l.u.b.), since, in infinite dimensions, a maximum over all  $\psi_2 \neq 0$  need not be attained. Given such a  $\mu$ , we can enlarge  $\mathcal S$  to a real Hilbert space,  $\mathcal S_\mu$ , with inner product  $(\psi_1,\psi_2)=2\mu(\psi_1,\psi_2)$ , by taking its Hilbert space completion (see Appendix A.1) in the norm  $2\mu$ . By eq. (3.2.16), the bilinear map,  $\Omega: \mathcal S \times \mathcal S \to \mathbb R$ , is bounded in the norm  $2\mu$ , so we may extend its action to  $\mathcal S_\mu \times \mathcal S_\mu$  by continuity. We then define the operator  $J: \mathcal S_\mu \to \mathcal S_\mu$  by

$$\Omega(\psi_1, \psi_2) = 2\mu(\psi_1, J\psi_2) = (\psi_1, J\psi_2) \tag{3.2.17}$$

(Since  $\Omega$  is bounded, existence of a bounded linear map, J, on  $\mathcal{S}_{\mu}$ satisfying eq. (3.2.17) follows from the Riesz lemma (see Appendix A.2) applied to a real Hilbert space.) From the antisymmetry of  $\Omega$ , it follows immediately that  $J^{\dagger} = -J$ . However, eq. (3.2.16) is equivalent to the statement that J is norm preserving in the inner product  $2\mu$ , i.e.,  $J^{\dagger}J = I$ . Hence, in particular, we have  $J^2 = -I$ , and, consequently, J endows & with a complex structure. Thus, we have shown that a specification of an inner product,  $\mu$ , satisfying eq. (3.2.16) gives rise to a complex structure, J, on  $\mathcal{S}_{\mu}$ . Note that, conversely, the specification of a complex structure, J, on & for which  $-\Omega(\psi_1,J\psi_2)$  is a positive definite inner product would give rise, via eq. (3.2.17), to a μ satisfying eq. (3.2.16), so one can view the specification of an inner product, μ, on & satisfying eq. (3.2.16) as being roughly equivalent to the specification of a complex structure, J, on & satisfying the condition that  $-\Omega(\psi_1,J\psi_2)$  is positive definite. However, this equivalence is only rough because only a small class of complex structures obtained from the collection of u's which satisfy eq. 

{54}------------------------------------------------

(3.2.16) would actually map & into itself (rather than into &<sub>u</sub>).

We now complexify  $\mathcal{S}_{\mu}$  and extend the actions of  $\Omega$ ,  $\mu$ , and J from  $\mathcal{S}_{\mu}$  to  $\mathcal{S}_{\mu}{}^{\complement}$  by complex linearity. We define a (complex) inner product on  $\mathcal{S}_{\mu}{}^{\complement}$  by

$$(\psi_1, \psi_2) = 2\mu(\overline{\psi}_1, \psi_2) \tag{3.2.18}$$

for all  $\psi_1,\psi_2\in \mathcal{S}_\mu{}^\mathbb{C}$ , thus making  $\mathcal{S}_\mu{}^\mathbb{C}$  into a (complex) Hilbert space. To obtain the desired complex Hilbert subspace  $\mathfrak{K}\subset \mathcal{S}_\mu{}^\mathbb{C}$ , we note that  $iJ:\mathcal{S}_\mu{}^\mathbb{C}\to\mathcal{S}_\mu{}^\mathbb{C}$  is self-adjoint. From the spectral theorem, it then follows that  $\mathcal{S}_\mu{}^\mathbb{C}$  decomposes into two orthogonal eigensubspaces of J (with eigenvalues  $\pm i$ ), which are easily seen to be complex conjugates of each other. We define  $\mathfrak{K}\subset \mathcal{S}_\mu{}^\mathbb{C}$  to be the eigensubspace with J=+i. It then follows directly that  $\mathfrak{K}$  satisfies properties (i)-(iii) of section 2.3, with  $\mathcal{S}^\mathbb{C}$  replaced by  $\mathcal{S}_\mu{}^\mathbb{C}$  in property (ii). Thus, this construction generalizes to infinite dimensions the prescription for the finite dimensional case given in the last paragraph of section 2.3.

This construction shows that a choice of  $\Re$  can be specified in a mathematically precise manner by a choice of  $\mu$  satisfying eq. (3.2.16). Furthermore, note that the construction allows us to define the map  $K: \mathcal{S}_{\mu}{}^{\mathbb{C}} \to \Re$  to be the orthogonal projection (in the inner product (3.2.18)) onto the subspace,  $\Re$ , of  $\mathcal{S}_{\mu}{}^{\mathbb{C}}$ . The restriction of K to  $\mathcal{S}$  defines a real-linear map  $K: \mathcal{S} \to \Re$  with dense range in  $\Re$  such that for all  $\psi_1, \psi_2 \in \mathcal{S}$ ,

$$\begin{split} (K\psi_1, \ K\psi_2)_{\Re} & = - \ i\Omega(\overline{K\psi}_1, \ K\psi_2) \\ & = \mu(\psi_1, \psi_2) - \frac{i}{2} \ \Omega(\psi_1, \psi_2) \end{split} \tag{3.2.19}$$

In particular, we have,

$$Im(K\psi_1, K\psi_2)_{\Re} = -\frac{1}{2}\Omega(\psi_1, \psi_2)$$
 (3.2.20)

Conversely, a specification of a Hilbert space  $\Re$  together with a real-linear map  $K: A \to \Re$  which satisfies eq. (3.2.20) and whose range is dense in  $\Re$  gives rise, via eq. (3.2.19), to a  $\mu$  which satisfies eq. (3.2.16). This shows that the freedom involved in choosing  $\Re$  is completely characterized by a choice of  $\mu$  which satisfies eq. (3.2.16).

Actually, it is possible to consider even more general con-

{55}------------------------------------------------

structions in which  $\mu$  merely satisfies the inequality (2.3.27) and, correspondingly, only the complexification of the range of K restricted to & is dense in % (so that the span of % and its complex conjugate space,  $\overline{\%}$ , is "larger" than  $\&_{\mu}{}^{\complement}$ ). (Details of this more general construction can be found in Appendix A of Kay and Wald (1991).) Indeed, in the algebraic formulation (see section 4.5 below), it is natural to consider a far wider class of quantum field theory constructions. However, the class of constructions arising from a  $\mu$  satisfying eq. (3.2.16) comprises the class most closely analogous to the quantum theory of finitely many oscillators, and—until we discuss the algebraic formulation—we shall restrict attention to this class.

Once we have chosen  $\Re$  via a choice of  $\mu$  satisfying eq. (3.2.16), the remainder of specification of the quantum field theory construction is straightforward: We take the Hilbert space of the quantum field theory to be  $\Im_s(\Re)$ . The fundamental observables  $\widehat{\Omega}(\psi,\cdot)$  on  $\Im_s(\Re)$  then are defined by eq. (3.2.10), where K is determined by  $\mu$  as described above.

We conclude this section by showing that—in any of these constructions (including, of course, the original, standard construction)—the operator (3.2.10) actually can be re-interpreted as a spacetime average of the (Heisenberg) operator representing the value of the field. This will enable us to give a rigorous meaning to eq. (3.1.19), with  $\hat{\phi}$  viewed as an "operator-valued distribution".

This re-interpretation arises from a relationship between classical solutions to eq. (3.1.2) and the vector space,  $\mathfrak{T}=C_0^\infty(\mathbb{R}^4)$ , of test functions on Minkowski spacetime, i.e.,  $\mathfrak{T}$  is comprised by functions on Minkowski spacetime which are smooth and of compact support. Recall that  $(\mathfrak{S},\Omega)$  was defined to be the symplectic vector space of solutions to eq. (3.1.2) with initial data,  $[\phi,\pi]$ , lying in  $C_0^\infty(\Sigma_0)$ . Let  $f\in \mathfrak{T}$  and let Af and Rf denote, respectively, the advanced and retarded solutions to the Klein-Gordon equation with source f, so that

$$(\partial^a \partial_a - m^2)$$
 (Af) = f,  $(\partial^a \partial_a - m^2)$  (Rf) = f (3.2.21)

with Af = 0 outside the causal past of the support of f, and Rf = 0 outside the causal future of the support of f. Then

$$\mathsf{Ef} = \mathsf{Af} - \mathsf{Rf} \tag{3.2.22}$$

{56}------------------------------------------------

is a solution to the homogeneous equation (3.1.2). Furthermore the initial data for this solution lies in  $C_0^\infty(\Sigma_0)$ . Hence, we obtain a linear map  $E: \mathcal{T} \to \mathcal{S}$ . The key properties of this map are stated in the following lemma:

Lemma 3.2.1 : The map E: $\mathfrak{T}\to \mathcal{A}$  satisfies the following three properties. (1) E is onto, i.e., every  $\psi\in \mathcal{A}$  can be expressed as  $\psi=$  Ef for some  $f\in \mathfrak{T}$ . (2) Ef = 0 if and only if  $f=(\partial^a\partial_a-m^2)g$  for some  $g\in \mathfrak{T}$ . (3) For all  $\psi\in \mathcal{A}$  and all  $f\in \mathfrak{T}$ , we have

$$\int \psi f \, d^4x = \Omega(Ef, \, \psi) \tag{3.2.23}$$

*Proof*: To prove property (1), let  $\psi \in \mathcal{A}$ . Let  $\chi$  be any smooth function on spacetime such that  $\chi = 0$  for  $t \le 0$  and  $\chi = 1$  for  $t \ge 1$ , and define

$$f = -(\partial^a \partial_a - m^2)(\chi \psi) \tag{3.2.24}$$

Then  $f \in \mathfrak{T}$ . Furthermore,  $Af = (1-\chi)\psi$  and  $Rf = -\chi \psi$ , since these quantities solve the inhomogeneous Klein-Gordon equation with the correct boundary conditions. Hence, we obtain  $Ef = \psi$ , as we desired to show.

To prove property (2), we note that if  $f=(\partial^a\partial_a-m^2)g$ , then Af=Rf=g, so Ef=0. Conversely, if Ef=0, then Af=Rf, so both Af and Rf lie in  $\Im$ . But we have

$$f = (\partial^a \partial_a - m^2) Af \qquad (3.2.25)$$

and thus  $f = (\partial^a \partial_a - m^2)g$  with  $g = Af \in \mathcal{T}$ .

Finally, to prove property (3), let  $\psi \in \mathcal{B}$ ,  $f \in \mathcal{T}$ , and choose  $t_1, t_2 \in \mathbb{R}$  so that f = 0 for all  $t \notin [t_1, t_2]$ . Then, integrating by parts twice and using the fact that  $\psi$  satisfies (3.1.2) we obtain the following version of Green's identity:

$$\int d^4x \ \psi \ (\partial^a \partial_a - m^2) \ Af$$

$$= \int_{t \in [t_1, t_2]} d^4x \ \psi \ (\partial^a \partial_a - m^2) \ Af$$

$$= \int_{t_1} d^3x \ [\psi \frac{\partial (Af)}{\partial t} - (Af) \frac{\partial \psi}{\partial t}]$$
 (3.2.26)

However, on the hypersurface  $t = t_1$ , we have Rf = 0. Hence, taking

{57}------------------------------------------------

account of eq. (3.2.25) and the definition of  $\Omega$  (see eq. (3.2.3)), we obtain

$$\int d^4x \ \psi f = \Omega(Ef, \psi) \tag{3.2.27}$$

as we desired to show.

The third property, eq. (3.2.27), of lemma 3.2.1 shows that for each  $f \in \mathcal{T}$ , the function  $\Omega(\mathsf{Ef}, \cdot)$  on & is equal to what one would obtain by averaging the solution over spacetime, weighted by f. This suggests that in the quantum theory, we should identify the (Schrodinger) operator  $\widehat{\Omega}(\mathsf{Ef}, \cdot)$ —defined by eq. (3.2.10)—with the spacetime average of the (Heisenberg) quantum field operator, weighted by f. More precisely, define the operator  $\widehat{\phi}(f)$  by

$$\hat{\phi}(f) = \hat{\Omega}(Ef, \cdot) = ia(K(Ef)) - ia^{\dagger}(K(Ef))$$
 (3.2.28)

Then  $\hat{\phi}$  (f) has the interpretation of being the spacetime average (weighted by f) of the Heisenberg operator representing the value of the field at point  $\mathbf{x}$  at time t. Indeed, eq. (3.2.28) corresponds to what one would obtain by multiplying the formal expression (3.1.19) by f and integrating over spacetime. Thus, although eq. (3.1.19) is mathematically ill-defined, eq. (3.2.28) provides a mathematically rigorous definition of the Heisenberg field operator  $\hat{\phi}$  as an "operator-valued distribution" on spacetime, i.e. as a map from test functions into operators on  $\mathfrak{F}_{\mathbf{s}}(\mathfrak{R})$ .

Note that we may view the collection of all "smeared field operators", defined by eq. (3.2.28), as comprising the fundamental observables of the quantum field theory, since by property (1) of lemma 3.2.1, the specification of these observables for all  $f \in \mathcal{T}$  is equivalent to the specification of the observables  $\hat{\Omega}(\psi,\cdot)$  for all  $\psi \in \mathcal{S}$ . Note also that the field operator  $\hat{\phi}$  satisfies the distributional version of the Klein-Gordon equation, eq. (3.1.2), in the sense that for all  $g \in \mathcal{T}$  we have

$$\hat{\phi} ([\partial^a \partial_a - m^2]g) = \hat{\Omega}(E[\partial^a \partial_a - m^2]g, \cdot) = 0$$
 (3.2.29)

where property (2) of lemma 3.2.1 was used. In addition, note that in terms of the "smeared field operators", the fundamental commutation relations are

{58}------------------------------------------------

$$\begin{split} [\hat{\phi}(f), \ \hat{\phi}(g)] &= [\hat{\Omega}(\mathsf{E}f, \, \cdot), \, \hat{\Omega}(\mathsf{E}g, \, \cdot)] \\ &= -i\Omega \; (\mathsf{E}f, \mathsf{E}g) \\ &= -i\mathsf{E}(f, g) \end{split} \tag{3.2.30}$$

where property (3) of lemma 3.2.1 was used and where we have written  $E(f,g) \equiv \int fEg \ d^4x$ . Equation (3.2.30) frequently is expressed more loosely as

$$[\hat{\phi}(x), \hat{\phi}(x')] = -iE(x,x')$$
 (3.2.31)

Finally, note that it follows immediately from eq. (3.2.28) that

$$<0|\hat{\phi}(f)\hat{\phi}(g)|0> = (KEf, KEg)_{\Re}$$
  
=  $\mu(Ef, Eg) - \frac{i}{2}E(f,g)$  (3.2.32)

where eq. (3.2.19) was used in the second line. Thus, the bilinear map  $\mu: A \times A \to \mathbb{R}$  used to construct the quantum field theory is directly and simply related to the real part of the "two-point function",  $<0|\hat{\phi}(x)\hat{\phi}(x')|_{0}>$ , of the quantum field in the vacuum state defined by the construction.

## 3.3 Particle Interpretation

In the previous two sections, we presented the quantum theory of a Klein-Gordon field  $\phi$  in Minkowski spacetime without ever mentioning the word "particle". This contrasts sharply with most presentations of quantum field theory, wherein one attempts at the outset to obtain a quantum theory of a relativistic particle, and ends up constructing a quantum field theory only because the theory of a relativistic particle runs into some mathematical difficulties. In such presentations, a particle interpretation of the states of the quantum field usually is taken for granted, since the Hilbert space,  $\Re$ , makes its first appearance in the attempt to define a Hilbert space for a single relativistic particle, and the Fock space,  $\Im$  (%), initially appears in the attempt to allow multiparticle states. However, irrespective of the manner in which the formulation of quantum field theory is introduced, the interpretation of the states of a quantum field in terms of "particles" requires justification.

As our presentation makes manifest, quantum field theory is the quantum theory of a field, not a theory of "particles". However, when we consider the manner in which a quantum field interacts 

{59}------------------------------------------------

with other systems to which it is coupled, an interpretation of the states in  $\mathfrak{F}_s(\mathfrak{K})$  in terms of "particles" naturally arises. It is, of course, essential that this be the case if quantum field theory is to describe observed phenomena, since "particle-like" behavior is commonly observed. Indeed, experiments designed to explore quantum field phenomena are usually referred to as "particle physics" experiments.

In this section, we shall illustrate how a particle interpretation of states in the standard quantum field theory in Minkowski spacetime arises by analyzing a simple model coupling of a quantum field to a two-level quantum mechanical system (Unruh and Wald 1984). This analysis provides a good illustration of the nature—and limitations—of the notion of "particles" in quantum field theory in flat spacetime. The limitations of this notion are considerably greater in curved spacetime, where a useful particle interpretation of states does not, in general, exist.

Consider a two level quantum mechanical system which is linearly coupled to a Klein-Gordon quantum field,  $\phi$ , in Minkowski spacetime. More precisely, we consider a combined system whose total Hamiltonian is time-independent and is of the form

$$H = H_{\phi} + H_{q} + H_{int} \tag{3.3.1}$$

Here,  $H_{\varphi}$  denotes the Hamiltonian of the free Klein-Gordon field theory constructed in the previous section. The unperturbed two-level quantum system is taken to have energy eigenstates  $|\mathfrak{X}_0\rangle$  and  $|\mathfrak{X}_1\rangle$ , with energies 0 and  $\sigma$  respectively, so its (unperturbed) Hamiltonian is taken to have the form

$$H_{q} = \sigma A^{\dagger} A \qquad (3.3.2)$$

where the operator A is defined by

$$A|\mathfrak{X}_0>=0, \ A|\mathfrak{X}_1>=|\mathfrak{X}_0>$$
 (3.3.3)

We choose the interaction Hamiltonian, Hint, of this model to be

$$H_{int} = \varepsilon(t) \int d^3x \ \hat{\phi}(\mathbf{x}) \left[ F(\mathbf{x}) A + h.c. \right]$$
 (3.3.4)

where the spatial function F(x) is in  $C_0^{\infty}(\mathbb{R}^3)$ , and the coupling con-