

{130}------------------------------------------------

as being the density matrix  $\exp(-H/T)$  (viewed as an operator acting on the folium of the stationary vacuum state of section 4.3), since we do not thereby obtain a normalizable density matrix. What is needed is a characterization of what it means for an algebraic state,  $\omega$ , to be a thermal equilibrium state without presuming that  $\omega$  exists as a density matrix in any particular representation of the field algebra  $\mathcal{A}$ . Such a characterization is provided by the KMS condition (see, e.g., Bratteli and Robinson (1981)). Thus, the statement that the restriction of the Minkowski vacuum to region I is a thermal state at temperature (5.1.29) can be formulated rigorously by saying that the algebraic state on  $\mathcal{A}_{\rm I}$  obtained by restriction of the Minkowski vacuum satisfies the KMS condition at temperature (5.1.29) with respect to the notion of "time translation" defined by ba.

Remarkably, as pointed out by Sewell (1982), a proof of this mathematically rigorous formulation of the Unruh effect follows directly from results obtained by Bisognano and Wichmann (1976) in work done entirely independently of (and, essentially, simultaneously with) the analysis of Unruh (1976); see Kay (1985) for further discussion. Indeed, the Bisognano-Wichmann theorem holds in the much more general context of axiomatic quantum field theory, thus showing that the results we have obtained above are not restricted merely to the case of linear quantum fields; see also Unruh and Weiss (1984) for an argument for this latter conclusion based upon a path integral approach.

## 5.2 Killing Horizons

The geometrical structure which played the key role in the derivation of the Unruh effect in Minkowski spacetime was the pair of intersecting null planes,  $\mathbf{\hat{h}_A}$  and  $\mathbf{\hat{h}_B}$ , to which the Killing field,  $\mathbf{b^a}$ , is normal. In this section, we shall generalize this structure to curved spacetime by defining the notion of a bifurcate Killing horizon and deriving some of its key properties. This will enable us to generalize the Unruh effect to curved spacetime in the next section.

Recall that an *isometry*, i:M $\rightarrow$ M, on a spacetime, (M, g<sub>ab</sub>), is a diffeomorphism which leaves the metric invariant. A *Killing vector field*,  $\chi^a$ , is the infinitesimal generator of a one-parameter group of isometries, i<sub>t</sub>. It satisfies

$$0 = \mathcal{Z}_{\chi} g_{ab} = 2\nabla_{(a} \chi_{b)} \tag{5.2.1}$$

{131}------------------------------------------------

where  $\nabla_a$  is the derivative operator associated with  $g_{ab}$  and  $\mathfrak Z$  denotes the Lie derivative.

An important property of an isometry is that its action on a connected spacetime, (M,  $g_{ab}$ ), is uniquely determined by its action on a single point  $p_{\in}M$  together with its induced action,  $i^*:V_p \rightarrow V_{i(p)}$ , on the tangent space,  $V_p$ , at p. To prove this, we note that isometries map geodesics to geodesics, and that a geodesic through p is uniquely determined by its tangent at p. Thus, the above information is sufficient to determine the action of i on all geodesics through p. More generally, we uniquely determine i on all "broken geodesics" through p, i.e., all curves through p which are piecewise geodesic. However, since any point  $q_{\in}M$  can be connected to p by a broken geodesic, i is uniquely determined on M.

Applying this result to a one-parameter group of isometries,  $i_t$ , we see that a Killing vector field,  $\chi^a$ , is uniquely determined by its value and the value of its derivative  $F_{ab} \equiv \nabla_a \chi_b = \nabla_{[a} \chi_{b]}$  at any point  $p \in M$ . This result may also be proven directly from the equation,

$$\nabla_c \nabla_a \chi_b = -R_{abcd} \chi^d \tag{5.2.2}$$

which is satisfied by any Killing field (see, e.g., Appendix C of Wald (1984a)).

Consider, now, the case of a two-dimensional manifold, M, and suppose a Killing field,  $\chi^a$ , vanishes at a point  $p \in M$ , i.e.,  $\chi^a(p) = 0$ . Then  $\chi^a$  is determined by the value of the antisymmetric tensor  $F_{ab} = \nabla_a \chi_b$  at p, which is unique up to scaling since is  $V_p$  two-dimensional. The induced action,  $i_t^*: V_p \rightarrow V_{i(p)} = V_p$  of the group of isometries,  $i_t$ , on the tangent space,  $V_p$ , at p is determined by its "infinitesimal action". However, the infinitesimal action of  $i_t^*$  defines the Lie derivative with respect to  $\chi^a$ , i.e., for all  $v^a \in V_p$ , the infinitesimal action of  $i_t^*$  takes  $v^a$  into

$$\mathfrak{Z}_{\chi} v^{a} = F^{a}{}_{b} v^{b} \tag{5.2.3}$$

The nature of the map on  $V_p$  defined by eq. (5.2.3) depends upon the signature of the metric. (The metric enters eq. (5.2.3) via the raising of an index of  $F_{ab}$ .) In the case of a metric of Riemannian signature, eq. (5.2.3) is identical to the action of an infinitesimal rotation in a flat, Euclidean space. It follows immediately that  $i_1^*:V_p \rightarrow V_p$  is simply an ordinary rotation on a tangent space. In par-

{132}------------------------------------------------

ticular, when t takes the value  $t_0$  corresponding to a " $2\pi$ -rotation",  $i_t^*$  is the identity transformation on  $V_p$ . By the above uniqueness result, this implies that  $i_t$  is the identity transformation on M. Consequently, all the orbits of  $i_t$  on M are closed (with period  $t_0$ ), and, in a neighborhood of p, the orbits have the usual structure of rotations about the "axis" p.

On the other hand, for a metric of Lorentz signature, eq. (5.2.3) corresponds to the action of an infinitesimal Lorentz boost in a two-dimensional Minkowski spacetime. Thus,  $i_t^*: V_p \rightarrow V_p$  is simply an ordinary Lorentz boost. It follows that the orbit structure of  $i_t$  in a neighborhood of p has the same structure as shown in fig. 5.1 above.

In n > 2 dimensions with a metric of either Riemannian or Lorentzian signature, exactly the same analysis applies for any Killing field  $\chi^a$  which vanishes on an (n-2)-dimensional spacelike surface S. In the Lorentzian case, the pair of null surfaces  $\hbar_A$  and  $\hbar_B$  (intersecting at S) which are generated by the null geodesics orthogonal to S is called a bifurcate Killing horizon. A bifurcate Killing horizon locally divides the spacetime into four "wedges" I, II, III, IV in the manner shown in fig. 5.1. Note that since  $i_t^*$  takes a null vector orthogonal to S at any  $p_E$  S into a multiple of itself, it follows that  $i_t$  takes null geodesics orthogonal to S into themselves (with a possibly different affine parametrization). Consequently,  $\chi^a$  must be everywhere tangent to the null geodesics orthogonal to S, i.e.,  $\chi^a$  is normal to both  $\hbar_A$  and  $\hbar_B$ .

Since bifurcate Killing horizons occur in Lorentzian space-times whenever a Killing field vanishes on an (n-2)-dimensional spacelike surface, they can be expected to arise commonly in space-times with a high degree of symmetry. An important additional reason for their physical relevance arises from the fact that, under suitable assumptions concerning matter fields and under the assumption of analyticity, it can be shown (Hawking and Ellis 1973) that the event horizon of a stationary black hole must be a *Killing horizon*, i.e., a null surface to which a Killing field is normal. As will be discussed further in section 6.2, this Killing horizon should comprise a portion of a bifurcate Killing horizon, except in the "degenerate case" of vanishing surface gravity (see below). Thus, bifurcate Killing horizons should arise in essentially all spacetimes representing a stationary black hole.

We now introduce the notion of the surface gravity of an arbitrary (i.e., not necessarily bifurcate) Killing horizon. Let  ${\bf h}$  be a

{133}------------------------------------------------

Killing horizon associated with the Killing field  $\chi^a$ , i.e.,  $\mathbf{h}$  is a null hypersurface to which  $\chi^a$  is normal. Since, by definition, we have  $\chi^a\chi_a=0$  on  $\mathbf{h}$ , the vector  $\nabla^b(\chi^a\chi_a)$  must be normal to  $\mathbf{h}$ . Since  $\chi^a$  also is normal to  $\mathbf{h}$ , these vectors must be proportional. Hence, there exists a function  $\kappa$  on  $\mathbf{h}$ —known as the *surface gravity* of  $\mathbf{h}$ —which satisfies

$$\nabla^{b} \left( \chi^{a} \chi_{a} \right) = -2 \kappa \chi^{b} \tag{5.2.4}$$

everywhere on  $\mathbf{h}$ . By taking the Lie derivative of this equation with respect to  $\chi^a$ , it follows immediately that  $\kappa$  must be constant along each orbit of  $\chi^a$  on  $\mathbf{h}$ .

A relatively straightforward calculation (see, e.g., Wald (1984a)) using Killing's equation together with the fact that  $\chi_{[a}\nabla_b\chi_{c]}=0$  on  $\mathbf{h}$  (since  $\chi^a$  is hypersurface orthogonal on  $\mathbf{h}$ ) yields the formula

$$\kappa^2 = -\frac{1}{2} \left( \nabla_{\mathbf{a}} \chi_{\mathbf{b}} \right) \left( \nabla^{\mathbf{a}} \chi^{\mathbf{b}} \right) \tag{5.2.5}$$

where evaluation on  $\pmb{\mathfrak{h}}$  is understood. It follows from this equation that  $\kappa$  can be expressed as

$$\kappa = \lim \left[ a(-\chi^a \chi_a)^{1/2} \right]$$
 (5.2.6)

(see, e.g., Wald (1984a) for a derivation), where a denotes the magnitude of the (proper) acceleration of the orbits of  $\chi^a$  in the region "outside" h where  $\chi^a$  is timelike, and the limit approaching the horizon is taken. (Note that  $\chi^a \chi_a \to 0$  and  $a \to \infty$  in this limit.) In the case of an asymptotically flat spacetime where  $\chi^a$  approaches a time translation at infinity, it is natural to normalize  $\chi^a$  so that  $\chi^a\chi_a\to -1$ at infinity. Then  $(-\chi a \chi_a)^{1/2}$  is the "gravitational redshift factor", so eq. (5.2.6) gives  $\kappa$  the interpretation of being the "redshifted proper acceleration" of the orbits of  $\chi^a$  near the horizon. The terminology "surface gravity" derives from this interpretation. If χa does not approach a time translation at infinity, a similar interpretation of  $\kappa$ as the "redshifted proper acceleration of zero angular momentum observers" can be given; see, e.g., Jacobson and Kang (1993) for further discussion of the various equivalent notions of surface gravity.

Above, we mentioned that  $\kappa$  is constant along each generator of an arbitrary Killing horizon  $\hbar$ . A remarkable property of bifurcate Killing horizons is that  $\kappa$  also does not vary from generator to gen-

{134}------------------------------------------------

erator, so that  $\kappa$  is globally constant on  $\mathbf{h}$ . To see this, we differentiate eq. (5.2.5) on the bifurcation surface S in a direction,  $s^a$ , tangent to S. We obtain

$$\begin{split} \kappa \; s^a \nabla_a \kappa &= -\frac{1}{2} \; s^c (\nabla_c \nabla_a \chi_b) \; (\nabla^a \chi^b) \\ &= \; \frac{1}{2} \; s^c \; R_{abc}{}^d \; \chi_d \; \nabla^a \chi^b \\ &= \; 0 \end{split} \tag{5.2.7}$$

where we used eq. (5.2.2) in the second line, and we used the fact that  $\chi^a=0$  on S in the last line. Thus,  $\kappa$  is constant on S. Since  $\kappa$  also is constant along each generator of any Killing horizon, it follows that for any bifurcate Killing horizon,  $\kappa$  is constant on  $\hbar_A U \hbar_B$ . Note that no use of Einstein's equation was made in this argument, i.e., the constancy of  $\kappa$  holds for an arbitrary bifurcate Killing horizon in a spacetime of any dimension. As we shall discuss further in section 6.2, for four-dimensional spacetimes, Einstein's equation together with the dominant energy condition holding for matter implies the constancy of  $\kappa$  on any (not necessarily bifurcate) Killing horizon.

We conclude this section by showing that the relationship between "Killing parameter time" and "affine parameter time" on any bifurcate Killing horizon corresponds exactly to the relationships (5.1.5) and (5.1.8) obtained in the particular case of Minkowski spacetime. Using Killing's equation  $\nabla_{(a}\chi_{b)}=0$ , we may rewrite eq. (5.2.4) as

$$\chi^a \nabla_a \chi^b = \kappa \chi^b \tag{5.2.8}$$

which is just the geodesic equation in nonaffinely parametrized form. It follows immediately that if v is a Killing parameter on  $\mathbf{h}_A$  i.e., if the function v on the portion of  $\mathbf{h}_A$  to the future of S satisfies  $\chi^a \nabla_a v = 1$ , then

$$V = \exp(\kappa v) \tag{5.2.9}$$

is an affine parameter along the null geodesics tangent to  $\chi^a$  which generate  $h_A$ . Continuing this affine parametrization to the past of S,

{135}------------------------------------------------

we find that the relationship between "Killing time" and "affine time" on  $\mathbf{h}_{A}$  is given by

$$v = \frac{1}{\kappa} \ln|V| \tag{5.2.10}$$

which is of the same form as eq. (5.1.5), as we desired to show. Similarly, on  $\mathbf{\hat{h}}_B$ , the relationship between "Killing time" u and "affine time" U is given by

$$u = -\frac{1}{\kappa} \ln |U|$$
 (5.2.11)

## 5.3 The Unruh Effect in Curved Spacetime

Let  $(M, g_{ab})$  be a spacetime possessing a bifurcate Killing horizon. We assume, in addition that  $(M, g_{ab})$  is globally hyperbolic and possesses a Cauchy surface passing through the bifurcation surface, S. In that case, a global definition of the 4 "wedges" determined by the bifurcate Killing horizon (corresponding to the wedges of Minkowski spacetime shown in fig. 5.1 above) may be given as follows:

Region I = 
$$I^-(h_A) \cap I^+(h_B)$$
 (5.3.1a)

Region II = 
$$I^+(h_A) \cap I^-(h_B)$$
 (5.3.1b)

Region III = 
$$J^+(S)$$
 (5.3.1c)

Region IV = 
$$J^{-}(S)$$
 (5.3.1d)

It follows that these regions are disjoint, except for the intersection of regions III and IV on S (see Kay and Wald (1991)). Furthermore, by the arguments given in the previous section (see the discussion below eq. (5.2.3)),  $\chi^a$  must be timelike in a neighborhood of the horizon in regions I and II. Note, however, that  $\chi^a$  need not be timelike everywhere in regions I and II. Without loss of generality, we may assume that  $\chi^a$  is future-directed timelike in region I near the horizon.

Suppose, now, that  $\chi^a$  is globally timelike in regions I and II. Then, we can perform the quantum field theory construction for a stationary spacetime (see section 4.3) in each of these two wedges separately. The essential features of this construction are the same as our "non-standard construction" of quantum field theory in

{136}------------------------------------------------

Minkowski spacetime based upon the boost Killing field  $b^a$  (see section 5.1). As in that construction, states in the Fock spaces obtained thereby have a natural interpretation in terms of particles "seen" by observers in regions I and II who follow orbits of  $\chi^a$ .

In Minkowski spacetime, in addition to the one-parameter family of Lorentz boosts which generate the bifurcate Killing horizon, there exist the "ordinary time translation" isometries which are globally timelike over all of Minkowski spacetime and serve to define the standard quantum field theory construction and the usual Minkowski vacuum state 10>M. However, in a general curved spacetime with bifurcate Killing horizon, there will not, in general, exist any globally timelike isometries which would enable us to perform a quantum field theory construction analogous to the standard construction for Minkowski spacetime. Nevertheless, we can proceed as follows. As discussed in section 5.1, in Minkowski spacetime, solutions in the one-particle Hilbert space, % 1, associated with the standard construction are characterized by the fact that their restriction to hA is purely positive frequency with respect to "affine time" V and, similarly, their restriction to  $h_B$  is purely positive frequency with respect to U. Now, suppose that in a curved spacetime with bifurcate horizon one had a vacuum state,  $\omega$ —characterized, say, by the real inner product  $\mu: \mathcal{S} \times \mathcal{S} \to \mathbb{R}$  or, equivalently, by the oneparticle Hilbert space,  $\Re$ , together with a real, linear map,  $K: \mathcal{S} \to \Re$ , with dense range—having the property that for all  $\psi \in \mathcal{S}$  the restriction of  $K_{\Psi}$  to  $h_A \cup h_B$  is nonvanishing and is purely positive frequency with respect to V on hA and purely positive frequency with respect to U on h.B. Then an exact repetition of the analysis in Minkowski spacetime yields the following results: When  $\omega$  is (formally) expressed as a state in  $\Im_s(\Re_I)\otimes \Im_s(\Re_{II})$ , it is precisely of the form (5.1.27) with a replaced by  $\kappa$ . Furthermore, the restriction of  $\omega$  to region I is a thermal equilibrium state (with respect to the notion of time translations determined by  $\chi^a$ ) at the Hawking temperature, T, given by

$$T = \frac{\kappa}{2\pi} \tag{5.3.2}$$

Note that the temperature measured locally by any observer following an orbit of  $\chi^a$  will differ from eq. (5.3.2) by the ratio of "Killing time" to "proper time" for that observer, so that the locally measured temperature is given by

{137}------------------------------------------------

$$T = \frac{\kappa}{2\pi\chi} \tag{5.3.3}$$

where  $\chi$  is the "redshift factor", i.e.,  $\chi = (-\chi^a \chi_a)^{1/2}$ . In particular, in view of eq. (5.2.6), this means that the temperature locally measured by a stationary observer very near the horizon will be given by the same formula, eq. (5.1.29), which holds for the Unruh effect in flat spacetime. This result could have been expected on the grounds that the state considered in the above argument corresponds closely to the Minkowski vacuum state, and one would not expect the (finite) spacetime curvature near the Killing horizon to have an important effect in the limit of arbitrarily large acceleration near the horizon.

The above discussion merely postulated the existence of a vacuum state, ω, which satisfies the property that Kψ is purely positive frequency with respect to affine parameter on  $h_A$  and  $h_B$ . However, there is strong motivation for considering states which satisfy this positive frequency condition. As discussed in detail in section 4.6, the expected stress-energy tensor of the quantum field in a state  $\boldsymbol{\omega}$ is well defined and nonsingular only when its two-point distribution,  $\langle \phi(x_1)\phi(x_2)\rangle_{\omega}$ , is of "Hadamard form" (see eq. (4.6.8)). It turns out that the Hadamard form of the two-point function of a vacuum state together with its invariance under the isometries generated by  $\chi^a$  requires solutions in  $\Re$  to be purely positive frequency with respect to affine parameter on  $h_A$  and  $h_B$  in the following sense: Consider a Cauchy surface,  $\Sigma_A$ , containing a portion of  $h_A$  as depicted in fig. 5.2 and consider a solution  $\psi_A$  whose restriction to  $\Sigma_A$  has support on hA. (As explained in the "note in proof" in Kay and Wald (1991), such solutions,  $\psi_A$ , are not, in general, smooth [even if their restriction to  $\Sigma_A$  is smooth] and hence do not lie in  $\mathcal{S}$ . However, states satisfying the Hadamard condition are sufficiently regular that their action can be extended to an enlargement of Weyl algebra containing elements associated with a wide class of such  $\psi_A$ 's.) Then, as shown by the detailed calculations given in Appendix B of Kay and Wald (1991), for any Hadamard vacuum state, ω, which is invariant under the isometries generated by  $\chi^a$ , it follows that  $\mu(\psi_A,\psi_A)$  must be equal to the Klein-Gordon norm of the positive frequency part of  $\psi_A$  on  $\mathbf{h}_A$  with respect to affine parameter V. Similar results hold for the analogous solutions,  $\psi_B$ , associated with the horizon,  $h_B$ . Thus, the condition that solutions in  $\Re$  be purely positive frequency with respect to affine parameter on  $h_A$  and  $h_B$ 

{138}------------------------------------------------

![](_page_138_Picture_2.jpeg)

Figure 5.2. A spacetime diagram showing the Cauchy surface  $\Sigma_A$ .

actually is a consequence of nonsingularity (i.e., Hadamard form) of the vacuum state and its invariance under isometries generated by  $\chi^a$ . In this regard, it should be noted that the Rindler vacuum state  $|0>_{I}\otimes |0>_{II}$  in Minkowski spacetime (or its curved spacetime analogs, such as the Boulware vacuum of extended Schwarzschild spacetime) is not of Hadamard form on the horizon, and, indeed, its stressenergy tensor is divergent in the limit as the horizon is approached.

A mathematically precise and strengthened version of the above results may be stated as follows: Let  $\mathcal{A}_0$  denote the subalgebra of the (enlarged) Weyl algebra generated by solutions of the form  $\psi_A + \psi_B$ . Let  $\mathcal{A}_{0I}$  denote the subalgebra of  $\mathcal{A}_0$  generated by solutions of the form  $\psi_{AI} + \psi_{BI}$ , where  $\psi_{AI}$  and  $\psi_{BI}$  vanish in region II. Let  $\omega$  be any (not necessarily vacuum or even quasi-free) state which satisfies the Hadamard condition and is invariant under the isometries generated by  $\chi^a$ . Then the restriction of  $\omega$  to  $\mathcal{A}_0$  is a (pure) vacuum state, and its restriction to  $\mathcal{A}_{0I}$  is a thermal (i.e., KMS) state at the Hawking temperature (5.3.2). Furthermore, under an additional hypothesis (concerning the absence of "zero modes")  $\omega$  is unique (if it exists) on the entire (enlarged) Weyl algebra. A complete proof of these results when  $\omega$  is assumed to be quasi-free is given in Kay and Wald (1991). The strengthening of the result to drop the quasi-free assumption is given in Kay (1993).

The above results generalize the Unruh effect to curved spacetimes with a bifurcate Killing horizon. Indeed, these results strengthen the results of section 5.1 in that they show that the 

{139}------------------------------------------------

thermality of a state in regions I and II of Minkowski spacetime follows merely from its nonsingularity and its isometry invariance under  $b^a$ ; the myriad of other special properties of the Minkowski vacuum state  $10>_M$  (such as invariance under the full Poincaré group) are not essential for its thermal nature with respect to  $b^a$ .

However, note that the curved spacetime results obtained above are weaker than the results we obtained for Minkowski spacetime in the following two ways: First, thermality is proven only on the ("large") subalgebra  $\mathcal{A}_{01}$  rather than on the full Weyl algebra for region I. Second, while uniqueness results are obtained, existence is not proven. Indeed, it is not difficult to show that if  $\chi^a$ fails to be globally timelike throughout regions I and II—as occurs, for example, in Kerr spacetime-then no nonsingular, isometry invariant state,  $\omega$ , can exist (see Kay and Wald (1991)). However, if  $\chi^a$ is globally timelike in regions I and II and M is the union of the four "wedges" defined by the bifurcate Killing horizon (so that, in particular, there are no additional horizons), it seems plausible that existence will generally hold. In particular, as will be explained further below, if  $\chi^a$  is hypersurface orthogonal (i.e., in the static case) and M is the union of the four "wedges", there is good reason to expect existence to hold unless "infra-red divergences" occur.

An interesting application of the generalization of the Unruh effect to curved spacetime is provided by deSitter spacetime. Suppose we have a nonsingular (i.e., Hadamard) state  $\omega$  which is invariant under the full deSitter group. (As shown by Allen (1985), no such state exists for the massless Klein-Gordon field, but such a state was explicitly constructed by Allen in the massive case.) Then  $\omega$  is a thermal state (in the appropriate "wedges" of deSitter spacetime) at temperature (5.3.2) for each Killing field in deSitter spacetime which generates a bifurcate Killing horizon. Now, given any timelike geodesic,  $\gamma$ , in deSitter spacetime, there exists a Killing field  $\chi^a$  which is everywhere tangent to  $\gamma$  and which generates a bifurcate Killing horizon. We normalize  $\chi^a$  so that  $\chi^a\chi_a=-1$  on  $\gamma$ . Then the surface gravity of  $\chi^a$  is readily computed to be

$$\kappa = \sqrt{\Lambda/3} \tag{5.3.4}$$

where  $\Lambda$  is the cosmological constant. Thus, the result (5.3.2) implies that for the nonsingular deSitter invariant vacuum state,  $\omega$ , every inertial observer "feels himself to be immersed" in a thermal