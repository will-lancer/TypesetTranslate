

{210}------------------------------------------------

- Parker, L. (1969), "Quantized Fields and Particle Creation in Expanding Universes", Phys. Rev. **183**, 1057.
- Racz, I., and Wald, R.M. (1992), "Extensions of Spacetimes with Killing Horizons", Class. Quant. Grav. 9, 2643.
- Radzikowski, M. (1992), "The Hadamard Condition and Kay's Conjecture in (Axiomatic) Quantum Field Theory in Curved Spacetime", Ph. D. thesis, Princeton University.
- Reed, M., and Simon, B. (1980), Functional Analysis (Academic Press, London).
- Russo, J.G., Susskind, L., and Thorlacius, L. (1992), "End Point of Hawking Radiation", Phys. Rev. **D46**, 3444.
- Schoen, R., and Yau, S.-T. (1983), "The Existence of a Black Hole due to Condensation of Matter", Commun. Math, Phys. **90**, 575.
- Segal, I.E. (1963), *Mathematical Problems of Relativistic Physics* (Am. Math. Soc., Providence).
- Segal, I.E. (1967), "Representations of the Canonical Commutation Relations", in *Applications of Mathematics to Problems in Theoretical Physics*, ed. F. Lurcat (Gordon and Breach, New York).
- Sewell, G.L. (1982), "Quantum Fields on Manifolds: PCT and Gravitationally Induced Thermal States", Ann. Phys. **141**, 201.
- Shale, D. (1962), "Linear Symmetries of Free Boson Fields", Trans. Am. Math. Soc. 103, 149.
- Simon, B. (1972), "Topics in Functional Analysis", in *Mathematics of Contemporary Physics*, ed. R.F. Streater (Academic Press, London).
- Simon, J.Z. (1990), "Higher Derivative Lagrangians, Nonlocality, Problems, and Solutions", Phys. Rev. **D41**, 3720.
- Slawny, J. (1972), "On Factor Representations and the C\*-Algebra of the Canonical Commutation Relations", Commun. Math. Phys. 24, 151.
- Streater, R.F., and Wightman, A.S. (1964), *PCT, Spin and Statistics, and All That* (Benjamin, New York).
- Sudarsky, D., and Wald, R.M. (1992), "Extrema of Mass, Stationarity and Staticity, and Solutions to the Einstein-Yang-Mills Equations", Phys. Rev. **D46**, 1453.
- 't Hooft, G. (1991), "The Black Hole Horizon as a Quantum Surface", Physica Scripta **T36**, 247.
- 't Hooft, G. (1992), "Scattering Matrix for a Quantized Black Hole", in *Black Hole Physics.*, ed. V. DeSabbata and Z. Zhang, (Kluwer Academic Publishers, Dordrecht).
- Tagaki, S. (1986), "Vacuum Noise and Stress Induced by Uniform Acceleration", Prog. Theor. Phys. Suppl. 88, 1.
- Thorne, K.S., Zurek, W.H., and Price, R.H. (1986), "The Thermal Atmosphere of a Black Hole", in *Black Holes: The Membrane Paradigm*, ed. K. S. Thorne, R. H. Price, and D. A. MacDonald (Yale University Press, New Haven).
- Unruh, W.G. (1976), "Notes on Black Hole Evaporation", Phys. Rev. D14, 870.
- Unruh, W.G., and Wald, R.M. (1984), "What Happens When an Accelerating Observer Detects a Rindler Particle", Phys. Rev. **D29**, 1047.
- Verch, R. (1994), "Local Definiteness, Primarity, and Quasiequivalence of Quasifree Hadamard Quantum States in Curved Spacetime", Commun. Math. Phys. 160, 507.

{211}------------------------------------------------

- von Neumann, J. (1938), "On Infinite Direct Products", Composito Mathematica 6, 1.
- Wald, R.M. (1975), "On Particle Creation by Black Holes", Commun. Math. Phys. **45**, 9.
- Wald, R.M. (1976), "Stimulated Emission Effects in Particle Creation near Black Holes", Phys. Rev. **D13**, 3176.
- Wald, R.M. (1977), "The Back Reaction Effect in Particle Creation in Curved Spacetime", Commun. Math. Phys. **54**, 1.
- Wald, R.M. (1978a), "Trace Anomaly of a Conformally Invariant Quantum Field in Curved Spacetime", Phys. Rev. **D17**, 1477.
- Wald, R.M. (1978b), "Axiomatic Renormalization of the Stress Tensor of a Conformally Invariant Field in Conformally Flat Spacetimes", Ann. Phys. 110, 472.
- Wald, R.M. (1979a), "Existence of the S-Matrix in Quantum Field Theory in Curved Spacetime", Ann. Phys. **118**, 490.
- Wald, R.M. (1979b), "On the Euclidean Approach to Quantum Field Theory in Curved Spacetime", Commun. Math. Phys. **70**, 221.
- Wald, R.M. (1980), "Quantum Gravity and Time Reversibility", Phys. Rev. **D21**, 2742.
- Wald, R.M. (1984a), General Relativity (University of Chicago Press, Chicago).
- Wald, R.M. (1984b), "Black Holes, Singularities, and Predictability", in *Quantum Theory of Gravity*, ed. S.M. Christensen (Adam Hilger Press, Bristol).
- Wald, R.M. (1986), "Black Holes and Quantum Coherence", Found. of Phys. **16**, 501.
- Wald, R.M. (1988), "Black Hole Thermodynamics", in *Highlights in Gravitation and Cosmology*, ed. B. R. lyer, A. Kembhavi, J. V. Narlikar, and C. V. Vishveshwara, (Cambridge University Press, Cambridge).
- Wald, R.M. (1992), "Black Holes and Thermodynamics", in *Black Hole Physics.*, ed. V. DeSabbata and Z. Zhang, (Kluwer Academic Publishers, Dordrecht)
- Wald, R.M. (1993a), "The First Law of Black Hole Mechanics", in *Directions in General Relativity*, Vol.1, ed. B.L. Hu, M.P. Ryan, and C.V. Vishveshwara, (Cambridge University Press, Cambridge).
- Wald, R.M. (1993b), "'Weak' Cosmic Censorship", in *PSA 1992*, volume 2, ed. by M. Forbes D. Hull and K. Okruhlik, Philosophy of Science Association (East Lansing, 1993).
- Wald, R.M. (1993c), "Black Hole Entropy is the Noether Charge", Phys. Rev. **D48**, R3427.
- Woodhouse, N. (1980) Geometric Quantization (Clarendon Press, Oxford).
- Zurek, W.H., and Thorne, K.S. (1986), "Statistical Mechanical Origin of the Entropy of a Rotating, Charged Black Hole", Phys. Rev. Lett. **54**, 2171.

{212}------------------------------------------------

{213}------------------------------------------------

## **Notation Index**

a, a<sup>†</sup> annihilation and creation operators 22, 194

| A                                | Weyl algebra 74                                                            |
|----------------------------------|----------------------------------------------------------------------------|
| $A_{0}$                          | subalgebra of A associated with spacetime region © 84                      |
| C,D                              | operators arising in solving for the S-matrix 68                           |
| D(0)                             | domain of determinacy of © 84                                              |
| $D(\Sigma)$                      | domain of dependence of $\Sigma$ 55                                        |
| Ε                                | advanced minus retarted Green's function 43                                |
| $\mathfrak{F}_{s}(\mathfrak{K})$ | symmetric Fock space 192                                                   |
| φ                                | Klein-Gordon scalar field 32, 54                                           |
| φ̂(f)                            | Klein-Gordon (smeared) field operator 45, 59                               |
| g <sub>ab</sub>                  | spacetime metric 1                                                         |
| $\mathcal{H}$                    | one-particle Hilbert space 25, 27, 33, 38, 40-42, 58, 63                   |
| $\mathfrak{H}_{in}$              | "in" one-particle Hilbert space 64                                         |
| $\mathfrak{L}_{out}$             | "out" one-particle Hilbert space 64                                        |
| $\mathcal{H}$                    | complex conjugate space to % 190-91                                        |
| $\mathbf{h}_A, \mathbf{h}_B$     | portions of a bifurcate Killing horizon 120                                |
| h+                               | future horizon 134                                                         |
| 1+, 1-                           | null infinity 133                                                          |
| K                                | "projection map" from & to % 28, 38, 42                                    |
| κ                                | surface gravity 121                                                        |
| М                                | spacetime manfold 1                                                        |
| $\mathfrak{m}$                   | phase space 11, 36, 57                                                     |
| μ                                | inner product on & used for the construction of % 29, 41, 58               |
| π                                | momentum density 36, 57                                                    |
| <i>8</i>                         | vector space of (real) classical solutions 13, 36-37, 57-58                |
| DB,                              | complexification of & 24                                                   |
| æμ                               | Cauchy completion of & in the inner product μ 41                           |
| <b>∕</b> 80                      | subspace of classical solutions associated with spacetime region 0 8       |
| <u>ა</u>                         | space of "test functions" 43, 58                                           |
| T <sub>ab</sub>                  | stress-energy tensor of φ 85                                               |
| U                                | S-matrix 64, 66 (also used as affine parameter on h <sub>B</sub> 109, 123) |
| V                                | Killing parameter on hA 110, 122                                           |
| V                                | affine parameter on hA 109, 122-23                                         |
| Ω                                | symplectic structure on M or & 14-15, 37, 58 (also used for                |
|                                  |                                                                            |

{214}------------------------------------------------

## 202 NOTATION INDEX

angular velocity of the horizon 140)

- $\Omega(\textbf{y}, \boldsymbol{\cdot})$  function (or corresponding quantum observable) on  $\mathfrak{M}$  or & obtained from  $\Omega$  15
- $\boldsymbol{\hat{\Omega}}(\psi, \boldsymbol{\cdot})$  quantum observable corresponding to  $\Omega(\psi, \boldsymbol{\cdot})$  26, 39, 59

{215}------------------------------------------------

## General Index

Italic page numbers denote definitions.

adjoint 191 ADM Hamiltonian 144 algebra 189; C\*- 190; von Neumann 79; Weyl 74 algebraic formulation 73-85; for fermion fields 104 angular velocity of horizon 140 annihilation operator 22, 194 antilinear map 188 area theorem 137-39 asymptotic completeness 153, 154back-reaction 86, 98-100; for black holes 175-77, 186-87 baryon nonconservation 177-78 bifurcate Killing horizon 120, 120-23, 140-41 black holes 6-8, 133-34; area theorem 137-39; classical properties of 133-50; evaporation of 175-87; particle creation by 152-63; predictable 137; thermodynamic laws of 7-8, 139-50, 163-75 Bogoliubov transformation 69 Boulware vacuum 126, 128, 160-61 buoyancy force 168-71 C\*-algebra 190; net of 84 Cauchy surface 55-56 charged scalar field 101-3 coherence, quantum: loss of 178-85, commutation relations; of annihilation and creation operators 22, 194; of fundamental quantum observables 18, 37, 45-46 complex conjugate space 190 complex structure 41 cosmic censorship 135-37

creation operator 194 cyclic vector 76 density matrix: in Hawking effect 179-80; in Unruh effect 115 deSitter spacetime 127-28 DeWitt-Schwinger expansion 93 dilaton gravity 185-87 direct sum 191 domain of dependence 55 domain of determinacy 84 dual space 190 electromagnetic field, quantum theory entropy, of black hole 163-64; in general theory of gravity 145-47; generalized 166 Euclidean methods 129-32, 164-66 event horizon 134, 137-39, 140-41 Fell's theorem 81 fermion fields 103-4 Feynmann propagator 130, 130-32 field operator 45, 59 first law 141-47 Fock space 192 folium 76 fundamental observables 74 generalized second law 166, 166-75 global hyperbolicity 56 GNS construction 76 Green's functions 43-46, 56, 58, 93, 130-32 Hadamard bi-distribution 92 Hadamard state 95, 95-97, 125-26, 161-62 Hamiltonian: in classical mechanics 11-13; for field-particle detector system 47; for general relativity 144; for harmonic oscillator 21-22;

{216}------------------------------------------------

Hamiltonian diagonalization 65 harmonic oscillator 21-30 Hartle-Hawking vacuum 128, 128-29, 151, 155, 161 Hawking effect 8-9, 151-63, 157 Hawking temperature 124 Hilbert space 189; completion 189; direct sums of 191; for quantum field 33-34, 38, 40-43, 46, 58, 102-4; in stationary spacetimes 63; tensor products of 191-92. See also "in" representation; one-particle Hilbert space; "out" representation horizon 134, 134-35. See also event horizon; Killing horizon "in" representation 64; for black hole 153 index notation 192-94 infra-red divergences 38, 61, 83, 93, 97, 131 inner product 189; Klein-Gordon 38 interacting fields: See nonlinear fields irreducible representation 19, 83-84 isometry 118 Kerr black hole 127, 129, 141, 149, Killing horizon 120, 120-23, 140-41; degenerate 141 Killing vector field 118 Klein-Gordon inner product 38 KMS condition 118, 126 Lagrangian: for dilaton gravity 186; for general theory of gravity 145; for harmonic oscillator 21; for Klein-Gordon field 32, 54 lapse function 57, 144 lifetime, of black hole 177 linear dynamical system 14 linear map 188 Maxwell field, quantum theory of 101 measurement theory, in algebraic approach 78-81 mixed state 83, 84-85 momentum density 36, 57 Noether charge 146 nonlinear fields 118, 132, 162-63 norm 188-89

normal ordering 87-88

null energy condition 138 one-particle Hilbert space 25, 27-30, 33-34, 38, 40-43, 46, *51*, 58, 63, "out" representation 64; for black hole 153-54, 157, 179-80 particle creation 71; by black holes 152-63 particle, definition of 2-4, 46-52, 59-60, 63-64, 116, 159 particle detector 47-51, 63, 116 partition function 164 phase space 11, 36, 57 "point-splitting" regularization 87-88, 91-94, 99 Poisson bracket 13-14, 15, 37; relationship with commutators 17-18, 20 positive frequency 23, 25, 27, 33-34, 38, 40, 61, 63, 71 positivity condition 74, 75 propagator: See Feynmann propagator: Green's functions: two-point function pure state 83, 84-85 quasi-free state 77, 84 Reeh-Schlieder theorem 85 regularization, of stress-energy tensor: See "point-splitting" regularization remnant, of black hole 183-84 Riesz lemma 190 Rindler vacuum 107, 126 runaway solution 99-100 S-matrix 64, 66-71, 83; in Hawking effect 154-59; in Unruh effect, 114 Schwarzschild black hole 128-29; particle creation by 152-63 second law: area theorem 137-39; generalized 166-75 semiclassical approximation: See back-reaction shift vector 57, 144 solution space 17, 36-37, 57-58, 101 spontaneous emission 51, 71 squeezed vacuum state 29, 71 state, algebraic 74 stationary spacetimes, quantum field

{217}------------------------------------------------

theory in 61-65 stimulated emission 51 Stone-von Neumann theorem 20 stress-energy tensor, quantum 85-100, 187 superscattering matrix 180, 181 surface gravity 121, 121-22, 127, 128, 140, 149 symplectic form 11 symplectic structure 14-15, 16-17, 37, 58, 101 temperature, of Schwarzschild black hole 157 tensor product 191-92 test functions 43, 58, 84 third law 149 trace anomaly 94

trapped surface 7, 139 two-dimensional model: See dilaton gravity two-point function 46, 74-75, 87-88, 91-94; in Hawking effect 159-62; in Unruh effect 117, 130-32 unitary equivalence 19, 60, 66-72, 73, 83, 96-97; in Unruh effect 114 Unruh effect 8, 105-18, 115, 123-32 Unruh vacuum 158 vacuum polarization 88 vacuum state xii-xiii, 50-51 vector space 188 von Neumann algebra 79 Weyl algebra 74 Weyl relations 19, 73 zeroth law 149