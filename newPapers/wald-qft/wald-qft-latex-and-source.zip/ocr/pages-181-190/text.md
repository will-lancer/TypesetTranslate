

{180}------------------------------------------------

The above calculation does not take quantum effects like Hawking radiation into account, but since the calculation is applicable to a macroscopically large black hole, one might expect that such quantum effects could be made negligible simply by taking M to be sufficiently large. Remarkably, however, although for a large black hole the Hawking radiation seen at infinity indeed is negligible and there are no important nonclassical effects on freely falling bodies, we now shall show that the Unruh effect makes a large quantum correction to the behavior of a body which is slowly lowered toward the horizon of the black hole. As discussed in section 5.3, when the field is in the natural vacuum state of the extended black hole spacetime, a static observer will see himself immersed in a thermal bath at the locally measured temperature,

$$T = \frac{\kappa}{2\pi\lambda} \tag{7.2.10}$$

(see eq. (5.3.3) above). As discussed in detail in the previous section, for the case of an isolated black hole formed by gravitational collapse, only the particle states which correspond to modes emerging from the "white hole horizon" will be thermally populated according to eq. (7.2.10) at late times. However, since these modes dominate all modes near the black hole horizon, the deviation from an exactly thermal state (with respect to all modes) near the horizon is negligible, and will be ignored in our calculations below. (In any case, the deviations from thermality due to the fact that the particle states in  $\Re_{-\infty}$  are unpopulated should serve only to enhance the effects calculated below.)

Since the redshift factor  $\chi$  is not constant, according to eq. (7.2.10) there will be a nonzero gradient of the locally measured temperature seen by static observers. By the Gibbs-Duhem relation of elementary thermodynamics (in the case of vanishing chemical potential) there will be a pressure gradient associated with the thermal bath given by

$$\nabla_{\mathbf{a}} \, \mathsf{P} = \mathsf{s} \, \nabla_{\mathbf{a}} \, \mathsf{T} \tag{7.2.11}$$

where s is the entropy density of the thermal bath. Consequently, there will be a buoyancy force exerted on a box lowered slowly toward a black hole, much as though the box were being lowered into

{181}------------------------------------------------

an ordinary fluid body. I will now outline the calculation (Unruh and Wald 1982) that shows that this buoyancy force acts in just the right way to preserve the generalized second law.

Taking into account the buoyancy force, we find that the force, eq. (7.2.6), is modified to become

$$F_{\infty} = E \frac{dX}{dy} + V \frac{d(XP)}{dy}$$
 (7.2.12)

where V denotes the volume of the box. Integrating eq. (7.2.12), we find

$$W_{\infty} = (1 - \chi) E - \chi PV$$
 (7.2.13)

so that the energy delivered to the black hole now is given by

$$\Delta M = \chi (E + PV) \tag{7.2.14}$$

Thus, more energy actually is delivered to the black hole than was found in the above classical calculation. Indeed, since  $\chi P$  becomes large near the horizon, the optimal place to release the matter into the black hole no longer is at the black hole horizon. Rather, the optimal place now occurs at the value of y at which

$$0 = \frac{d(\Delta M)}{dy} = -\frac{dW_{\infty}}{dy} = -F_{\infty}$$
 (7.2.15)

i.e., at the "floating point" of the box. By eq. (7.2.12), the "floating point" condition is

$$0 = E \frac{dX}{dy} + PV \frac{dX}{dy} + VX \frac{dP}{dy}$$

$$= (E + PV) \frac{dX}{dy} + VX s \frac{dT}{dy}$$

$$= (E + PV - VsT) \frac{dX}{dy}$$
(7.2.16)

where eqs. (7.2.10) and (7.2.11) were used in the last two steps. Since  $d\chi/dy \neq 0$ , the floating point condition becomes

{182}------------------------------------------------

$$E + PV - sTV = 0$$
 (7.2.17)

However, the integrated form of the Gibbs-Duhem relation for the thermal bath yields

$$eV + PV - sTV = 0$$
 (7.2.18)

where e denotes the energy density of the thermal bath. Thus, the condition for the box to float is simply

$$E = eV \tag{7.2.19}$$

which agrees with a result previously obtained by Archimedes.

We substitute eq. (7.2.19) into eq. (7.2.14) to obtain the minimum energy that can be delivered to the black hole in this process. Using eqs. (7.2.18) and (7.2.10), we obtain

$$(\Delta M)_{min} = \frac{\kappa}{2\pi} Vs \qquad (7.2.20)$$

and hence,

$$(\Delta A)_{min} = \frac{8\pi}{\kappa} (\Delta M)_{min} = 4Vs \qquad (7.2.21)$$

Thus, the net change in generalized entropy in the process is given by

$$\Delta S' = \Delta S_m + \Delta A/4 \ge \Delta S_m + (\Delta A)_{min}/4 = -S + sV$$
 (7.2.22)

where s is the entropy density of the thermal bath at the floating point. But, by definition, at a given energy and volume, the entropy is maximum in a thermal state. Thus, taking eq. (7.2.19) into account, we obtain sV 2 S and thus,

$$\Delta S' \ge 0 \tag{7.2.23}$$

i.e., the generalized second law cannot be violated by this process. Note that this argument does not assume the existence of any bound (such as the one postulated by Bekenstein (1981)) for the amount of entropy at fixed energy that can be put in a box of a given size. If S/E is large for the matter lowered toward the black hole, then the entropy density of thermal matter at that energy density must be 

{183}------------------------------------------------

correspondingly large, and, by eq. (7.2.11), the buoyancy force on the box also will be correspondingly large, thereby preventing a violation of the generalized second law.

Note also that in the above calculation of the buoyancy force on the box, we attributed an energy density, e, and pressure, P, to the thermal bath of radiation. In fact, however, this is not correct: For a macroscopic black hole, the true expected stress-tensor <Tab> of the quantum field is negligibly small near the horizon, as expected on physical and dimensional grounds. The thermal bath values, e and P, used in the above calculation actually measure the expected energy and pressure relative to the natural vacuum state, 10>s, defined by the static isometries. (Thus, it follows that for a macroscopic black hole, the expected energy density and pressure in the state  $10>_s$  are nearly -e and -P, respectively.) Since only the stress-tensor differences between the outside and inside of the box are relevant to the calculation of forces on the box, this shift of the "zero-point" of  $\langle T_{ab} \rangle$  has no effect upon the above results. However, it does indicate that the process is more accurately described by saying that-rather than feeling an externally applied buoyancy force-the box fills up with negative energy and pressure (flowing into the box by a "radiation by moving mirrors" effect) as it is slowly lowered. In this more accurate "inertial" description, the "floating point" occurs when a sufficient amount of negative energy has flowed into the box that the total energy of the box is zero. The difference between the behavior of a slowly lowered box-which feels a large force of quantum origin-and a freely falling box-which feels a negligible quantum force-also is readily explained in this inertial viewpoint, since the freely falling box does not fill up with negative energy. Further discussion of these features of the process as well as a discussion of the inverse process of "mining" energy from a black hole can be found in Unruh and Wald (1982).

The fact that the above gedankenexperiment fails to produce a counterexample to the generalized second law suggests that it should be possible to give a more general argument for the validity of that law, at least in the case of processes which can be treated as small perturbations of a stationary black hole. Such an argument has been given by Zurek and Thorne (1986) and Thorne, Zurek, and Price (1986). The following argument (Wald 1988, 1992) roughly corresponds to the one they have given; a related argument has been given very recently by Frolov and Page (1993).

{184}------------------------------------------------

We consider a process wherein we start with a stationary black hole and perturb it (infinitesimally) by some process, e.g., by dropping matter into it. We wish to calculate the net change,  $\Delta S'$ , in generalized entropy resulting from the process. In comparing the perturbed spacetime with the unperturbed black hole, it is convenient to make an identification of perturbed and unperturbed spacetimes in such a way that the black hole horizons coincide and have the same null generators. In addition, we identify the spacetimes so that in a neighborhood of the horizon of the perturbed spacetime, the image under this identification of the Killing field Xa normal to the horizon in the unperturbed spacetime has the same norm,  $\chi^2 = -\chi_a \chi^a$ , as it has in the unperturbed spacetime. (This can be achieved by composition of any horizon preserving identification with an additional diffeomorphism which moves points along the orbits of  $\chi a$ , thereby "compressing" or "stretching"  $\chi a$  as needed.) We then define  $\chi^a$  on the perturbed spacetime to be the image of  $\chi^a$  under this identification of the Killing field Xa. Thus, in this choice of "gauge", we automatically have  $\delta \chi a = 0$  on the perturbed spacetime as well as  $\delta \chi = 0$  in a neighborhood of the horizon.

Consider, now, the family of observers outside the black hole who follow orbits of  $\chi a$ . In the unperturbed spacetime, such observers "see" a thermal bath of particles, and-relative to the stationary vacuum state 10>s associated with Xa-they would assign a thermal bath energy density, e, to the quantum field given by

$$e = T_{ab} \chi a \chi b / \chi^2 \qquad (7.2.24)$$

where Tab denotes the difference between the actual expected stress energy and the expected stress-energy in the state 10>s. Such observers also would naturally assign to the quantum field a thermal bath entropy current of the form

$$S^{a} = sX^{a}/X \tag{7.2.25}$$

However, as I shall discuss further below, in this case the "objective significance" of Sa is far from clear. The local entropy density, s, then is given in terms of Sa by

$$s = -S_a \chi^a / \chi \tag{7.2.26}$$

{185}------------------------------------------------

Consider, now, the perturbed spacetime and consider, again, the observers following orbits of  $\chi^a$ . The perturbation in the energy and entropy densities they would assign to the quantum field are given by

$$δe = δ[Tab  $χa χb/χ²]$ 

$$= (δTab) χa χb/χ²$$
(7.2.27)$$

and

$$\delta s = -\delta[S_a \chi^a/\chi] = -(\delta S_a) \chi^a/\chi \qquad (7.2.28)$$

However,  $\delta s$  would be maximized for a given  $\delta e$  if the perturbed field remained locally in a thermal state. Hence, we must have

$$\delta s \le (\delta s)_{th} = \delta e/T = 2\pi \chi \, \delta e/\kappa \qquad (7.2.29)$$

where we have used the ordinary first law of thermodynamics for the thermal bath as well as the formula (7.2.10) for the locally measured temperature. We multiply eq. (7.2.29) by  $\chi$  and take the limit as one approaches the horizon, using eqs. (7.2.27) and (7.2.28). We thereby obtain

$$-(\delta S_a) \chi^a \Big|_{horizon} \le \frac{2\pi}{\kappa} (\delta T_{ab}) \chi^a \chi^b \Big|_{horizon}$$
 (7.2.30)

We integrate eq. (7.2.30) over the horizon (with respect to Killing parameter v). The left side then can be interpreted as the total flux of matter entropy into the black hole, whereas the right side is proportional to the same combination of energy and angular momentum fluxes as appeared in the derivation of the first law (see eq. (6.2.6)). (Although  $T_{ab}$  is the "fictitious thermal bath stress-energy", the difference  $\delta T_{ab}$  is equal to the difference in true stress energies.) Using the first law of black hole mechanics (6.2.8), we thus obtain the final result

$$-\Delta S \le \Delta A/4 \tag{7.2.31}$$

which states that the generalized second law is satisfied in any process that can be treated as a small perturbation of a stationary black hole.

Although the above calculation certainly is supportive of the validity of the generalized second law, we should point out a problematical aspect of the analysis. As already noted above, the calcu-

{186}------------------------------------------------

lation assumes that we can assign an entropy current density Sa to the state of the quantum field in such a way that eqs. (7.2.26) and (7.2.29) hold and  $-S_a \chi^a$  yields the matter entropy flux into the black hole. However, it is far from clear how to define a meaningful notion of an entropy current density in quantum field theory, particularly since one would wish to avoid the introduction of the problematical notion of "particles" in making such a definition. Indeed, the likely difficulties in defining Sa in such a way as to validate the above argument are highlighted if we consider the entropy current to be assigned to the Minkowski vacuum state in flat space-By Poincare invariance, it is clear that any "objectively defined" entropy current density must vanish. However, a uniformly accelerating observer following the orbit of a boost Killing field Xa would naturally assign a nonvanishing entropy current of the form (7.2.25) to this state, and, indeed, this type of assignment was assumed in the above calculation. One might expect that—in analogy with the situation for stress-energy-formula (7.2.25) actually should be interpreted as yielding the difference between a well defined, "objective" entropy current density of the Minkowski vacuum state (which vanishes) and that of the static (i.e., "Rindler") vacuum associated with Xa. However, that would entail the assignment of a negative entropy density to Rindler vacuum state in Minkowski spacetime, and it is not clear what this would mean. Alternatively, perhaps one should not attempt to define an "objective" entropy, but only define entropy with respect to a notion of time translations, so that, for example, the entropy current of the Minkowski vacuum with respect to ordinary time translations would vanish, but its entropy with respect to  $\chi^a$  would be nonvanishing. However, in that case, it would appear that entropy could be defined only in the quasistationary case.

Despite this difficulty, I see little reason to doubt the validity of the generalized second law. (In any case, the recent arguments of Frolov and Page (1993) do not require the introduction of a local entropy current density.) If the validity of the generalized second law is accepted, then by far the most natural interpretation of the laws of black hole thermodynamics is that they simply *are* the ordinary laws of thermodynamics applied to a black hole. In that case, A/4 truly would represent the physical entropy of a black hole, and S' simply would be the total entropy of the universe, including contributions both from ordinary matter and from black holes. Indeed, in

{187}------------------------------------------------

the absence of a complete quantum theory of gravity, it is hard to imagine how a more convincing case could be made for this conclusion.

Nevertheless, some major puzzles remain. Prominent among them are the following two: (1) Underlying ordinary thermodynamics and the usual interpretation of entropy is the idea that "time average = phase average" for general dynamical systems. In view of the nature of "time" in general relativity, it is hard to see how this notion would be applicable to a system containing a black hole, and, if it is not, what idea would replace it. In addition, the fact that a black hole cannot causally influence its exterior makes it difficult to understand the underlying mechanism by which thermal equilibrium could be achieved between a black hole and a material body. (2) Why is the entropy of a black hole so simply and directly related to its horizon area, even in the nonequilibrium case? A formula of the desired type could arise if all the degrees of freedom of a black hole were concentrated in a Planck length "skin" around the horizon. Namely, if a finite number of states are assigned to each Planck volume in this region, then the logarithm of the total number of states would be proportional to A. Some ideas for how to derive such a formula for entropy have been proposed by Sorkin and collaborators (see Bombelli et al. (1986), and references cited therein; see also 't Hooft (1991, 1992)). However, these ideas run counter to the notion in classical general relativity of the black hole horizon as being a globally defined, mathematical surface, possessing no local, physical significance, and thus providing a very poor candidate for where the true dynamical degrees of freedom of a black hole should lie.

Further investigation of these issues may well represent our best opportunity to gain further insight into the nature of quantum gravity.

## 7.3 Evaporation of Black Holes and Loss of Quantum Coherence

Another striking ramification of the Hawking effect arises from consideration of "back-reaction" effects. In the (fixed, background) space-time of fig. 7.1, the energy properties of the quantum field are described semiclassically by its expected stress-energy tensor <T<sub>ab</sub>> (see section 4.6). Since the spacetime is static outside of the collapsing matter, the expected energy current

{188}------------------------------------------------

$$J_a = \langle T_{ab} \rangle t^b$$
 (7.3.1)

is conserved in that region, where  $t^b$  denotes the static Killing field of the Schwarzschild geometry. However, the particle creation calculation shows that at infinity—where the spacetime is nearly flat and, hence, normal ordering with respect to the static vacuum can be used to calculate  $<T_{ab}>$ —there will be a steady nonzero flux, F, associated with  $J^a$ . On dimensional grounds, for a massless field this flux must be of the form

$$F = \frac{\alpha}{M^2} \tag{7.3.2}$$

where  $\alpha$  is of order unity in Planck units. The value of  $\alpha$  can be estimated from the Stefan-Boltzmann flux law,  $F_{S-B}=\sigma AT^4,$  with  $T=1/(8\pi M)$  and  $A=4\pi(3\sqrt{3}M)^2,$  where  $3\sqrt{3}\,M$  is the effective radius of the black hole when "light bending" is taken into account. However, since the modes predominantly contributing to the flux have wavelength comparable to the size of the black hole, the Stefan-Boltzmann law holds only approximately, and a ("physical optics") mode sum must be done to compute  $\alpha$  exactly. Note that eq. (7.3.2) also will hold approximately for any field whose mass is small compared with the black hole temperature (7.1.9), but the flux for fields whose mass is much greater than the black hole temperature would be negligible.

By conservation of Ja, a negative energy flux equal in magnitude to (7.3.2) must flow into the black hole. Consequently, it is clear that back-reaction effects will cause the black hole to lose mass. In order to calculate these back-reaction effects in the semiclassical approximation, we would like to self-consistently solve the semiclassical Einstein equation,

$$G_{ab} = 8\pi < T_{ab} >$$
 (7.3.3)

Unfortunately, for the three reasons discussed near the end of section 4.6, this has not been done. Nevertheless, on physical grounds, one would expect that for a black hole whose mass, M, is much greater than the Planck mass,  $M_P = (c\hbar/G)^{1/2} \approx 10^{-5}$  gm, the backreaction effects will be locally small near the black hole horizon and in the entire exterior region (i.e., everywhere except very near

{189}------------------------------------------------

the singularity within the black hole). In that case, the spacetime geometry should be accurately represented by a locally Schwarzschild geometry in which M decreases slowly with time in accordance with eq. (7.3.2). Thus, considering, for simplicity, only the contribution from massless fields, we obtain

$$\frac{dM}{dt} = -F = -\frac{\alpha}{M^2} \tag{7.3.4}$$

which is easily integrated to yield

$$M(t) = (M_0^3 - 3\alpha t)^{1/3}$$
 (7.3.5)

Thus, we find that a black hole should completely "evaporate" (or, at least, reach the Planck mass, at which point this calculation certainly no longer can be trusted) in the finite time  $M_0^{3/3}\alpha$ .

A spacetime diagram depicting the process of black hole formation and evaporation is shown in fig. 7.2, under the assumption that complete evaporation occurs. The global manner in which M decreases—i.e., the region of spacetime corresponding to a particular value of M—is indicated in this figure. It should be noted (Wald 1986) that the spacetime of fig. 7.2 contrasts sharply with that of a Vaidya solution with the same mass dependence at future null infinity. In the Vaidya solution one has an everywhere positive energy flux which is locally large near the horizon, whereas in the spacetime of fig. 7.2, the energy flux is locally negative near the horizon and is locally small everywhere outside of the black hole (until the black hole reaches Planck dimensions).

One immediate, noteworthy ramification of the idea the black holes can "evaporate" due to the Hawking effect is that conservation laws for lepton and baryon number apparently can be grossly violated. Indeed, one could imagine forming a black hole with M~M<sub>o</sub> by the collapse of a neutron star, with baryon number ~10<sup>57</sup>. This baryon number should not leave any "imprint" upon the black hole exterior at late times, so when the black hole evaporates, it should do so in a baryon-antibaryon symmetric manner. If so, then the expected baryon number after black hole evaporation would be zero. Indeed, one would expect, in any case, that essentially all of the energy of the black hole would be radiated in particles which carry zero baryon number, since the black hole temperature is much less