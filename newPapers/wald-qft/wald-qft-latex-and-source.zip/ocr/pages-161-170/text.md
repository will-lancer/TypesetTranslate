

{160}------------------------------------------------

we can define  $\kappa$  and  $\Omega$  as described above. Finally, there is an additional thermodynamic quantity, the total entropy, S, which also can be defined for nonequilibrium states. Similarly, the surface area, A, of the event horizon also is defined for nonstationary black holes.

The above analogy in the framework of black hole physics and the thermodynamics of ordinary dynamical systems is not particularly striking by itself. What is quite striking, however, is the analogy between the area theorem 6.1.2 and the ordinary second law of thermodynamics, which states that the total entropy, S, never decreases with time. Now, it might appear that the nature of the area theorem and the ordinary second law could hardly be more different: The area theorem is a rigorous theorem in differential geometry applicable to predictable black holes satisfying Rabkakb≥ 0. The time asymmetry in the area theorem arises from the fact one is dealing with a future horizon, h+, rather than a past horizon. On the other hand, the ordinary second law is not believed to be a rigorous law but rather one which holds with (overwhelmingly) high probability. The time asymmetry of this law arises from a choice of (highly improbable) initial state. Nevertheless, there are very few laws of physics which involve time asymmetric behavior of a quantityallowing it to increase with time but not decrease—so the analogy between these laws should not be dismissed.

The analogy between laws of black hole physics and thermodynamics is strongly reinforced when one compares eq. (6.2.15) (or, equivalently, eq. (6.2.8)) with the ordinary first law of thermodynamics:

$$T\Delta S = \Delta E + P\Delta V \tag{6.2.23}$$

(It is worth noting that for a given thermodynamic system, one typically obtains both a "physical process" and "equilibrium state" version of this ordinary first law, although one commonly does not emphasize the fact that the consistency of these two versions supports the conjecture that all physically realistic initial states of the dynamical system asymptotically approach a thermal equilibrium state.) The term " $-\Omega\Delta J$ " in eq. (6.2.15) is closely analogous to the "work term"  $P\Delta V$  in eq. (6.2.23). Indeed, if one considers a rotating body in ordinary thermodynamics, one obtains precisely such a " $-\Omega\Delta J$ " term in the ordinary first law. Thus, eqs. (6.2.15) and (6.2.23)

{161}------------------------------------------------

have remarkably similar characters.

The analogy is further strengthened by consideration of the "zeroth law" which, in ordinary thermodynamics, states that for a body in thermal equilibrium, the temperature must be uniform over the body. Comparing eqs. (6.2.15) and (6.2.23), we see that the quantity in black hole physics which plays the role analogous to temperature, T, is the surface gravity,  $\kappa$ . As discussed above, for a stationary black hole  $\kappa$  must be uniform over the event horizon.

One formulation of the third law of ordinary thermodynamics asserts that  $S \rightarrow 0$  (or a universal constant) as  $T \rightarrow 0$ . The analog of this law is not satisfied in black hole physics, since, in particular,  $\kappa = 0$  for all "extreme"  $(J = M^2)$  Kerr black holes, which have variable  $A \neq 0$ . However, while this formulation of the ordinary third law is believed to be satisfied by all materials presently known to occur in nature, in my opinion it is not at all a fundamental aspect of thermodynamics. Indeed, there are entirely sensible models of quantum dynamical systems (such as a quantum Boltzmann gas) which violate it (see, e.g., Huang (1963) for further discussion). Thus, I do not view the failure of the analog of this law to hold in black hole physics as particularly disturbing.

There is an alternate—and much vaguer—formulation of the third law, which states that it is impossible to achieve absolute zero temperature in a finite series of processes. (I would view this statement as being, in essence, a consequence of the second law, since it is entropically highly upfavorable to remove energy from a system near absolute zero temperature.) It appears that an analog of this formulation of the third law does hold in black hole physics (see Israel (1986)).

Taken together, the above results provide a striking mathematical analogy between the laws of thermodynamics and classical black hole physics. Furthermore, there even is a hint that the analogy may have some physical content as well: The quantity in the laws of black hole physics which plays the role mathematically analogous to total energy, E, is the mass, M, of the black hole, which, in general relativity, physically is the total energy of the black hole. However, at this stage, the physical analogy ends. The quantity in black hole physics mathematically analogous to temperature, T, is the surface gravity,  $\kappa$ . In classical black hole physics,  $\kappa$  has nothing whatever to do with the physical temperature of a black hole, which is absolute zero by any reasonable criteria (such as the ability to

{162}------------------------------------------------

## 150 CHAPTER 6

run heat engines). Nevertheless, we shall see in the next chapter, that this situation changes dramatically when quantum physics is taken into account.

{163}------------------------------------------------

## 7 The Hawking Effect

In chapter 5, we saw that in extended Schwarzschild spacetime, the Hartle-Hawking vacuum state-which is uniquely characterized by being everywhere nonsingular (i.e., of Hadamard form) and invariant under the Schwarzschild time translation isometries—is a thermal state at the "Hawking temperature"  $\kappa/2\pi$ . However, we also noted there that the Hartle-Hawking state has the rather unphysical feature of having incoming thermal radiation in region I of extended Schwarzschild spacetime correlated with similar incoming radiation in region II, as well as with radiation emerging from the "white hole" singularity. It is far from clear, a priori, what the relationship is between the mathematical properties of the Hartle-Hawking state in extended Schwarzschild spacetime and the physical effects that would occur when a black hole is produced in nature by the gravitational collapse of a body. Nevertheless, we shall see in section 7.1 that the analysis of the behavior of a quantum field at sufficiently late times following gravitational collapse to a black hole is closely related mathematically to the analysis of the Unruh effect given in chapter 5. The result of the analysis is the Hawking effect: A black hole will radiate exactly like a blackbody at temperature  $\kappa/2\pi$ .

One immediate ramification of the Hawking effect is that it solidifies the relationship between black holes and thermodynamics presented in the previous chapter. The surface gravity,  $\kappa$ , is not merely a mathematical analog of temperature, it literally is the physical temperature of a black hole. This strongly suggests that one-fourth of the area of a black hole should be interpreted as its physical entropy. These ideas are discussed in section 7.2.

A further major ramification of the Hawking effect arises when one considers the back-reaction of the quantum field on the black hole. As a result of back-reaction effects, an isolated black hole should completely "evaporate" within a finite time. Although a complete analysis of this phenomenon will have to await a quantum theory of gravity, it would seem difficult to avoid the conclusion that, in this process, an initially pure quantum state will evolve to a

{164}------------------------------------------------

mixed state, i.e., "loss of quantum coherence" should occur. This ramification of the Hawking effect is explored in section 7.3.

## 7.1 Particle Creation by Black Holes

We wish to consider quantum field effects in a spacetime corresponding to the gravitational collapse of a body to form a black hole. For simplicity, we shall restrict attention to the case of spherically symmetric collapse to a Schwarzschild black hole. As we shall argue later, the behavior of the quantum field at asymptotically late times depends only upon the asymptotic final state of the black hole, so a nonspherical collapse producing a black hole which merely "settles down" to a Schwarzschild black hole at late times would yield the same results. The modifications to the analysis occurring for the case of collapse to a Kerr black hole (where the phenomenon of "superradiance" occurs) will not be discussed here, but can be found in Hawking (1975) and Wald (1975).

The spacetime geometry corresponding to the gravitational collapse of an initially static, spherical body to a Schwarzschild black hole is shown in fig. 7.1. Since the spacetime geometry is (by assumption) spherically symmetric, by Birkhoff's theorem, the region exterior to the body is isometric to a portion of extended Schwarzschild spacetime. Note, however, that this exterior region corresponds to only a part of regions I and III of fig. 5.3, and analogs of regions II and IV of that figure are entirely absent from fig. 7.1. In particular, no analog of the past horizon,  $\mathbf{h}_{B}$ , appears in fig. 7.1.

![](_page_164_Figure_6.jpeg)

Figure 7.1. A conformal diagram of a spacetime in which a spherical body undergoes collapse to a Schwarzschild black hole.

{165}------------------------------------------------

Consider, now, a Klein-Gordon quantum field in the spacetime of fig. 7.1. Since this spacetime is asymptotically static in the past, we have a natural quantum field theory construction—the "in" representation—which is obtained in the manner described at the end of section 4.3. States in the Fock space of the "in" representation have a natural particle interpretation in the asymptotic past.

Although the spacetime of fig. 7.1 also is static in region I in the asymptotic future, the static portion of region I does not contain a Cauchy surface for the spacetime, since any Cauchy surface must pass through the collapsing matter. Consequently, the construction of the "out" representation is less straightforward, and we proceed as follows: First, we assume that in the asymptotic future, each  $\psi \in \mathcal{S}$  propagates entirely through the black hole horizon,  $h_A$ , and/or out to infinity. This "asymptotic completeness" assumption is supported by analyses of scattering in Schwarzschild spacetime (Dimock and Kay (1987); see also Wald (1984a)) but, as far as I am aware, has been rigorously proven only in the massless case (Dimock 1985). We then focus attention upon a subspace, &L, of &, comprised by solutions which propagate into the black hole and/or to infinity at sufficiently "late times". For the spacetime of fig. 7.1, we make the following choice of &L: Let  $\Sigma$  be any Cauchy surface which intersects the event horizon outside of the collapsing matter and let &1 consist of the solutions in & whose data on  $\Sigma$  have support outside the black hole. (In the more general case where the spacetime geometry merely "settles down" to a Schwarzschild final state,  $\Sigma$ should be chosen so that the spacetime geometry has approached its Schwarzschild final state throughout the future of  $\Sigma$  in region I, so that the spacetime can be considered to be static when solutions in & propagate into the black hole and/or to infinity.) We define the "early time" subspace, & E, of &, to be the symplectic complement of  $\mathcal{S}_{\perp}$  in  $\mathcal{S}_{\perp}$ , so that  $\mathcal{S}_{\vdash}$  consists of solutions in  $\mathcal{S}_{\perp}$  whose data on  $\Sigma$  have support inside the black hole. As we shall see below, the solutions in & will play a role in our analysis similar to the role played by solutions in region II of Minkowski spacetime in the derivation of the Unruh effect.

Since the portion of the spacetime of fig. 7.1 outside the collapsing matter is isometric to a portion of extended Schwarzschild spacetime, we may identify each solution in & with the solution in extended Schwarzschild spacetime which has the same initial data on a Cauchy surface  $\widetilde{\Sigma}$  of extended Schwarzschild spacetime which

{166}------------------------------------------------

coincides with  $\Sigma$  in region I under the identification provided by the isometry relating the two spacetime regions. Given  $\psi_{\perp} \in \mathcal{S}_{\perp}$ , we denote the corresponding solution in extended Schwarzschild spacetime by  $\widetilde{\psi}_L$ . We define the "out" representation to be such that for all  $\psi_{\perp} \in \mathcal{S}_{\perp}$ , the associated "mode function",  $K\psi_{\perp}$ , in the one-particle Hilbert space, % out, is the solution in the spacetime of fig. 7.1 which corresponds to the positive frequency part (with respect to Schwarzschild time translations) of  $\tilde{\psi}_1$  in extended Schwarzschild spacetime. (Note that the positive frequency part of  $\tilde{\psi}_L$  in extended Schwarzschild spacetime will have a small "tail" which propagates into the black hole at "early times," resulting in some ambiguity in identifying it with a solution in the spacetime of fig. 7.1. However, for solutions  $\psi_1 \in \mathcal{S}_1$  which propagate into the black hole or out to infinity at sufficiently late times, this "tail"—and hence this ambiguity in identification—becomes arbitrarily small.) We denote by  $\Re_{\perp}$ the (complex) subspace, K&L, of % out spanned by the mode functions associated with &<sub>L</sub>. We extend K to & and we write  $\Re$ <sub>E</sub> = K&<sub>E</sub>. We shall leave the choice of extension of K to & unspecified for the present, but in the course of our analysis below we will make a convenient choice of  $K\psi_E$  for certain  $\psi_E \in \mathcal{S}_E$ . It should be emphasized that the "out" representation Fock space we have just defined has a physically meaningful particle interpretation for modes in % (with respect to measurements by static observers in the future), but no meaningful particle interpretation is claimed for modes in % E.

We wish, now, to compute the S-matrix,  $U:\mathfrak{F}_s(\mathfrak{K}_{in}) \to \mathfrak{F}_s(\mathfrak{K}_{out})$  relating the "in" and "out" representations. In particular, we wish to calculate  $U|0_{in}>$ . The density matrix in  $\mathfrak{F}_s(\mathfrak{K}_L)$  corresponding to  $U|0_{in}>$  will then tell us about the spontaneous creation of particles as seen by static observers at late times. We shall give a sketch of the calculation of  $U|0_{in}>$  along the lines of the original derivation (Hawking 1975, Wald, 1975) and then will describe an improved framework for analyzing this effect.

The relevant information needed to compute the density matrix in  $\mathfrak{F}_s(\mathfrak{R}_L)$  corresponding to UIO\_in> can be obtained by starting with solutions in  $\mathfrak{R}_L$  (which, as described above, are "positive frequency" in region I in the future), propagating them into the past, and decomposing them into their positive and negative frequency parts there. We now assume the same "asymptotic completeness" property in extended Schwarzschild spacetime for the propagation of classical solutions into the past as we assumed above for the propagation of

{167}------------------------------------------------

classical solutions into the future in the spacetime of fig. 7.1, i.e., we assume that in the asymptotic past, all solutions in extended Schwarzschild spacetime propagate entirely into the white hole and/or out to infinity. We then may further decompose  $\Re_L \subset \Re_{out}$  as

$$\mathfrak{H}_{L} = \mathfrak{H}_{\mathsf{wh}} \oplus \mathfrak{H}_{-\infty} \tag{7.1.1}$$

where  $\Re_{wh}$  consists of solutions,  $\psi_L$ , which are positive frequency in the future and whose corresponding solution  $\widetilde{\psi}_L$  in extended Schwarzschild spacetime propagates entirely through the "white hole" horizon in the past. Similarly,  $\Re_{-\infty}$  consists of solutions,  $\psi_L \in \Re_L$ , such that the corresponding solution  $\widetilde{\psi}_L$  propagates entirely to infinity in the asymptotic past. Now, apart from a "tail" which becomes arbitrarily small at late times, the solutions in  $\Re_{-\infty}$  never propagate into the nonstatic region of the spacetime of fig. 7.1, i.e., their propagation is exactly the same as occurs in extended Schwarzschild spacetime. It follows immediately that for all  $\psi_{-\infty} \in \Re_{-\infty}$ , there is no "mixing of frequencies", so we have

$$DC^{-1}\psi_{-\infty} = 0$$
 (7.1.2)

This implies that no particle creation occurs in modes corresponding to  $\mathfrak{R}_{-\infty}$ . Note that this contrasts sharply with the properties of the Hartle-Hawking vacuum state of extended Schwarzschild spacetime, in which all modes in region I (including those corresponding to  $\mathfrak{R}_{-\infty}$ ) are thermally populated.

Consider, now, the propagation of a solution  $\psi_{wh} \in \Re_{wh}$  in the spacetime of fig. 7.1 such that  $\psi_{wh}$  emerges to infinity and/or enters the black hole at sufficiently late times in the future. (Note that since  $\psi_{wh} \in \Re_{wh} \subset \Re_{L}$ ,  $\psi_{wh}$  automatically emerges to infinity and/or enters the black hole at "late times", i.e., within the static Schwarzschild region of the spacetime of fig. 7.1. By "sufficiently late times", we mean at sufficiently large values of Killing parameter within this static region.) When evolved backwards into the past,  $\psi_{wh}$  will propagate through the collapsing matter and emerge in the asymptotic past as an ultra-high-frequency solution. (One way of seeing this is that if one considers the "time translates" of  $\psi_{wh}$  to increasingly later times, the "blueshift" of these solutions as determined by any fixed, smooth family of observers falling into the black hole continues to increase, but the subsequent "redshift" re-

{168}------------------------------------------------

sulting from their continued propagation through the collapsing matter approaches a finite limit.) We wish to decompose  $\psi_{wh}$  into its positive and negative frequency parts in the asymptotic past. The key result needed to do so is the following: The positive and negative frequency decomposition of  $\psi_{wh}$  in the asymptotic past in the spacetime of fig. 7.1 is the same as the decomposition of the corresponding solution,  $\tilde{\psi}_{wh}$ , in extended Schwarzschild spacetime, where "positive and negative frequencies" are defined with respect to affine parameter along the white hole horizon, h.B. This follows from the fact that the geometrical optics approximation can be used to determine the propagation of  $\psi_{wh}$  into the asymptotic past starting from the Schwarzschild region just outside the collapsing matter, since  $\psi_{wh}$  is "ultra-high-frequency" throughout this region. Consequently, in this region, the surfaces of constant phase of the wave will be null. The propagation of the "pattern" of the wave will be governed by the geodesic deviation equation applied to the congruence of null geodesics which generate the surfaces of constant phase, and the above result then follows (see Hawking (1975) or Wald (1984a) for further details). Now,  $\widetilde{\psi}_{wh}$  is purely positive frequency with respect to Schwarzschild time translations, so, to complete the calculation, we simply need the relationship between the positive and negative frequency decompositions of functions on the white hole horizon, h, of extended Schwarzschild spacetime, with respect to "Killing time" and "affine time". This, of course, was the key ingredient which entered our analysis of the Unruh ef-From eqs. (5.1.20) and (5.1.21) and their generalization described in section 5.3, we see that if  $\tilde{\psi}_{wh}$  is peaked sharply around the frequency  $\omega > 0$ , then in extended Schwarzschild spacetime the solutions

$$\widetilde{\Psi}_{\omega} = \widetilde{\psi}_{\text{wh}} + \exp(-\pi\omega/\kappa) \ \overline{\widetilde{\psi}}_{\text{II}}$$
 (7.1.3)

and

$$\widetilde{\Psi}'_{\omega} = \widetilde{\psi}_{II} + \exp(-\pi\omega/\kappa) \ \overline{\widetilde{\psi}}_{wh}$$
 (7.1.4)

are purely positive frequency with respect to affine parameter on the white hole horizon,  $h_B$ , where  $\widetilde{\psi}_{II}$  is the solution (whose initial data has support in region II of extended Schwarzschild spacetime) obtained by applying the "wedge reflection" isometry to  $\widetilde{\psi}_{wh}$ , followed by complex conjugation. Consequently, in the spacetime of fig. 7.1, the solutions

{169}------------------------------------------------

$$\Psi_{\omega} = \psi_{\text{wh}} + \exp(-\pi \omega/\kappa) \ \overline{\psi}_{\text{II}} \tag{7.1.5}$$

$$\Psi'_{\omega} = \psi_{II} + \exp(-\pi\omega/\kappa) \overline{\psi}_{wh}$$
 (7.1.6)

are purely positive frequency in the asymptotic past, where  $\psi_{\rm II}$  is the solution corresponding to  $\widetilde{\psi}_{\rm II}$  in the "asymptotic future" (inside the black hole). Note that in the spacetime of fig. 7.1,  $\psi_{\rm II}$  enters the black hole at "early times".

It is convenient, now, to define the "early time mode" subspace,  $\Re_E$ , of the "out" one-particle Hilbert space,  $\Re_{out}$ , to be such that for all  $\psi_{wh}$  which emerge to infinity and/or enter the black hole at asymptotically late times, we have  $\psi_{II} \in \Re_E$ . (The final results for the density matrix on  $\Im_s(\Re_L)$  do not depend on this choice.) Then from eqs. (7.1.5) and (7.1.6) we find that—exactly as in the derivation of eqs. (5.1.24) and (5.1.25) above—for any  $\psi_{wh} \in \Re_L$  which is peaked sharply around frequency  $\omega > 0$ , we have

$$DC^{-1}\psi_{wh} = \exp(-\pi\omega/\kappa) \overline{\psi}_{II}$$
 (7.1.7)

$$DC^{-1}\psi_{II} = exp(-\pi\omega/\kappa) \ \overline{\psi}_{Wh} \eqno(7.1.8)$$

Consequently, by an exact repetition of the steps which led to eq. (5.1.28), we obtain the following remarkable conclusion, known as the Hawking effect: The state  $U/O_{in}$  is a thermal state at the Hawking temperature  $T=\kappa/2\pi$  with respect to modes in  $\Re_{wh}$  which emerge to infinity at asymptotically late times. It is a vacuum state with respect to modes in  $\Re_{-\infty}$ .

These conclusions can be formulated more succinctly by stating simply that, at late times, a Schwarzschild black hole formed by gravitational collapse radiates precisely as a thermal blackbody at temperature

$$kT = \kappa/2\pi = \frac{\hbar c^3}{8\pi GM}$$
 (7.1.9)

Namely, the modes in  $\Re_{-\infty}$  correspond to particles which appear to have propagated in from infinity at late times; these particle states are unpopulated. On the other hand, the modes in  $\Re_{wh}$  correspond to particles emanating from the white hole in the extended Schwarzschild spacetime. In the spacetime of fig. 7.1, these particles would appear to be emerging from the region where the black