

{20}------------------------------------------------

as its total energy. However, the physical relationship breaks down beyond this point in classical theory, since, clearly, the physical temperature of a black hole in classical general relativity is absolute zero.

## 1.3 The Hawking Effect and its Ramifications

The gravitational collapse of a body to form a black hole is a violent event, so it would be expected that in quantum field theory, particle creation should occur in the strongly time-dependent gravitational field associated with the collapse. Particle creation effects occurring at "late times" after the black hole has "settled down" to its stationary final state also would be expected in the case of a rotating or charged black hole, where energy extraction is possible classically. However, it came as a great surprise when an analysis by Hawking (1975) showed that particle creation also occurs at "late times" following the collapse of a body to a nonrotating, uncharged black hole. It came as an even greater surprise that this radiation which, in effect, is "emitted" by the black hole, has a remarkably simple and familiar form: It corresponds to perfectly thermal, "blackbody" radiation, at temperature kT =  $\kappa/2\pi$ , where  $\kappa$ denotes the surface gravity of the black hole. We shall present the derivation of this result in section 7.1.

The Hawking effect is closely related mathematically to an effect subsequently discovered by Unruh (1976), who found that an accelerating observer in flat spacetime feels himself to be immersed in a thermal bath of particles at temperature  $kT = a/2\pi$ (where a denotes the acceleration of the observer) when the quantum field is in its vacuum state as determined by inertial observers. More precisely, the inertial vacuum state of Minkowski spacetime is a thermal ("KMS") state when analyzed with respect to the notion of "time translations" defined by a one-parameter family of Lorentz boosts. (The orbits of these Lorentz boost isometries correspond to a family of uniformly accelerating observers.) This result-known as the "Unruh effect"—is actually a consequence of the fact that the Lorentz boost isometries possess a Killing horizon, i.e., a null surface to which the Killing field generating the isometries is normal. The Unruh effect has a generalization to curved spacetimes possessing a one-parameter group of isometries which have an associated Killing horizon. The close mathematical relationship between the Unruh effect and the Hawking effect stems from the fact that the

{21}------------------------------------------------

event horizon of a stationary black hole is a Killing horizon. We shall analyze the Unruh effect and its generalization to curved spacetimes in detail in chapter 5.

An important, immediate consequence of the Hawking effect is that it puts the analogy between the laws of black hole mechanics and the laws of thermodynamics on a firm physical foundation: The surface gravity of a black hole-which plays a role mathematically analogous to temperature-is now seen to be the physical temperature of the black hole in a completely literal sense. Furthermore, the Hawking effect and other closely related quantum effects make viable the "generalized second law of thermodynamics", which asserts that the total entropy of matter outside black holes plus 1/4 the surface area of all black holes never decreases with time. suggests that the laws of black hole mechanics literally are the ordinary laws of thermodynamics applied to a system containing a black hole. However, the manner in which these laws might arise from a statistical mechanics based upon a complete quantum theory of gravity remains a mystery. The ramifications of the Hawking effect for black hole thermodynamics and the generalized second law will be discussed in detail in section 7.2.

An important further ramification of the Hawking effect concerns an issue posed when "back-reaction" of the quantum field on the black hole is taken into account. Clearly, if total energy is to be conserved, the black hole must lose mass as it emits radiation via the particle creation process. A simple estimate indicates that a black hole should radiate all of its mass—and, thus, "evaporate" completely—within a finite time. Since the black hole emits radiation in a thermal (and, thus, highly mixed) state, it would appear that in the process of black hole formation and evaporation, an initial pure quantum state can evolve to a mixed state. This raises some issues of principle concerning the nature of quantum theory, which presently continue to remain at the center of considerable discussion and debate. The phenomenon of black hole evaporation and the consequent "loss of quantum coherence" will be discussed in section 7.3.

{22}------------------------------------------------

## 2 Quantum Mechanical Preliminaries

Our formulation of quantum field theory in curved spacetime will be based directly upon the quantum mechanics of systems satisfying linear equations of motion, i.e., harmonic oscillators. the only important difference between a linear (i.e., non-selfinteracting) field in curved spacetime and a collection of ordinary harmonic oscillators (with possibly time dependent masses and spring constants) is that the field system has infinitely many degrees of freedom. The main goal of this chapter is to reformulate some standard results from the quantum mechanics of harmonic oscillator systems in a manner that will enable us, in the next two chapters, to give a direct formulation of quantum field theory in flat and curved spacetimes. We shall begin with a very brief discussion of the classical mechanics of nonlinear systems with finitely many degrees of freedom, so that we may introduce the symplectic form in a general setting. Then we shall specialize to linear systems, and will write the quantum theory of a collection of harmonic oscillators in a manner that brings to the fore both the role of the symplectic vector space structure of the classical solutions and the freedom available in making a choice of "one-particle Hilbert space". Although the material covered in this chapter is entirely elementary in the sense that the quantum theory we construct is the same as can be found in any introductory text on nonrelativistic quantum mechanics, some aspects of our discussion and notation will be unconventional (within this quantum mechanical setting). It is hoped, thereby, that this chapter will afford a useful link between ideas with which the reader undoubtedly is very familiar and the construction of quantum field theory in curved spacetime given in the subsequent chapters of these notes.

## 2.1 Classical Dynamics of Particle Systems

The quantum theory of a system composed of finitely many particles (or, more generally, any system with finitely many degrees

{23}------------------------------------------------

of freedom) is based directly upon the structure present in the Hamiltonian formulation of the classical theory. In this section, we review the key elements of this classical structure.

The reader undoubtedly is familiar with classical Hamiltonian mechanics in the manner presented in most introductory textbooks. In such treatments, it normally is assumed that the state of a classical system with finitely many degrees of freedom is characterized by n "generalized coordinates",  $q_1,...,q_n$ , (describing its "configuration") together with n corresponding "conjugate momenta",  $p_1,...,p_n$ . The collection of all possible values of coordinates and momenta,  $(q_1,...,q_n; p_1,...,p_n)$ , is referred to as *phase space*. Dynamical evolution on phase space is then determined by specifying a Hamiltonian function,  $H = H(q_1,...,q_n; p_1,...,p_n)$ , and imposing Hamilton's equations of motion,

$$\frac{dq_{\mu}}{dt} = \frac{\partial H}{\partial p_{\mu}}, \frac{dp_{\mu}}{dt} = -\frac{\partial H}{\partial q_{\mu}}$$
 (2.1.1)

We can express these equations more succinctly by writing  $y=(q_1,\ldots,q_n;\ p_1,\ldots,p_n)$  and introducing the antisymmetric  $2n\times 2n$  matrix  $\Omega^{\mu\nu}$ , with  $\Omega^{\mu\nu}=1$  when  $\nu=\mu+n$  and  $\Omega^{\mu\nu}=0$  when  $|\mu-\nu|\neq n$ . We obtain, for  $\mu=1,\ldots,2n$ ,

$$\frac{dy^{\mu}}{dt} = \sum_{\nu=1}^{2n} \Omega^{\mu\nu} \frac{\partial H}{\partial y^{\nu}}$$
 (2.1.2)

It is not too large a jump to go from Hamilton's equations in the form (2.1.2) to the much more general and abstract formulation of Hamiltonian mechanics given, e.g., in (Arnold 1989), in which the essential mathematical structure which is needed to define the theory can be seen more clearly. In this more abstract formulation, states of a classical system with n degrees of freedom are represented by points in a 2n-dimensional manifold,  $\mathfrak{M}$ , which we continue to refer to as phase space. The fundamental structure on  $\mathfrak{M}$  needed to formulate Hamiltonian mechanics is a symplectic form,  $\Omega_{ab}$ , by which is meant a nondegenerate, closed, 2-form on  $\mathfrak{M}$ . In other words,  $\Omega_{ab}$  is a tensor field of type (0,2) on  $\mathfrak{M}$  such that,  $\Omega_{ab} = \Omega_{[ab]}$ ,  $\nabla_{[a}\Omega_{bc]} = 0$ , (where square brackets denote antisymmetrization) and for any tangent vector  $\mathbf{v}^b$  on  $\mathfrak{M}$ , we have  $\Omega_{ab}\mathbf{v}^b = 0$  if and only if  $\mathbf{v}^b = 0$ . The nondegeneracy of  $\Omega_{ab}$  implies that it has a unique inverse,

{24}------------------------------------------------

denoted  $\Omega^{ab}$ , satisfying  $\Omega^{ab}$   $\Omega_{bc}=\delta^a{}_c$ . The Hamiltonian, H, of the system is viewed as a function on  $\mathbb{M}$ , i.e., H: $\mathbb{M}\to\mathbb{R}$ . The Hamiltonian vector field, ha, on  $\mathbb{M}$ , is defined in terms of H and the inverse symplectic form by

$$h^{a} = \Omega^{ab} \nabla_{b} H \qquad (2.1.3)$$

Hamilton's equations of motion then correspond to the statement that the dynamically possible motions on phase space are those which correspond to integral curves of  $h^a$  on  $\mathfrak M$ .

The relationship between the two formulations of Hamilton's equations of motion described above can be seen as follows: We can pass from the standard treatment of Hamiltonian mechanics to the more abstract formulation by viewing the configuration variables,  $(q_1,...,q_n)$ , as local coordinates on an n-dimensional manifold,  $q_i$ , corresponding to the configuration space of the system. The phase space, M, appearing in the more abstract treatment then corresponds to the cotangent bundle of  $\mathfrak{P}_{0}$ , i.e.,  $\mathfrak{M}_{\bullet} = T_{\bullet}(\mathfrak{P}_{0})$ . (Here, the cotangent bundle,  $T_*(\mathfrak{N})$ , of any n-dimensional manifold,  $\mathfrak{N}$ , is defined to be the 2n-dimensional manifold comprised by all points, x, of N together with all cotangent (i.e., dual) vectors at x; see any text on differential geometry for further discussion.) The local coordinates  $(q_1,...,q_n)$  on q give rise to natural local coordinates  $(q_1,...,q_n; p_1,...,p_n)$  on  $\mathfrak{M}$  by taking  $(p_1,...,p_n)$  to be the components of the cotangent vectors in the coordinate basis associated with  $(q_1,...,q_n)$ . The symplectic form,  $\Omega_{ab}$ , on  $\mathfrak{N}$ , then may be defined by

$$\Omega_{ab} = 2 \sum_{\mu} (\nabla p_{\mu})_{[a} (\nabla q_{\mu})_{b]}$$
 (2.1.4)

or, equivalently, in the notation of differential forms,

$$\Omega = \sum_{\mu} dp_{\mu} \wedge dq_{\mu} \tag{2.1.5}$$

We define  $\Omega^{ab}$  and  $h^a$  as above. It then may easily be checked that for a curve y(t) whose tangent coincides at every point with  $h^a$ , the components of eq. (2.1.3) in the coordinates  $(q_1,...,q_n; p_1,...,p_n)$  yield precisely eq. (2.1.2). It also is easily checked that the tensor field,  $\Omega_{ab}$ , on  $\mathfrak{M}$  defined by eq. (2.1.4) does not depend upon the choice of

{25}------------------------------------------------

local coordinates on  $\P$ . Thus, eq. (2.1.3) has the advantage of yielding a form of Hamilton's equations of motion that is independent of the choice of "generalized coordinates" on  $\P$ . Note also that eq. (2.1.3) shows that Hamilton's equations actually retain the form (2.1.2) in any system of coordinates on  $\P$ , for which  $\Omega_{ab}$  takes the form (2.1.4), including systems of coordinates which "mix" the original q's and p's.

Conversely, to pass from the abstract formulation of Hamiltonian mechanics to the more standard treatment, we note that given a 2n-dimensional manifold, M, (not necessarily expressed as the cotangent bundle of a configuration space, &) together with a symplectic form,  $\Omega_{ab}$ , the Darboux theorem states that it always is possible locally to choose coordinates  $(q_1,...,q_n; p_1,...,p_n)$  on  $\mathfrak{N}$  so that  $\Omega_{ab}$  takes the form (2.1.4). (Any such coordinates are referred to as canonical coordinates on M.) Thus, locally at least, the formulation of Hamiltonian mechanics associated with eq. (2.1.3) is completely equivalent to the usual formulation associated with eqs. (2.1.1) or (2.1.2). The primary advantage of the abstract formulation is that it deflects attention away from the inessential features of the usual formulation of classical mechanics (such as the choice of canonical coordinates) and focuses attention upon the relevant geometrical structure of the theory. The key quantity in this geometrical structure is the symplectic form,  $\Omega_{ab}$ , and this symplectic form will play a central role in our constructions below.

It follows immediately from eq. (2.1.3) that the specification of a point in  $\mathfrak R$  is appropriate initial data for determining a solution to Hamilton's equations of motion, i.e., each point, y, of  $\mathfrak R$  gives rise to a unique solution to the dynamical evolution equations such that the initial data at t=0 corresponds to y. We therefore may identify phase space,  $\mathfrak R$ , with the manifold,  $\mathcal S$ , of solutions to the equations of motion. We shall freely make use of this correspondence below.

Observables in classical mechanics are represented by real-valued functions on  $\mathfrak{M}$ , i.e., an observable, f, is a map, f:  $\mathfrak{M} \to \mathbb{R}$ , which we will assume to be smooth  $(\mathsf{C}^{\scriptscriptstyle\infty})$ . The set of all observables, 0, has a natural (infinite dimensional) vector space structure. Furthermore, the inverse symplectic form,  $\Omega^{ab}$ , gives rise to an algebraic (i.e., "product") structure on the vector space of observables, called the *Poisson bracket*, which is defined by

$$\{f,g\} = \Omega^{ab} \nabla_a f \nabla_b g \qquad (2.1.6)$$

{26}------------------------------------------------

The Poisson bracket is manifestly antisymmetric, and it is not difficult to show that it satisfies the Jacobi identity by virtue of the closedness of  $\Omega_{ab}$ .

Since the canonical coordinates  $q_\mu$ ,  $p_\nu$ , are, of course, functions on  $\mathfrak{M}$ , they may be viewed as observables. Indeed, these observables are "fundamental" in the sense that all other observables are functions of them. By eqs. (2.1.4) and (2.1.6), the Poisson bracket of these fundamental observables is given by

$$\{q_{\mu}, q_{\nu}\} = \{p_{\mu}, p_{\nu}\} = 0$$
 (2.1.7)

$$\{q_{\mu}, p_{\nu}\} = \delta_{\mu\nu}$$
 (2.1.8)

Our attention in these lectures will be focused almost exclusively on "linear dynamical systems". More precisely, we shall consider systems for which the following two properties hold. (1) We have  $\mathfrak{M}=T_*(\mathfrak{P}_s)$ , where  $\mathfrak{P}_s$  has the natural structure of a vector space. In that case, we can choose a basis of  $\mathfrak{P}_s$ , and use the basis components of the vectors in  $\mathfrak{P}_s$  to define "linear coordinates",  $(q_1,\ldots,q_n)$ , globally on  $\mathfrak{P}_s$ . These coordinates then give rise to globally well defined linear canonical coordinates  $(q_1,\ldots,q_n;\,p_1,\ldots,p_n)$  on  $\mathfrak{M}_s$  such that eq. (2.1.4) holds. (2) The Hamiltonian, H, is a quadratic function on  $\mathfrak{M}_s$ , so that the equations of motion, (2.1.1), are linear in the linear canonical coordinates. In that case, the manifold of solutions,  $\mathfrak{F}_s$ , also acquires a natural vector space structure.

Note that a linear dynamical system is thus simply a collection of coupled harmonic oscillators (possibly with time-dependent and/or negative masses and spring constants). As already mentioned above, a linear field in curved spacetime, is, in essence, an infinite collection of such harmonic oscillators.

A key consequence of property (1) is that it allows us to view the symplectic form,  $\Omega_{ab}$ , in the following manner. On account of the vector space structure of  $\mathfrak{M}$ , we may identify the tangent space at any point  $y_{\in}\,\mathfrak{N}$  with  $\mathfrak{M}$  itself. Under this identification, the symplectic form,  $\Omega_{ab}$ , becomes a bilinear function,  $\Omega\colon \mathfrak{M}\times \mathfrak{M}\to \mathbb{R}$ , on  $\mathfrak{M}$ . Furthermore, since, by eq. (2.1.4), the components of  $\Omega_{ab}$  are constant in the linear canonical coordinate basis, this bilinear map,  $\Omega_{\cdot}$  is independent of the choice of point y used to make the identification. We shall refer to  $\Omega$  as a symplectic structure on  $\mathfrak{M}$ . For  $y_1,y_2\in \mathfrak{M}$ ,  $\Omega$  is given explicitly by

{27}------------------------------------------------

$$\Omega(y_1,\ y_2) = \sum_{\mu} [p_{1\mu} q_{2\mu} - p_{2\mu} q_{1\mu}] \eqno(2.1.9)$$

In this way, the phase space of a linear dynamical system, may be naturally viewed simply as a symplectic vector space,  $(\mathfrak{M}, \Omega)$ —i.e., a vector space,  $\mathfrak{M}$ , on which is defined a nondegenerate, antisymmetric, bilinear map,  $\Omega$ —rather than as a symplectic manifold,  $(\mathfrak{M}, \Omega_{ab})$ .

For a system satisfying property (1), we may use the symplectic structure,  $\Omega$ , to, in effect, replace the linear canonical coordinates  $(q_1,...,q_n;\,p_1,...,p_n)$  as follows: Fix  $y\in\mathbb{N}$ . Then, we may view the quantitiy  $\Omega(y,\cdot)$  as a linear function on  $\mathbb{N}$ . If we choose  $y=(0,...,0,\,q_\mu=1,0,...,0)$ , then by eq. (2.1.9) we see that  $\Omega(y,\cdot)$  is just the function whose value at an arbitrary point of  $\mathbb{N}$  is  $-p_\mu$ , where " $p_\mu$ " is the value of the  $\mu^{th}$  momentum coordinate. Similarly, it is easily checked that for  $y=(0,...,0,\,p_\mu=1,0,...,0)$ , we have  $\Omega(y,\cdot)=q_\mu$ . It follows that the collection of functions of the form  $\Omega(y,\cdot)$ , with y ranging over  $\mathbb{N}$ , correspond to arbitrary linear combinations of the linear canonical coordinates  $(q_1,...,q_n;\,p_1,...,p_n)$ . Thus, we may rewrite any relations involving the linear canonical coordinates in terms of the functions  $\Omega(y,\cdot)$ . In particular, the Poisson bracket relations (2.1.7)-(2.1.8) are equivalent to the single relation,

$$\{\Omega(y_1,\cdot), \Omega(y_2,\cdot)\} = -\Omega(y_1, y_2)$$
 (2.1.10)

It may seem to the reader that eq. (2.1.10) does little more than express the perfectly satisfactory and familiar relations (2.1.7)-(2.1.8) in a much more obscure form. However, even in the finite dimensional case considered here, eq. (2.1.10) has a notable advantage over (2.1.7)-(2.1.8) in that it allows us to write down the fundamental Poisson bracket relations without requiring us to make a particular choice of linear canonical coordinates on  $\mathfrak{M}$ . More importantly, when we treat fields in curved spacetime (for which  $\mathfrak{M}$  is infinite dimensional), it is far from clear how to generalize the relations (2.1.7)-(2.1.8) in such a way as to define the Poisson bracket on a natural class of linear functions on  $\mathfrak{M}$ . On the other hand, the Poisson bracket relation in the form (2.1.10) generalizes straightforwardly to the infinite dimensional case. Consequently, in these notes, we will work almost exclusively with the functions  $\Omega(y,\cdot)$  as the fundamental observables on  $\mathfrak{M}$ , and the reader is urged to be-

{28}------------------------------------------------

come familiar and comfortable with the notation used in eq.(2.1.10).

Only property (1) of linear dynamical systems has been used thus far. We now explore some consequences of property (2), which states that the Hamiltonian function, H, on  $\mathfrak M$  at any time t takes the form

$$H(t; y) = \frac{1}{2} \sum_{\mu,\nu} K_{\mu\nu}(t) y^{\mu} y^{\nu}$$
 (2.1.11)

where  $y^{\mu}$  denotes the linear canonical coordinates,  $(q_1,...,q_n;\ p_1,...,p_n)$ , of point y, and where, without loss of generality, we take  $K_{\mu\nu}=K_{\nu\mu}$ . By eq. (2.1.2), Hamilton's equations of motion are

$$\frac{dy^{\mu}}{dt} = \sum_{\rho,\nu} \Omega^{\mu\rho} K_{\rho\nu} y^{\nu} \qquad (2.1.12)$$

Now, let  $y_1(t)$ ,  $y_2(t)$  be two solutions of the equations of motion (2.1.12) and let

$$s(t) = \Omega(y_1(t), y_2(t))$$

$$= \sum_{\alpha, \beta} \Omega_{\alpha\beta} y_1^{\alpha} y_2^{\beta}$$
(2.1.13)

Then, we have

$$\begin{split} \frac{ds}{dt} &= \sum_{\alpha,\beta} \Omega_{\alpha\beta} \Big[ \frac{dy_1^{\alpha}}{dt} \ y_2^{\beta} + y_1^{\alpha} \frac{dy_2^{\beta}}{dt} \Big] \\ &= \sum_{\alpha,\beta,\rho,\nu} \Omega_{\alpha\beta} \Big[ \Omega^{\alpha\rho} \, \mathsf{K}_{\rho\nu} \, y_1^{\nu} \, y_2^{\beta} + \Omega^{\beta\rho} \, \mathsf{K}_{\rho\nu} y_2^{\nu} \, y_1^{\alpha} \Big] \\ &= - \sum_{\beta,\nu} \mathsf{K}_{\beta\nu} y_1^{\nu} y_2^{\beta} \ + \sum_{\alpha,\nu} \mathsf{K}_{\alpha\nu} y_2^{\nu} y_1^{\alpha} \\ &= 0 \end{split} \tag{2.1.14}$$

Thus, for a linear dynamical system, the "symplectic product", s, of two solutions is conserved. (This result is really a consequence of the much more general fact for nonlinear systems that dynamical evolution defines a canonical transformation on phase space.) Thus, the symplectic structure,  $\Omega: \mathbb{M} \times \mathbb{M} \to \mathbb{R}$ , on  $\mathbb{M}$  gives rise to a natural

{29}------------------------------------------------

symplectic structure (also denoted  $\Omega$ ) on the vector space of solutions, &, since the symplectic structure on & obtained by identifying  $\mathfrak{N}$ , and & does not depend upon the choice of "initial time" t=0 under which the identification is made. The explicit form of  $\Omega$  on & can be obtained by expressing  $p_{\mu}$  as a function of the q's and their time derivatives via Hamilton's equations of motion (2.1.1), and then substituting the result in eq. (2.1.9).

The symplectic vector space structure  $(\mathcal{S},\Omega)$  of the manifold of solutions for a linear dynamical system is the fundamental classical structure that underlies the construction of the quantum theory of a linear field.

## 2.2 Quantum Mechanics

The mathematical framework of quantum mechanics differs drastically from classical mechanics: A state in quantum theory is represented by a vector in an infinite dimensional Hilbert space,  $\mathfrak F$ , rather than being represented by a point in a finite dimensional manifold  $\mathfrak M$ . An observable in quantum theory is represented as a self-adjoint operator acting on  $\mathfrak F$ , rather than being represented by a real-valued function on  $\mathfrak M$ . Finally, dynamical evolution is given by a one-parameter family of unitary transformations on  $\mathfrak F$  generated by a Hamiltonian operator, rather than being given by a one-parameter family of canonical transformations on  $\mathfrak M$  generated by a Hamiltonian function via eq. (2.1.3).

The key issue in the construction of a quantum theory corresponding to a classical system is how to choose the Hilbert space  $\mathfrak F$  and the self-adjoint operators  $\hat{f}_i \colon \mathfrak F \to \mathfrak F$  corresponding to the classical observables of interest,  $f_i$ . The basic guiding principle in making the choice of  $(\mathfrak F\,,\,\hat{f}_i)$  is the "Poisson-bracket-commutator" relationship: The Poisson-bracket (2.1.6) gives an algebraic structure on the space of classical observables  $\mathfrak O,$  whereas commutators provide a similar algebraic structure on quantum observables  $\hat{\mathfrak O}.$  One seeks a correspondence map  $\hat{\ }: \mathfrak O \mapsto \hat{\mathfrak O},$  taking classical observables to quantum observables, such that for any pair of classical observables  $\mathfrak f,$  g we have

$$[\hat{f}, \hat{g}] = i \{\hat{f}, g\}$$
 (2.2.1)

where we choose units where  $\hbar=1$ . In fact, it is well known (see, e.g., Chernoff (1981) or Gotay (1980)) that—for theories in which the