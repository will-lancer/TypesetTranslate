

{70}------------------------------------------------

data in  $\mathfrak{M}$ . By theorem 4.1.2 above, each  $[\phi,\pi] \in \mathfrak{M}$ , gives rise to a unique element of  $\mathcal{S}$ , so we may again identify  $\mathfrak{M}$  and  $\mathcal{S}$ . In addition, theorem 4.1.2 implies that  $\mathcal{S}$  is independent of the choice of  $\Sigma_0$ , since  $[\phi,\pi]$  will be smooth and of compact support on the Cauchy surface  $\Sigma_0$  if and only if it is smooth and of compact support on all Cauchy surfaces. Note that dynamical evolution in  $\mathfrak{M}$  by "time" t corresponds to evaluation of the associated element of  $\mathcal{S}$  (and the canonically conjugate momentum  $\pi$  of this solution) on the Cauchy surface  $\Sigma_t$ .

The symplectic structure,  $\Omega$ , on  $\mathfrak{M}$  is given by

$$\begin{split} \Omega\big([\phi_1,\,\pi_1],\,[\phi_2,\,\pi_2]\big) &= \int_{\Sigma_0} (\pi_1\phi_2 - \pi_2\phi_1) \ d^3x \\ &= \int_{\Sigma_0} [\phi_2\,n^a\nabla_a\,\phi_1 - \phi_1\,n^a\nabla_a\,\phi_2] \ \sqrt{h} \ d^3x \ \ (4.2.6) \end{split}$$

Again,  $\Omega$  is conserved for solutions, so we may view  $\Omega$  as a bilinear map on  $\mathcal{A}$ , i.e.,  $\Omega: \mathcal{A} \times \mathcal{A} \to \mathbb{R}$ .

As in Minkowski spacetime, we define the space,  $\Im$ , of "test functions" on a globally hyperbolic curved spacetime, (M,  $g_{ab}$ ), to be  $\Im = C_0^\infty(M)$ . The existence of unique advanced and retarded Green's functions again allows us to define the map  $E:\Im \to \mathcal{S}$  by eq. (3.2.22). The proofs of the three properties of this map expressed in lemma 3.2.1 then generalize straightforwardly to curved spacetime. Thus, all of the mathematical structure used to formulate the quantum theory of a Klein-Gordon field in Minkowski spacetime carries over to globally hyperbolic curved spacetimes with one major exception: In a general, curved spacetime, there is no unique, natural analog of the space of "positive frequency solutions" used to define  $\Re$ .

Nevertheless, there is no difficulty in constructing a quantum field theory for the Klein-Gordon field as follows: Choose any bilinear map  $\mu: \mathcal{S} \times \mathcal{S} \to \mathbb{R}$  such that for all  $\psi_1 \in \mathcal{S}$ ,

$$\mu(\psi_1, \psi_1) = \frac{1}{4} \frac{\text{l.u.b.}}{\psi_2 \neq 0} \frac{[\Omega(\psi_1, \psi_2)]^2}{\mu(\psi_2, \psi_2)}$$
(4.2.7)

Construct the Hilbert space  $\Re$  and the projection map  $K: A \to \Re$  by the algorithm given in section 3.2. Define the quantum field theory by taking the Hilbert space to be  $\Im_s(\Re)$  and representing the classical observables  $\Omega(\psi, \cdot)$  for each  $\psi \in A$  by the operator

{71}------------------------------------------------

$$\widehat{\Omega}(\psi,\cdot) = ia(\overline{K\psi}) - ia^{\dagger}(K\psi)$$
 (4.2.8)

(see eq. (3.2.10)). Equivalently, for each test function  $f \in \mathcal{T}$ , define the "smeared Heisenberg field operator"  $\hat{\phi}(f) : \mathcal{F}_s(\mathfrak{K}) \to \mathcal{F}_s(\mathfrak{K})$  by

$$\widehat{\phi}(f) = ia(\overline{K(Ef)}) - ia^{\dagger}(K(Ef))$$
 (4.2.9)

The only unsatisfactory aspect of this construction is that it involves an arbitrary (i.e., unspecified) choice of the bilinear map  $\mu.$  Although, as discussed at the end of the next section, there never is any difficulty with the existence of  $\mu$ 's which satisfy eq. (4.2.7), in a general, curved spacetime there does not appear to be any "preferred" choice of  $\mu.$  There are two important ramifications of this fact.

First, since the choice of  $\boldsymbol{\mu}$  is in one-to-one correspondence with the construction of the Hilbert space of states,  $\mathcal{F}_s(\mathcal{H})$ , and since the Fock space structure of  $\mathfrak{F}_s(\mathfrak{X})$ , in turn, allows one to define a notion of "particles", this means that there is no natural definition of "particles" in a general, curved spacetime. though a considerable amount of effort has been expended by researchers to obtain a preferred definition of "particles", these efforts have not been successful, except in some restricted classes of spacetimes (most notably, the class of stationary spacetimes discussed in the next section) where symmetries or other structure can be used to naturally select a  $\mu$ . To put this statement in perspective, we should point out that there is no difficulty defining an approximate notion of "particles" when the spacetime is nearly flat (or, more generally, nearly stationary); more precisely, the notion of "particles" becomes highly ambiguous only for modes whose frequency is smaller than typical inverse timescales for the change of the metric. Thus, in our universe, serious difficulties would arise if we attempt to define a meaningful notion of "particles" whose wavelength is larger than the Hubble radius, but, as a practical matter, there is little difficulty employing a particle concept in most other circumstances. Nevertheless, as a matter of principle, it should be stressed that, in general, the notion of "particles" in curved spacetime is, at best, only an approximate one. While some readers familiar with standard presentations of quantum field theory in flat spacetime might be disturbed by the lack of a notion of "particles" in curved spacetime, we have taken great care to empha

{72}------------------------------------------------

size here that this should not be a cause of alarm, since the notion of "particles" plays no essential role in the formulation of quantum field theory. Indeed, I view the lack of an algorithm for defining a preferred notion of "particles" in quantum field theory in curved spacetime to be closely analogous to the lack of an algorithm for defining a preferred system of coordinates in classical general relativity. (Readers familiar only with presentations of special relativity based upon the use of global inertial coordinates might well find this fact to be alarming.) In both cases, the lack of an algorithm does not, by itself, pose any difficulty for the formulation of the theory.

However, a second, related ramification of the lack of a preferred choice of  $\mu$  does pose a potentially serious difficulty with the formulation of quantum field theory in curved spacetime. Stone-von Neuman theorem (see theorem 2.2.1 above) were valid for a quantum theory corresponding to an infinite dimensional phase space,  $\mathfrak{M}$ , then the choice of  $\mu$  would be of no consequence, since different choices of  $\mu$  would lead to unitarily equivalent theories. that case, the choice of  $\mu$  would be exactly analogous to the choice of a coordinate system in classical general relativity in that, in both cases, the choice might affect the superficial appearance of some formulas but would not affect any physical predictions. However, in section 4.4 below, we shall see explicitly that when M is infinite dimensional, different choices of  $\mu$  can yield unitarily inequivalent theories. Thus, to define quantum field theory in a general curved spacetime, it might appear to be essential that we prescribe a unique unitary equivalence class of µ's. In fact, we shall see in section 4.6 that the imposition of the Hadamard condition on states does define a preferred unitary equivalence class of  $\mu$ 's in the case of a "closed universe" (i.e., a spacetime with compact Cauchy surface). However, it does not appear that a uniquely preferred unitary equivalence class of  $\mu$ 's exists for general spacetimes with a noncompact Cauchy surface. Fortunately, we shall see in section 4.5 below that this fact also does not pose a serious problem: Quantum field theory in curved spacetime can be formulated via the algebraic approach in a manner which does not require the specification of even a preferred unitary equivalence class of  $\mu$ 's.

Despite the lack of a completely general algorithm to define  $\mu$ , in stationary spacetimes (i.e., spacetimes possessing a time translation symmetry) there does exist a natural, unique choice of  $\mu$ .

{73}------------------------------------------------

Furthermore, the notion of "particles" associated with this  $\mu$  has a direct physical interpretation. We now shall describe this quantum field theory construction for stationary spacetimes.

## 4.3 Quantum Field Theory in Stationary Spacetimes

Let (M, gab) be a globally hyperbolic spacetime which is stationary, i.e., (M. gab) admits a one-parameter group of isometries.  $\alpha_t$ : M $\rightarrow$ M, whose orbits are timelike. Let  $\xi^a$  denote the Killing vector field which generates these isometries. The basic idea of the quantum field construction in stationary spacetimes is to choose % to be the subspace of (complex) solutions which are "purely positive frequency" with respect to "Killing time" t (satisfying  $\xi^a \nabla_a t = 1$ ) when Fourier analyzed along the orbits of  $\xi^a$ . However, if one attempts to straightforwardly implement this construction in a naive manner, one encounters the difficulties that, a priori, it is not clear that solutions decay suitably rapidly for their Fourier transform along individual Killing orbits to exist, or that there are "sufficiently many" solutions that are purely positive frequency along all Killing Nevertheless, a mathematically precise implementation of this idea has been given by Ashtekar and Magnon (1975) and Kay (1978), and we now describe this construction.

First, in order to avoid possible "infra-red divergence" difficulties in the construction (see below), in general we must make the additional restrictions that the mass, m, of the Klein-Gordon field be strictly positive:

$$m > 0$$
 (4.3.1)

and that there exists a Cauchy surface,  $\Sigma$ , such that on  $\Sigma$  we have, for some  $\epsilon > 0$ ,

$$-\xi^a \xi_a \ge -\varepsilon \xi^a n_a > \varepsilon^2 \tag{4.3.2}$$

where  $n^a$  denotes the unit normal to  $\Sigma$ . Without the restrictions (4.3.1) and (4.3.2), the quantum field construction given below may still work, but it is not guaranteed to do so.

We complexify  ${\mathcal S}$  and define an "energy inner product" on  ${\mathcal S}^{\,{\mathbb C}}$  by

$$<\psi_1, \ \psi_2> = \int_{\Sigma} T_{ab} \, \xi^a \, n^b \sqrt{h} \, d^3x$$
 (4.3.3)

where the classical stress-energy tensor,  $T_{ab}$ , on  $\mathcal{S}^{\,\mathbb{C}}$  is given by

{74}------------------------------------------------

$$T_{ab}(\psi_1, \psi_2) = \nabla_{(a}\overline{\psi}_1\nabla_{b)}\psi_2 - \frac{1}{2}g_{ab}[\nabla^c\overline{\psi}_1\nabla_c\psi_2 + m^2\overline{\psi}_1\psi_2] \qquad (4.3.4)$$

(Note that the assumption that m is positive is used here to ensure that <, > is positive definite even if  $\Sigma$  is compact.) Since  $\psi_1$  and  $\psi_2$  are solutions of the Klein-Gordon equation, we have  $\nabla^a T_{ab} = 0$ . Since  $T_{ab} = T_{ba}$  and  $\nabla_{(a} \xi_{b)} = 0$  by Killing's equation, it follows that  $\nabla^a (T_{ab} \xi^b) = 0$ . Hence, using Gauss' law, we see that <, > is independent of the choice of Cauchy surface  $\Sigma$ . In particular, it follows that <, > is invariant under the time translation map  $\tau_t \colon \mathcal{A}^{\,\mathfrak{C}} \to \mathcal{A}^{\,\mathfrak{C}}$  defined by  $\tau_t(\psi) = \psi\circ\alpha_{-t}$ , since applying  $\tau_t$  to the solutions is equivalent to applying  $\alpha_{-t}$  to  $\Sigma$ .

Next, we complete  $\mathcal{A}^{\mathfrak{C}}$  in the norm defined by <, > to get a complex Hilbert space  $\widetilde{\mathfrak{R}}$ . (It should be emphasized that  $\widetilde{\mathfrak{R}}$  is *not* the Hilbert space we seek; it is used only as an intermediate tool in the construction.) The time translation map  $\tau_t$  extends to  $\widetilde{\mathfrak{R}}$  to define a strongly continuous, one-parameter, unitary group,  $V_t$ . By Stone's theorem,  $V_t$  is of the form  $V_t = \exp(-i\widetilde{h}t)$ , where  $\widetilde{h} \colon \widetilde{\mathfrak{R}} \to \widetilde{\mathfrak{R}}$  is self-adjoint. Note that from the definition of  $\tau_t$ , we have for all  $\psi \in \mathcal{A}^{\mathfrak{C}}$ ,

$$\tilde{h} \psi = i \mathfrak{Z}_{\xi} \psi \tag{4.3.5}$$

where & denotes the Lie derivative.

Now, define B: $\&^{\mathbb{C}} \times \&^{\mathbb{C}} \to \mathbb{C}$  by

$$\mathsf{B}(\psi_1,\psi_2) = \Omega(\overline{\psi}_1,\,\psi_2) \tag{4.3.6}$$

Using the definition of  $\Omega$ , eq.(4.2.6), together with eqs. (4.3.1), (4.3.2), and the Schwarz inequality, we obtain

$$|B(\psi_1, \psi_2)| \le C \|\psi_1\| \|\psi_2\|$$
 (4.3.7)

from which it follows that B extends continuously to a quadratic form on  $\widetilde{\mathfrak{K}}$ . Furthermore, by a direct calculation using eq. (4.3.5) and the definitions of  $\Omega$  and <, >, it may be verified that for all  $\psi_1, \psi_2 \in \mathcal{A}^{\mathfrak{C}}$ , we have

$$B(\psi_1, \tilde{h}\psi_2) = 2 i < \psi_1, \psi_2 >$$
 (4.3.8)

From eqs. (4.3.7) and (4.3.8) and the fact that  $\mathcal{S}^{\mathbb{C}}$  is dense in  $\widetilde{\mathfrak{K}}$ , it

{75}------------------------------------------------

follows that the spectrum of  $\tilde{h}$  is bounded away from zero, so  $\tilde{h}^{-1}$  exists as a bounded operator on  $\tilde{\Re}$ .

Now, let  $\widetilde{\mathfrak{K}}^+$  be the positive spectral subspace of  $\widetilde{h}$  in  $\widetilde{\mathfrak{K}}$  (defined via the spectral theorem), so that—in view of eq. (4.3.5)— $\widetilde{\mathfrak{K}}$  + may be interpreted as the subspace of "positive frequency solutions" in  $\widetilde{\mathfrak{K}}$ . Let  $K:\widetilde{\mathfrak{K}}\to\widetilde{\mathfrak{K}}^+$  denote the projection map onto  $\widetilde{\mathfrak{K}}^+$ . For all  $\psi_1,\psi_2\in \mathcal{S}$ , define  $\mu:\mathcal{S}\times\mathcal{S}\to\mathbb{R}$  by

$$\mu(\psi_1, \psi_2) = \text{Im B}(K\psi_1, K\psi_2) = 2 \text{ Re} < K\psi_1, \ \tilde{h}^{-1}K\psi_2 >$$
 (4.3.9)

Then  $\mu$  satisfies eq. (4.2.7) with the least upper bound for  $\psi_2$  in that equation\_attained by a sequence in  $\mathcal A$  approaching the vector  $i(K\psi_1-K\psi_1)$  in  $\widetilde{\mathfrak K}$ . This defines the desired quantum field theory which naturally arises from the stationary symmetry. The "one-particle-Hilbert space",  $\mathfrak K$ , defined by the construction is just the completion of the space,  $\widetilde{\mathfrak K}^+$ , of "positive frequency solutions" in the Klein-Gordon inner product (see eq. (3.2.19)). Note, however, that the construction avoided any direct attempt to take the "time Fourier transform" of solutions in  $\mathcal A$  along orbits of  $\xi^a$ . As already indicated above, significant technical difficulties would have arisen had we attempted to do so, since the time decay properties of solutions in general spacetimes—in particular, in spacetimes with a compact Cauchy surface—are such that this time Fourier transform may exist only in a distributional sense.

It is important to note that the discussion of the "particle interpretation" of states for quantum field theory in Minkowski spacetime given in section 3.3 carries over without any essential change to globally hyperbolic, stationary, curved spacetimes. Namely, a nearly "time-independent" (with respect to  $\xi^a$ ) coupling of the quantum field  $\phi$  to a time-independent quantum mechanical system will induce transitions of that system in exactly the same manner as discussed in section 3.3. Consequently, the states in the Hilbert space  $\mathfrak{F}_s(\mathfrak{K})$  constructed above have the same type of particle interpretation as in Minkowski spacetime.

Now, consider a globally hyperbolic spacetime (M,  $g_{ab}$ ) which is "stationary in the past", i.e., suppose that for some Cauchy surface  $\Sigma$ , the past of  $\Sigma$  is isometric to the past of a Cauchy surface  $\Sigma'$  in some globally hyperbolic stationary spacetime (M',  $g_{ab}$ ). Then the solution space,  $\mathcal{S}$ , for (M,  $g_{ab}$ ) can be identified with the solution space,  $\mathcal{S}'$ ,

{76}------------------------------------------------

for (M',  $g'_{ab}$ ) by identifying initial data for the solutions on corresponding Cauchy surfaces in the isometric regions. Hence, the  $\mu'$  defined on  $\mathcal{S}'$  by eq. (4.3.9) gives rise to a quantum field construction on (M,  $g_{ab}$ ). The one-particle Hilbert space for the quantum field on (M,  $g_{ab}$ ) which is obtained from  $\mu'$  is denoted as  $\mathfrak{K}_{in}$ . States in the Fock space  $\mathfrak{F}_s(\mathfrak{K}_{in})$  obtained from this construction will have a natural particle interpretation in the past, but not necessarily anywhere else in the spacetime. Similar considerations apply if (M,  $g_{ab}$ ) is merely "asymptotically stationary" in the past, i.e., if, under an appropriate identification of the given spacetime with a stationary spacetime (M',  $g'_{ab}$ ), solutions in  $\mathcal{S}$  suitably approach solutions in  $\mathcal{S}'$  in the asymptotic past.

If (M,  $g_{ab}$ ) also is stationary (or asymptotically stationary) in the future, a similar quantum field construction yields a Fock space  $\mathfrak{F}_s(\mathfrak{R}_{out})$ , whose states have a natural particle interpretation in the future. If this construction is unitarily equivalent to the one arising from  $\mathfrak{R}_{in}$ , the unitary map  $U:\mathfrak{F}_s(\mathfrak{R}_{in}) \to \mathfrak{F}_s(\mathfrak{R}_{out})$  which implements this equivalence is known as the S-matrix. Thus, the S-matrix relates the particle description of states in the past with that in the future, and it thereby directly contains all information regarding "spontaneous particle creation" and scattering. We shall compute the S-matrix explicitly (in terms of operators describing classical scattering) in the next section.

Finally, we remark that the considerations of this section allow us to prove that for the Klein-Gordon field on an arbitrary globally hyperbolic spacetime, there always exists a bilinear map  $\mu: \mathcal{A} \times \mathcal{A} \to \mathbb{R}$  satisfying eq. (4.2.7). Namely, given any globally hyperbolic spacetime (M,  $g_{ab}$ ) with Cauchy surface  $\Sigma$  we can construct a new globally hyperbolic "interpolating spacetime"  $(\tilde{M}, \tilde{g}_{ab})$  with Cauchy surfaces  $\tilde{\Sigma}_1$ ,  $\tilde{\Sigma}_2$  such that the future of  $\tilde{\Sigma}_1$  in  $\tilde{M}$  is isometric to the future of  $\Sigma$  in M, and the past of  $\widetilde{\Sigma}_2$  is isometric to the past of a Cauchy surface in a stationary, globally hyperbolic spacetime, satisfying eq. (4.3.2) (see Appendix C of Fulling et al (1981)). In addition, in the case of a massless field on (M, gab) we may also "deform" m on  $(\widetilde{M},\,\widetilde{g}_{\,a\,b})$  to the past of  $\widetilde{\Sigma}_{\,1}$  (by treating it as an external potential) so that m is nonzero and constant in the past of  $\tilde{\Sigma}_2$ , in which case eq. (4.3.1) also is satisfied there. By identifying the solution space, &, for  $(M, g_{ab})$  with the solution space  $\tilde{\mathcal{A}}$  for  $(\tilde{M}, \tilde{g}_{ab})$  and, in turn, identifying  $\tilde{\mathcal{S}}$  with the solution space for the stationary spacetime, we 

{77}------------------------------------------------

thereby obtain the desired  $\mu$ .

Indeed, a much more direct proof of the existence of a bilinear map  $\mu: \mathcal{A} \times \mathcal{A} \to \mathbb{R}$  satisfying eq. (4.2.7) can be given as follows (Chmielowski 1994). Start with any inner product, <, >, on  $\mathcal{A}^{\mathfrak{C}}$  whose associated norm satisfies the inequality

$$||\psi_1|| \ ||\psi_2|| \ \ge \frac{1}{2} \ |\Omega(\psi_1, \, \psi_2)| \tag{4.3.10}$$

(An example of such an inner product is the sum of the L²-norms of  $\psi$  and its normal derivative on an arbitrary Cauchy surface  $\Sigma$ .) Complete  $\mathcal{A}^{\,\mathbb{C}}$  in this inner product to get a complex Hilbert space  $\mathfrak{A}^{\,\mathbb{C}}$ . Since the quadratic form  $i\Omega(\psi_1,\psi_2)$  is bounded on  $\mathfrak{A}^{\,\mathbb{C}}$ , it defines a bounded operator  $A\colon \mathfrak{A}^{\,\mathbb{C}} \to \mathfrak{A}^{\,\mathbb{C}}$  such that  $<\psi_1,A\,\psi_2>=i\Omega\,(\overline{\psi}_1,\psi_2).$  Furthermore, the antisymmetry property of  $\Omega$  implies that A is self-adjoint. We define  $\mu\colon \mathcal{A}\times\mathcal{A}\to\mathbb{R}$  by

$$\mu(\psi_1, \psi_2) = \frac{1}{2} \langle \psi_1, | A | \psi_2 \rangle \tag{4.3.11}$$

for all  $\psi_1, \psi_2 \in \mathcal{A}$ , where IAI: $\mathfrak{K}' \to \mathfrak{K}'$  denotes the absolute value of A, i.e., the positive square root of A†A. Then, it is not difficult to verify that  $\mu$  satisfies eq. (4.2.7) (see Chmielowski 1994). Indeed, the above stationary vacuum state construction is equivalent to defining  $\mu$  by this algorithm, starting with the inner product (4.3.3). When m>0, the  $\mu$  obtained by this algorithm using the inner product (4.3.3) with  $\xi^a$  replaced by  $n^a$  defines a Hamiltonian diagonalization prescription for defining a vacuum state with respect to any Cauchy surface  $\Sigma$  in any globally hyperbolic spacetime. However, unlike the stationary vacuum state construction, the vacuum state obtained by Hamiltonian diagonalization will, in general, depend upon the choice of Cauchy surface  $\Sigma$ .

The above argument establishes quantum field theory constructions of the type discussed in the previous section always exist in any globally hyperbolic spacetime. However, it is clear that the choice of  $\mu$  is highly nonunique. We turn now to an analysis of the necessary and sufficient conditions for two different choices of  $\mu$  to yield unitarily equivalent quantum field theories.

{78}------------------------------------------------

## 4.4 Unitary Equivalence; the S-matrix

Let  $(\mathcal{S},\Omega)$  be an arbitrary real symplectic vector space, i.e.,  $\mathcal{S}$  is a vector space over  $\mathbb{R}$  and the bilinear map  $\Omega: \mathcal{S} \times \mathcal{S} \to \mathbb{R}$  is antisymmetric and nondegenerate. The case of interest for us, of course, is where  $\mathcal{S}$  is the space of solutions to the Klein-Gordon equation in a globally hyperbolic spacetime having initial data in  $C_0^\infty$ , with  $\Omega$  given by eq. (4.2.6); however, it is worth emphasizing that all the considerations of this section and the next require only the symplectic vector space structure of  $(\mathcal{S},\Omega)$ . Let  $\mu_1:\mathcal{S}\times\mathcal{S}\to\mathbb{R}$  and  $\mu_2:\mathcal{S}\times\mathcal{S}\to\mathbb{R}$  be two bilinear maps satisfying eq. (4.2.7). In the manner described previously, we can use these maps to construct, respectively, the Fock spaces  $\mathcal{F}_1=\mathcal{F}_s(\mathcal{H}_1)$  and  $\mathcal{F}_2=\mathcal{F}_s(\mathcal{H}_2)$  with operators  $\widehat{\Omega}_1(\psi,\cdot):\mathcal{F}_1\to\mathcal{F}_1$  and  $\widehat{\Omega}_2(\psi,\cdot):\mathcal{F}_2\to\mathcal{F}_2$  defined by eq. (4.2.8). We wish to know under what circumstances there will exist a unitary map  $U:\mathcal{F}_1\to\mathcal{F}_2$  such that for all  $\psi\in\mathcal{S}$  we have

$$U \hat{\Omega}_1(\psi, \cdot) U^{-1} = \hat{\Omega}_2(\psi, \cdot)$$
 (4.4.1)

Furthermore, if such a U does exist, we wish to determine it explicitly.

There is a twofold purpose to our investigation of this ques-First, it is important with regard to the formulation of quantum field theory in curved spacetime to understand the necessary and sufficient conditions for two different choices of  $\mu$  to yield unitarily equivalent theories. In particular, if all choices of  $\mu$  led to unitarily equivalent theories, the choice of  $\mu$  would be irrelevant and the discussion of section 4.2 (together with the existence proof for  $\mu$  given at the end of section 4.3) would completely specify the construction of quantum field theory in curved spacetime. However, as we shall see shortly, this is not the case. Secondly, as discussed near the end of the section 4.3, for a spacetime which is asymptotically stationary in both the past and future, we have two natural choices of  $\mu_1$ , namely  $\mu_1 = \mu_{in}$  and  $\mu_2 = \mu_{out}$ . The S-matrix U: $\mathfrak{F}_1 \rightarrow \mathfrak{F}_2$ implementing the unitary equivalence of these constructions—if they are unitarily equivalent-yields all information regarding particle creation and scattering. Thus, it is of direct physical relevance to compute U. The basic analysis of the issue of unitary equivalence was given in Shale (1962). Our treatment below will follow closely that of Wald (1979a).

{79}------------------------------------------------

The analysis of unitary equivalence naturally divides into two cases:

case (i): There exist C, C' > O such that for all  $\psi \in \mathcal{S}$  we have

$$C \mu_1(\psi, \psi) \le \mu_2(\psi, \psi) \le C' \mu_1(\psi, \psi)$$
 (4.4.2)

case (ii): No such C, C'> O exist.

We claim, first, that unitary equivalence cannot hold in case (ii). Namely, if, say, there does not exist a C > O such that  $\mu_1(\psi,\psi) \leq \mu_2(\psi,\psi)/C$  for all  $\psi \in \mathcal{S}$ , then we can find a sequence  $\{\psi_n\}$  in  $\mathcal{S}$  such that  $\mu_1(\psi_n,\psi_n)=1$  for all n but  $\mu_2(\psi_n,\psi_n)\to 0$ . Then, on  $\mathfrak{F}_2$ , the sequence of operators  $\{\exp[i\hat{\Omega}_2(\psi_n,\cdot)]-I_2\}$  converges strongly to zero, i.e., when applied to any fixed vector in  $\mathfrak{F}_2$ , the resulting sequence of vectors converges to zero. However, on  $\mathfrak{F}_1$  the sequence of vectors  $\{\exp[i\hat{\Omega}_1(\psi_n,\cdot)] \mid 0>_1-\mid 0>_1\}$  does not converge to zero. Hence if a unitary map U satisfying eq. (4.4.1) existed, U  $\mid 0>_1\in \mathfrak{F}_2$  would contradict the strong convergence property in  $\mathfrak{F}_2$ .

We turn our attention, now, to case (i). Equation (4.4.2) implies that  $\mu_1$  and  $\mu_2$  define "equivalent norms" on &, i.e., a sequence in & is Cauchy in  $\mu_1$  if and only if it is Cauchy in  $\mu_2$ . Hence, the Cauchy completions of & in  $\mu_1$  and  $\mu_2$  may be identified and we will denote this completion as &  $\mu$  (omitting the subscript 1 or 2). The two one-particle Hilbert spaces,  $\mathfrak{K}_1$  and  $\mathfrak{K}_2$ —arising from  $\mu_1$  and  $\mu_2$ , respectively, by the construction described in section 3.2—thus may be viewed as different subspaces of the same (complexified, completed) space  $\mathcal{S}_\mu^{\ \ C}$ .

Now, define the inner product  $2\mu_1(\overline{\psi},\chi)$  on  $\mathcal{A}_\mu{}^\mathbb{C}$  (see eq. (3.2.18)) and let  $K_1:\mathcal{A}_\mu{}^\mathbb{C}\to\mathfrak{R}_1$  denote the orthogonal projection map onto  $\mathfrak{R}_1$  arising from this inner product. Similarly, let  $\overline{K}_1:\mathcal{A}_\mu{}^\mathbb{C}\to\overline{\mathfrak{R}}_1$  denote the orthogonal projection map onto  $\overline{\mathfrak{R}}_1$  in this inner product. Since  $\mathfrak{R}_1$  and  $\overline{\mathfrak{R}}_1$  are orthogonal subspaces which span  $\mathcal{A}_\mu{}^\mathbb{C}$ , we have  $K_1+\overline{K}_1=I$  on  $\mathcal{A}_\mu{}^\mathbb{C}$ . Let  $K_2:\mathcal{A}_\mu{}^\mathbb{C}\to\mathfrak{R}_2$  and  $\overline{K}_2:\mathcal{A}_\mu{}^\mathbb{C}\to\overline{\mathfrak{R}}_2$  denote the similar orthogonal projection maps for the inner product  $2\mu_2(\overline{\psi},\chi)$  on  $\mathcal{A}_\mu{}^\mathbb{C}$ . By eqs. (4.2.8) and (4.4.1), unitary equivalence of the two constructions holds if and only if there exists a unitary map  $U:\mathfrak{F}_s(\mathfrak{R}_1)\to\mathfrak{F}_s(\mathfrak{R}_2)$  such that for all  $\psi\in\mathcal{S}$  we have

$$U[ia_{1}(\overline{K}_{1}\psi) - ia_{1}^{\dagger}(K_{1}\psi)] \ U^{-1} = ia_{2}(\overline{K}_{2}\psi) - ia_{2}^{\dagger}(K_{2}\psi)$$
 (4.4.3)

where  $a_1$ ,  $a_1^{\dagger}$  and  $a_2$ ,  $a_2^{\dagger}$  are the annihilation and creation operators