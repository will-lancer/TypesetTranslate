

{150}------------------------------------------------

The geodesic deviation equation governs the rate of change of  $\theta$ . Using it, we obtain the Raychauduri equation (see, e.g., Wald (1984a)),

$$\frac{d\theta}{d\lambda} = -\frac{1}{2} \theta^2 - \sigma_{ab} \sigma^{ab} - R_{ab} k^a k^b$$
 (6.1.3)

where  $\sigma_{ab}$  denotes the shear of the geodesics and  $R_{ab}$  is the Ricci curvature of the spacetime. Now, if Einstein's equation holds with the stress-energy tensor  $T_{ab}$  satisfying the null energy condition  $T_{ab}$  kakb  $\geq 0$ , we obtain  $R_{ab}$  kakb  $\geq 0$  and, hence,

$$\frac{d\theta}{d\lambda} \le -\frac{1}{2} \theta^2 \tag{6.1.4}$$

from which it immediately follows that

$$\theta^{-1}(\lambda) \ge \theta_0^{-1} + \frac{1}{2}\lambda$$
 (6.1.5)

where  $\theta_0$  denotes the initial value of  $\theta.$  Thus, if  $\theta_0<0$  (i.e., the geodesics initially are converging) we find that  $\theta(\lambda_1)=-\infty$  (i.e., the convergence is infinite) at some  $\lambda_1\leq 2/|\theta_0|$  provided, of course, that the geodesic  $\alpha$  can be extended that far.

The machinery now is in place to state and prove the area theorem:

Theorem 6.1.2 (Area theorem): For a predictable black hole satisfying  $R_{ab}k^ak^b \ge 0$  for all null  $k^a$ , the surface area of the future event horizon,  $h^+$ , never decreases with time.

*Proof*: We show, first, that we have  $\theta \ge 0$  everywhere on the event horizon h+ of a predictable black hole,  $\mathfrak{B}$ . If the null generators of the horizon were assumed to be geodesically complete (as in the original proof of Hawking (1971)), this conclusion actually would follow immediately from the above result together with the fact that, by theorem 6.1.1 above, we cannot have  $\theta = -\infty$  at any point of h+. However, for a predictable black hole, it is not necessary to assume completeness of the generators of h+ (Hawking and Ellis 1973): If  $\theta < 0$  at  $p \in h+$ , we could deform a two-dimensional cross-section, S, of the horizon outward in a small neighborhood of p, keeping the expansion of the orthogonal null geodesics negative. Let S' denote

{151}------------------------------------------------

this deformed cross-section. Then  $\mathfrak{g}+\cap I^+(S')$  is nonempty, and global hyperbolicity implies that any point  $q \in \mathfrak{I}^+ \cap \dot{I}^+(S')$  must be connected to S' by a null geodesic,  $\alpha$ , which lies in  $I^+(S')$  (see theorem 8.3.11 of Wald (1984a)). Furthermore,  $\alpha$  is orthogonal to S' and is future complete, so that  $\theta = -\infty$  at some point of  $\alpha$  for the congruence of null geodesics orthogonal to S'. Application of theorem 6.1.1 to the "deformed horizon"-i.e., the horizon associated with the family of observers who have endpoints on  $\mathfrak{g}+\cap\dot{I}+(S')$ —then yields a contradiction. Note that this argument requires global hyperbolicity of only the region exterior to the black hole. Note also that the same argument shows that if the region exterior to a black hole is globally hyperbolic, then any trapped surface must be entirely contained within the black hole. (Here, a trapped surface is a compact, twodimensional, spacelike submanifold having the property that both sets of orthogonal null geodesics (i.e., "ingoing" and "outgoing") have negative expansion,  $\theta < 0$ .)

Since  $\theta \geq 0$ , the cross-sectional area of the horizon locally increases as one moves up the generators of h<sup>+</sup>. By theorem 6.1.1, these generators cannot leave h<sup>+</sup> (although new generators can join h<sup>+</sup>). Nevertheless, one has to worry about the possibility that these null geodesic generators might not reach a sufficiently late time slice  $\Sigma$  (e.g., they might terminate on a singularity on the horizon), thus causing the area of h<sup>+</sup>  $\cap$   $\Sigma$  to be smaller than the initial area. However, this possibility cannot occur for a predictable black hole, wherein the event horizon as well as the exterior region is contained in a globally hyperbolic region,  $\emptyset$ , of M. Namely, if  $\Sigma$  is a Cauchy surface for this region, then by a standard theorem (see theorem 8.3.7 of Wald (1984a)) every null geodesic in  $\emptyset$  must intersect  $\Sigma$ . Thus, if  $\Sigma_1$  and  $\Sigma_2$  are Cauchy surfaces with  $\Sigma_2 \subset I^+(\Sigma_1)$ , every generator of h<sup>+</sup> at  $\Sigma_1$  must reach  $\Sigma_2$ . Thus the area of h<sup>+</sup>  $\cap$   $\Sigma_2$  must be at least as large as the area of h<sup>+</sup>  $\cap$   $\Sigma_1$ , as we desired to show.  $\square$ 

## 6.2 The Laws of Black Hole Mechanics

The statement of the area theorem bears a superficial resemblence to the statement of the second law of thermodynamics in that both results assert that a certain quantity never decreases with time. In this section, we shall show that other laws of black hole mechanics bear a striking mathematical similarity to the laws of thermodynamics.

We begin by recalling the following result due to Hawking (see

{152}------------------------------------------------

proposition 9.3.6 of Hawking and Ellis (1973)): Let (M,  $g_{ab}$ ) be an asymptotically flat spacetime which is stationary, i.e., there exists a one-parameter group of isometries whose Killing field  $\xi^a$  is timelike near infinity. Suppose, further, that (M,  $g_{ab}$ ) is a solution of Einstein's equation with matter satisfying suitable hyperbolic equations, and that the metric and matter fields are analytic. (Analyticity of the metric and matter fields in the region where  $\xi^a$  is timelike follows as a consequence of the ellipticity of the stationary field equations, but it is an additional assumption elsewhere.) Then the event horizon, h+, of any black hole,  $\mathfrak B$ , in (M,  $g_{ab}$ ) is a Killing horizon, i.e., there exists a Killing field  $\chi^a$  (not necessarily coinciding with  $\xi^a$ ) which is normal to h+.

Since h+ must be invariant (i.e., mapped into itself) under the stationary isometries, it is obvious that the stationary Killing field  $\xi^a$  must be tangent to h+. The above result states that if  $\xi^a$  fails to be normal to h+, then there exists an additional Killing field,  $\chi^a$ , which is. Furthermore, in this case where  $\chi^a \neq \xi^a$ , it can be shown that a linear combination,  $\phi^a$ , of these two Killing fields, can be chosen so that the orbits of  $\phi^a$  are closed. Thus, if  $\chi^a \neq \xi^a$ , then (M,  $g_{ab}$ ) is axisymmetric as well as stationary. For a stationary black hole, we define the angular velocity of the horizon,  $\Omega$ , by,

$$\chi^{a} = \xi^{a} + \Omega \,\phi^{a} \tag{6.2.1}$$

where  $\phi^a$  is normalized by requiring that the closed orbits have period  $2\pi$ , and  $\xi^a$  is normalized by requiring  $\xi^a\xi_a\to -1$  at infinity.

The above result does not put any restriction on the type of Killing horizon that may occur, e.g., it does not imply that the event horizon of a stationary black hole must comprise a portion of a bifurcate Killing horizon (see section 5.2). However, it can be shown by a rather lengthy calculation (Bardeen et al. 1973) that if Einstein's equation holds with matter satisfying the dominant energy condition, then the surface gravity,  $\kappa$ , (defined by eq. (5.2.4) above) of any (connected) Killing horizon,  $\kappa$ , must be constant over the horizon. However, if  $\kappa$  is constant and nonzero over  $\kappa$ , then it can be shown (Racz and Wald 1992) that one always can locally extend, if necessary, a neighborhood of  $\kappa$  so that  $\kappa$  comprises a portion of a bifurcate Killing horizon (although existence of a global extension with this property was not proven). This indicates that the only physically relevant types of Killing horizons—i.e., the only Killing

{153}------------------------------------------------

horizons that occur in solutions of Einstein's equation with matter satisfying the dominant energy condition—are bifurcate Killing horizons and "degenerate horizons" (defined as those for which  $\kappa=0$ ). In particular, except in the degenerate case, the event horizon,  $h^+,$  of a stationary black hole should always correspond to the portion,  $\hbar_A,$  of a bifurcate Killing horizon. This is indeed the case for all the known black hole solutions. In particular, the charged Kerr solutions with  $Q^2+(J/M)^2 \le M^2$  comprise all the known stationary black hole solutions of the Einstein-Maxwell equations. The horizons of the charged Kerr black holes with  $Q^2+(J/M)^2 < M^2$  correspond to the bifurcate case (and have been proven to be the only solutions with  $\kappa \neq 0$ ), whereas the horizons of the "extreme" charged Kerr black holes satisfying  $Q^2+(J/M)^2=M^2$  correspond to the degenerate case.

We turn, now to the derivation of the "first law" of black hole mechanics. Actually, there are two logically independent versions of this law, which I will refer to as the "physical process version" and the "equilibrium state version."

For the "physical process version," we start with a stationary black hole and alter it by some (infinitesimal) physical process. We assume that the black hole is not destroyed by this process and that it "settles down" to a new stationary final state. We then relate its change in area to the changes in the other parameters describing the black hole.

For simplicity, we treat the case of a vacuum black hole which is altered by dumping in a small amount of matter represented by stress energy  $\Delta T_{ab}.$  Then, to first order in  $\Delta T_{ab},$  we can neglect the change in the black hole geometry when computing the resulting changes in mass,  $\Delta M,$  and angular momentum,  $\Delta J,$  of the black hole. Thus, we obtain

$$\Delta M = \int_0^\infty dV \int d^2S \ \Delta T_{ab} \ \xi^a \ k^b$$
 (6.2.2)

$$\Delta J = -\int_0^\infty dV \int d^2S \ \Delta T_{ab} \ \phi^a \ k^b$$
 (6.2.3)

where we have chosen to parametrize the null geodesics (with tangent ka) on the horizon by affine parameter, V, and the second integral in these expressions is over the cross-section, S, of the horizon corresponding to the "time" V. [Note that the product kbdV is parametrization-independent. Note also that the range of integration

{154}------------------------------------------------

from 0 to  $\infty$  for V corresponds to the range  $-\infty$  to  $+\infty$  of Killing parameter v (see eq. (5.2.10)).] On the other hand, the change in area is governed by the Raychaudhuri equation (6.1.3) applied to the exact horizon. To first order in  $\Delta T_{ab}$ , the quadratic terms  $\theta^2$  and  $\sigma_{ab}$   $\sigma^{ab}$  can be neglected. Hence, using Einstein's equation, we obtain,

$$\frac{d\theta}{dV} = -8\pi \,\Delta T_{ab} \,k^{a}k^{b} \tag{6.2.4}$$

When integrating the right side of this equation over the horizon, the change in the black hole geometry may be neglected. Thus, on the right side of eq. (6.2.4), we may substitute for ka

$$k^{a} = (\partial/\partial V)^{a} = \frac{1}{\kappa V} (\partial/\partial v)^{a} = \frac{1}{\kappa V} \chi^{a}$$
$$= \frac{1}{\kappa V} (\xi^{a} + \Omega \phi^{a})$$
(6.2.5)

Hence, multiplying both sides of eq. (6.2.4) by  $\kappa V$  and integrating over the horizon, we obtain (Hawking and Hartle 1972)

$$\kappa \int_0^\infty dV \int d^2S \ V \frac{d\theta}{dV} = -8\pi \int_0^\infty dV \int d^2S \ \Delta T_{ab}(\xi^a + \Omega \phi^a) k^b$$
$$= -8\pi \ (\Delta M - \Omega \Delta J) \tag{6.2.6}$$

The left side of this equation can be evaluated by integration by parts,

$$\int d^2S \left( \int_0^\infty V \frac{d\theta}{dV} dV \right) = \int d^2S \left( \theta V \right) \int_0^\infty - \int d^2S \int_0^\infty \theta dV \qquad (6.2.7)$$

By eq. (6.1.2), the second term on the right side is just minus the change in area of the black hole. On the other hand, the first term vanishes since V=0 at the lower limit and  $\theta$  must vanish faster than 1/V as  $V\to\infty$  if the black hole settles down to a stationary final state with finite area. Thus, we obtain

$$\kappa \Delta A = 8\pi \left(\Delta M - \Omega \Delta J\right) \tag{6.2.8}$$

which is the desired "physical process" version of the first law. Note that eq. (6.2.8) together with the equality of the second and 

{155}------------------------------------------------

third terms in eq. (6.2.6) shows that  $\Delta A \ge 0$  provided that  $\Delta T_{ab} k^a k^b \ge 0$ , in accordance with the area theorem.

The "equilibrium state" version of the first law simply compares the areas of two infinitesimally nearby stationary black hole solutions to Einstein's equation. The original derivation that eq.(6.2.8) holds for nearby stationary solutions involved a rather lengthy calculation (Bardeen et al. 1973). However, it turns out that eq. (6.2.8) can be derived in a very simple, direct, and general manner from the Hamiltonian or Lagrangian formulations of general relativity (Sudarsky and Wald 1992, Wald 1993a,c, lyer and Wald 1994). We now shall outline the derivation of the equilibrium state version of the first law for general relativity using the Hamiltonian formulation, and then shall briefly sketch how the first law may be derived for an arbitrary diffeomorphism invariant theory of gravity obtained from a Lagrangian.

It is well known that general relativity can be given a Hamiltonian formulation (see e.g., Appendix E of Wald (1984a)). A point in the phase space of general relativity corresponds to the specification of the fields  $(h_{ij},\,\pi^{ij})$  on a three dimensional manifold  $\Sigma.$  Here  $h_{ij}$  is a Riemannian metric on  $\Sigma$  and its canonically conjugate momentum is  $(1/16\pi)\pi^{ij}$  where  $\pi^{ij}$  is related to the extrinsic curvature,  $K_{ij},$  of  $\Sigma$  in the spacetime obtained by evolving this initial data by

$$\pi^{ij} = \sqrt{h} (K^{ij} - h^{ij} K)$$
 (6.2.9)

(The letters "i,j,k,..." are used here for "spatial indices", i.e., abstract indices of tensors on  $\Sigma$ ; as elsewhere in this book, the letters "a,b,c,..." are used for "spacetime indices", i.e., abstract indices of tensors on M.) As also is well known, constraints are present in general relativity. In the vacuum case, the allowed initial data are restricted to the constraint submanifold in phase space defined by the vanishing at each point  $x \in \Sigma$  of the quantities,

$$0 = \mathcal{C}_0 = \frac{1}{16\pi} \sqrt{h} \left\{ -(3)R + \frac{1}{h} \left[ \pi^{ij} \pi_{ij} - \frac{1}{2} \pi^2 \right] \right\}$$
 (6.2.10)

$$0 = \mathfrak{T}_{i} = -\frac{1}{8\pi} \sqrt{h} \ D_{j}(\pi_{i} j / \sqrt{h}) \tag{6.2.11}$$

where  $D_i$  denotes the derivative operator on  $\Sigma$  compatible with  $h_{ij}$  and  $^{(3)}R$  denotes the scalar curvature of  $h_{ii}$ .

{156}------------------------------------------------

The ADM Hamiltonian, H, for general relativity has the "pure constraint" form,

$$H = \int_{\Sigma} N^{a} \mathfrak{T}_{a} \tag{6.2.12}$$

where  $N^a$  is to be viewed as a nondynamical variable, which may be prescribed arbitrarily. In the spacetime obtained by solving Hamilton's equations,  $N^a$  has the interpretation of being the time evolution vector field, i.e., its projection normal to  $\Sigma$  yields the lapse function, N, and its projection into  $\Sigma$  yields the shift vector,  $N^i$ . This "pure constraint" form of H is not special to the vacuum Einstein equations; any diffeomorphism invariant theory which can be given a Hamiltonian formulation always has a Hamiltonian of this general form (see the Appendix of Lee and Wald (1990) and lyer and Wald (1994)).

Now, let  $(h_{ij}, \pi^{ij})$  be any initial data satisfying the constraints (6.2.10)-(6.2.11). Choose any time evolution vector field  $N^a$  on  $\Sigma$ . Let  $(\delta h_{ij}, \delta \pi^{ij})$  be an arbitrary perturbation of these data (not necessarily satisfying the linearized constraints). Then the variation of eq. (6.2.12) yields an equation of the form

$$\delta H = \int_{\Sigma} \left[ \mathfrak{P}^{ij} \, \delta h_{ij} + Q_{ij} \, \delta \pi^{ij} \right] \, + \, \text{"surface terms"} \qquad (6.2.13)$$

where the "surface terms" arise from the integrations by parts needed to remove the spatial derivatives from  $\delta h_{ij}$  and  $\delta \pi^{ij}$ . The statement that H is a Hamiltonian for general relativity means precisely that the coefficient,  $\mathfrak{P}^{ij}$ , of  $\delta h_{ij}$  equals minus the "time derivative" (i.e., the Lie derivative with respect to Na) of the canonical momentum  $(1/16\pi)\pi^{ij}$  in the solution to Einstein's equations arising from the initial data  $(h_{ij},\pi^{ij}),$  and that the coefficient,  $16\pi \mathfrak{P}_{ij}$ , of  $(1/16\pi)\delta\pi^{ij}$  equals the time derivative of  $h_{ab}.$  Explicit formulas for  $\mathfrak{P}^{ij}$  and  $\mathfrak{P}_{ij}$  can be found, e.g., in Appendix E of Wald (1984a).

Now, consider a stationary black hole with bifurcate Killing horizon. Choose an asymptotically flat hypersurface,  $\Sigma$ , which intersects the bifurcation surface,  $\sigma$ , of the horizon, and let  $(h_{ij}, \pi^{ij})$  be the initial data which are induced on  $\Sigma$ . Choose the Killing field  $\chi^a$ , eq. (6.2.1), which is normal to the horizon (and thus vanishes at  $\sigma$ ) as the time evolution vector field,  $N^a$ . Let  $(\delta h_{ij}, \delta \pi^{ij})$  be any smooth perturbation of these data which is asymptotically flat and satis-

{157}------------------------------------------------

fies the linearized constraints (i.e.,  $\delta \mathcal{C}_a = 0$ ). Then it follows immediately from eq. (6.2.12) that for this perturbation, we have  $\delta H = 0$ . On the other hand, the fact that  $\chi^a$  is a Killing field of the background solution implies that  $\mathfrak{P}^{ij} = \mathfrak{P}_{ij} = 0$ . Consequently, eq. (6.2.13) yields the result that

"surface terms" = 
$$0$$
 (6.2.14)

These surface terms are readily evaluated. Since  $N^a=\chi^a$  approaches a linear combination of a time translation and rotation at infinity (see eq. (6.2.1)), the surface term from infinity is directly related to the changes,  $\Delta M$  and  $\Delta J$ , in the mass and angular momentum ("as measured at infinity") produced by the perturbation ( $\delta h_{ij}$ ,  $\delta \pi^{ij}$ ). On the other hand, the surface term from  $\sigma$  is readily evaluated to be proportional to  $\kappa$  times the change,  $\Delta A$ , in the area of  $\sigma$  produced by the perturbation (see Sudarsky and Wald (1992)). Consequently, eq. (6.2.14) takes the explicit form

$$\frac{1}{8\pi} \kappa \Delta A = \Delta M - \Omega \Delta J \qquad (6.2.15)$$

which is our desired "equilibrium state" version of the first law. Note that our derivation shows that eq. (6.2.15) actually holds for any (nonsingular, asymptotically flat) perturbation satisfying the constraints, i.e., the perturbation may be nonstationary. Note also that this derivation admits a straight-forward generalization to the case where matter fields are present, provided only that the combined Einstein-matter system can be given a Hamiltonian formulation (see Sudarsky and Wald (1992) for the case of the Einstein-Yang-Mills system).

Indeed, much more generally, the basic form of eq. (6.2.15) can be shown to hold in an arbitrary diffeomorphism invariant theory of gravity (with arbitrary matter fields) derived from a Lagrangian (Wald 1993c, lyer and Wald 1994). In this approach, one starts from a Lagrangian of the general form

$$L = L(g_{ab}, R_{abcd}, \nabla_e R_{abcd}, ...; \psi, \nabla_a \psi, ...)$$
 (6.2.16)

in an n-dimensional spacetime, where  $\psi$  denotes the collection of matter fields present in the theory. For each vector field N<sup>a</sup> on spacetime, one defines a Noether current, (most conveniently viewed as an (n-1)-form, j) associated with the local symmetry correspond-

{158}------------------------------------------------

ing to the infinitesimal diffeomorphism generated by Na. When the equations of motion hold, the Noether current can be derived from a potential, i.e., we have  $\mathbf{j} = d\mathbf{Q}$  for an (n-2)-form,  $\mathbf{Q}$ , referred to as the Noether charge. Integration over the hypersurface  $\Sigma$  of the preceding paragraph of a general identity involving the variation of the Noether current then yields an equation of the general form (6.2.15), with the left side replaced by the variation,  $\Delta J_{\sigma} \mathbf{Q}$ , of the Noether charge associated the Killing field  $\chi^a$  integrated over the bifurcation surface  $\sigma$  (Wald, 1993c). Further analysis (lyer and Wald 1994) shows that

$$\Delta \int_{\sigma} \mathbf{Q} = \frac{\kappa}{2\pi} \Delta \mathbf{S} \tag{6.2.17}$$

where S is given by

$$S = -2\pi \int_{\sigma} E^{abcd} n_{ab} n_{cd}$$
 (6.2.18)

where  $n_{ab}$  denotes the binormal to  $\sigma$ , and  $E^{abcd}$  is simply the functional derivative of L with respect to  $R_{abcd}$  holding  $g_{ab}$  (and  $\nabla_a$ ) fixed,

$$\mathsf{E}^{\mathsf{abcd}} \equiv \frac{\delta \mathsf{L}}{\delta \mathsf{R}_{\mathsf{abcd}}} \tag{6.2.19}$$

i.e.,  $E^{abcd}=0$  would be the Euler-Lagrange equation of motion for  $R_{abcd}$  if one pretended that it were a dynamical field, independent of the metric, in the Lagrangian (6.2.16). Thus, for example, in the case of vacuum general relativity, we have

$$L = \frac{1}{16\pi} R = \frac{1}{16\pi} g^{ac} g^{bd} R_{abcd}$$
 (6.2.20)

so we simply obtain

$$\mathsf{E}^{\mathsf{abcd}} = \frac{1}{16\pi} \, \mathsf{g}^{\mathsf{ac}} \mathsf{g}^{\mathsf{bd}} \tag{6.2.21}$$

and

$$S = -2\pi \int_{\sigma} \frac{1}{16\pi} g^{ac}g^{bd} n_{ab}n_{cd}$$
$$= -\frac{1}{8} \int_{\sigma} n^{ab}n_{ab} = \frac{1}{4} A \qquad (6.2.22)$$

{159}------------------------------------------------

Hence, we recover eq. (6.2.15). However, this derivation shows that eq. (6.2.15) continues to hold in an arbitrary diffeomorphism invariant theory provided that we replace the quantity A/4 by the local, geometrical quantity (6.2.18).

We remark that comparison of eqs. (6.2.8) and (6.2.15) shows that the differences in mass, angular momentum, and area of two nearby stationary black hole solutions satisfy precisely the relationship required by the "physical process" argument given above. If the "physical process" and "equilibrium state" versions of the first law disagreed, it would establish an inconsistency in the assumptions that went into the derivation of the "physical process" version, particularly the assumptions that the black hole is not destroyed by the process of throwing matter into it and that it "settles down" to a stationary final state. The fact that the two versions of the first law do agree is correspondingly strong support for the consistency of the idea that gravitational collapse always results in a predictable black hole.

We are now in a position to describe the remarkable mathematical analogy between the ordinary laws of thermodynamics and certain laws (derived above) satisfied by black holes in classical general relativity. First we explain the framework of this analogy. We view a black hole as being analogous to an ordinary dynamical system with many degrees of freedom. Now, for a general, nonequilibrium state of an ordinary dynamical system, we must use the detailed, "microscopic" structure of the system to describe its state, and we must use the full "microscopic" dynamical laws to determine its time evolution. Similarly, for a general, nonstationary black hole, we must use the detailed initial data of general relativity to describe its state and the full Einstein equation to determine its time evolution. However, states of thermal equilibrium of an ordinary dynamical system can be characterized by a very small number of "state parameters" such as total energy, E, and volume, V. Similarly, stationary black hole states also can be characterized by a very small number of parameters. Indeed, it is known that in the electrovac case, the mass, M, angular momentum, J, and electric and magnetic charges, Q<sub>E</sub> and Q<sub>M</sub>, characterize a stationary black hole (see Wald (1984a) for a summary of the black hole uniqueness theorems). For thermal equilibrium states, one can define additional quantities such as temperature, T, and pressure, P. Similarly, for a stationary black hole-where the event horizon is a Killing horizon-