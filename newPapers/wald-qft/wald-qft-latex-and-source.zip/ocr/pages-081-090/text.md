

{80}------------------------------------------------

on  $\mathfrak{F}_s(\mathfrak{K}_1)$  and  $\mathfrak{F}_s(\mathfrak{K}_2)$ , respectively. By complex linearity, eq. (4.4.3) must hold for all  $\psi \in \mathcal{S}^{\mathbb{C}}$ . By continuity, eq. (4.4.3) also must hold for all  $\psi \in \mathcal{S}_{\mu}^{\mathbb{C}}$ . Let  $A:\mathfrak{K}_2 \to \mathfrak{K}_1$  and  $B:\mathfrak{K}_2 \to \overline{\mathfrak{K}}_1$  denote the restrictions of  $K_1$  and  $\overline{K}_1$ , respectively, to the subspace  $\mathfrak{K}_2$  of  $\mathcal{S}_{\mu}^{\mathbb{C}}$ . Similarly, let  $C:\mathfrak{K}_1 \to \mathfrak{K}_2$  and  $D:\mathfrak{K}_1 \to \overline{\mathfrak{K}}_2$  denote the restrictions of  $K_2$  and  $\overline{K}_2$ , respectively, to  $\mathfrak{K}_1$ . Then, choosing  $\psi \in \overline{\mathfrak{K}}_1$  and writing  $\chi = \overline{\psi}$ , we see that unitary equivalence implies that for all  $\chi \in \mathfrak{K}_1$ , we have

$$Ua_{1}(\overline{\chi})U^{-1} = a_{2}(\overline{C\chi}) - a_{2}^{\dagger}(\overline{D\chi})$$
 (4.4.4)

It follows from eq. (4.4.2) that the operators A, B, C, D are bounded. In addition, these operators satisfy a number of properties arising directly from their definition. In particular, let  $\chi$ ,  $\psi \in \Re_2$ . Then, we have

$$(\psi, \chi)_{\mathcal{H}_{2}} = -i\Omega(\overline{\psi}, \chi)$$

$$= -i\Omega(\overline{K_{1}\psi + \overline{K_{1}\psi}}, K_{1}\chi + \overline{K_{1}\chi})$$

$$= (A\psi, A\chi)_{\mathcal{H}_{3}} - (B\psi, B\chi)_{\overline{\mathcal{H}_{3}}}, \qquad (4.4.5)$$

(No "cross terms" arise since  $\Omega(\overline{\rho},\lambda)=0$  for all  $\rho\in\overline{\mathfrak{X}}_1,\,\lambda\in\mathfrak{X}_1.$ ) Thus, we obtain

$$A^{\dagger}A - B^{\dagger}B = I \tag{4.4.6}$$

A similar calculation starting with  $\chi \in \mathcal{K}_2$ ,  $\psi \in \overline{\mathcal{K}}_2$  yields

$$A^{\dagger} \overline{B} = B^{\dagger} \overline{A} \tag{4.4.7}$$

where the bar denotes the corresponding map between the complex conjugate spaces (see Appendix A.2). In an exactly similar manner, we obtain

$$C^{\dagger}C - D^{\dagger}D = I \tag{4.4.8}$$

$$C^{\dagger}\overline{D} = D^{\dagger}\overline{C}$$
 (4.4.9)

In addition, for  $\psi \in \mathcal{H}_1$ ,  $\chi \in \mathcal{H}_2$ , we find

{81}------------------------------------------------

$$(\psi, A\chi)_{\mathfrak{K}_{1}} = -i\Omega(\overline{\psi}, K_{1}\chi)$$

$$= -i\Omega(\overline{\psi}, K_{1}\chi + \overline{K}_{1}\chi)$$

$$= -i\Omega(\overline{\psi}, \chi)$$

$$= -i\Omega(\overline{K_{2}\psi + \overline{K_{2}\psi}}, \chi)$$

$$= -i\Omega(\overline{K_{2}\psi}, \chi)$$

$$= (C\psi, \chi)_{\mathfrak{K}_{2}} \qquad (4.4.10)$$

Thus, we have

$$A^{\dagger} = C \tag{4.4.11}$$

Similarly, we obtain

$$\overline{\mathsf{B}}^\dagger = -\mathsf{D} \tag{4.4.12}$$

Note that eqs. (4.4.6) and (4.4.8) imply that  $A^{-1}$  and  $C^{-1}$  exist as bounded operators.

A unitary map U satisfying eq. (4.4.4) with A, B, C, D satisfying eqs. (4.4.6)-(4.4.9) and (4.4.11)-(4.4.12) is known as a *Bogoliubov transformation*. We wish to determine the conditions under which a Bogoliubov transformation exists and, if it does, to obtain it explicitly. We proceed straightforwardly by supposing that U exists and attempting to solve for

$$\Psi = U |0>_1$$
 (4.4.13)

We expand  $\Psi \in \mathcal{F}_s(\mathfrak{R}_2)$  in terms of its "n-particle amplitudes" as

$$\Psi = c (1, \psi^a, \psi^{ab}, \psi^{abc}, ...)$$
 (4.4.14)

(The index notation used here is explained in Appendix A.3. For convenience in defining  $\psi^{a_1...a_n}$ , we have implicitly assumed in writing this equation that the "vacuum entry" of  $\Psi$  is nonzero; that there is no loss of generality in this assumption can be seen easily from the analysis given below.). Let  $\xi \in \Re_2$ , choose  $\chi = C^{-1}\xi$ , and apply eq. (4.4.4) to  $\Psi$ . The left side vanishes, so we obtain, for all  $\xi \in \Re_2$ ,

$$0 = \left[a_2(\overline{\xi}) - a_2^{\dagger}(\mathfrak{C}\overline{\xi})\right] \Psi \tag{4.4.15}$$

{82}------------------------------------------------

where the operator  $\mathfrak{E}: \overline{\mathfrak{R}}_2 \rightarrow \mathfrak{R}_2$  is defined by

$$\mathcal{E} = \overline{D} \, \overline{C}^{-1} \tag{4.4.16}$$

It follows from eq. (4.4.9) that  $\mathfrak E$  is symmetric, i.e.,  $\overline{\mathfrak E}^{\dagger} = \mathfrak E$ .

Equation (4.4.15) yields an infinite sequence of equations for the n-particle amplitudes,  $\psi^a$ ,  $\psi^{ab}$ ,  $\psi^{abc}$ ,..., of  $\Psi$ . The first four of these equations are,

$$\overline{\xi}_a \psi^a = 0 \tag{4.4.17}$$

$$\sqrt{2} \ \overline{\xi}_{a} \ \psi^{ab} = (\mathfrak{E}\overline{\xi})^{b} \tag{4.4.18}$$

$$\sqrt{3} \,\overline{\xi}_{a} \,\psi^{abc} = \sqrt{2} \,(\mathfrak{E}\overline{\xi})^{(b} \psi^{c)} \tag{4.4.19}$$

$$\sqrt{4} \ \overline{\xi}_{a} \ \psi^{abcd} = \sqrt{3} \ (\mathfrak{E}\overline{\xi})^{(b} \psi^{cd)}$$
 (4.4.20)

where it is understood that these relations must hold for all  $\xi \in \Re_2$ . The unique solution to eq. (4.4.17) is  $\psi^a = 0$ . By induction all the n-particle amplitudes vanish for odd n. On the other hand, eq. (4.4.18) implies that—when viewed as a map from  $\Re_2 \to \Re_2 - \psi^{ab}$  must equal  $\mathcal{E}/\sqrt{2}$ . However,  $\psi^{ab}$  is not an arbitrary map: It is symmetric,  $\psi^{ab} = \psi^{ba}$ , and satisfies  $\psi^{ab}$   $\overline{\psi}_{ab} < \infty$  (see sections A.2 and A.3 of the Appendix). We already noted above that  $\mathcal{E}$  is symmetric. Hence, a solution to eq. (4.4.18) exists if and only if  $\mathcal{E}$  satisfies

$$\operatorname{tr}(\mathfrak{E}^{\dagger}\mathfrak{E}) < \infty.$$
 (4.4.21)

Since both C and C<sup>-1</sup> are bounded, eq. (4.4.21) is equivalent to the condition  $tr(D^{\dagger}D) < \infty$ ; by eq. (4.4.12) and the cyclic property of traces, it also is equivalent to  $tr(B^{\dagger}B) < \infty$ . In terms of the original quantities  $\mu_1$  and  $\mu_2$ , these conditions, in turn, are equivalent to the condition that the linear map  $Q: \mathcal{S}_u \to \mathcal{S}_u$  defined by

$$\mu_1(\psi_1, Q\psi_2) = \mu_2(\psi_1, \psi_2) - \mu_1(\psi_1, \psi_2)$$
 (4.4.22)

be of trace class.

If eq. (4.4.21) holds, by induction the solution obtained for  $\Psi$  is

$$\Psi = c(1, 0, \sqrt{\frac{1}{2}} \epsilon^{ab}, 0, \sqrt{\frac{3 \cdot 1}{4 \cdot 2}} \epsilon^{(ab} \epsilon^{cd)}, 0, \dots)$$
 (4.4.23)

{83}------------------------------------------------

where  $\varepsilon^{ab}$  denotes the "two-particle state" (i.e., the element of  $\mathfrak{K}_2 \otimes \mathfrak{K}_2$ ) corresponding to the map  $\mathfrak{E}$ . It can be shown (Wald 1979a) that eq. (4.4.23) defines a (finite norm) state in  $\mathfrak{F}_s(\mathfrak{K}_2)$ . The constant c is determined (up to phase) by the condition that  $\|\Psi\|=1$ , as is required for U to be unitary.

The above analysis has merely determined the action of U (if it exists) on the state  $10>_1$ , given that eq.(4.4.21) holds. However, the action of U on an arbitrary one-particle state,  $a_1^{\dagger}(\chi)10>_1$ , is determined by applying the adjoint of eq. (4.4.4) to  $\Psi=U10>_1$ . By induction, we similarly can calculate uniquely how U must act on an arbitrary n-particle state. Since these states span  $\mathfrak{F}_s(\mathfrak{R}_1)$  we see that U is uniquely determined. Existence and unitarity of U (given eq. (4.4.21)) then can be established straightforwardly (see Wald (1979a)). Consequently, we obtain the following theorem, which achieves the main mathematical objective set forth at the beginning of this section:

Theorem 4.4.1: The necessary and sufficient conditions for the quantum field theories defined by the norms  $\mu_1$  and  $\mu_2$  to be unitarily equivalent are that (a) eq. (4.4.2) holds and (b) the operator Q defined by eq. (4.4.22) be of trace class (or, equivalently, that eq. (4.4.21) holds, which, in turn, is equivalent to the conditions  $tr(D^{\dagger}D) < \infty$  or  $tr(B^{\dagger}B) < \infty$ ).

With regard to the physical applications of our results, eq. (4.4.23) gives an explicit solution to the problem of spontaneous particle creation from the vacuum in spacetimes which are asymptotically stationary in the past and future. (Note that eq. (4.4.23) also may be interpreted as yielding the most general form of a "squeezed vacuum state"; we had promised in section 2.3 that we would provide such a formula.) One immediate consequence of eq. (4.4.23), is that particles always are created in pairs. Furthermore, since  $\mathfrak{E} \neq 0$  if and only if  $D \neq 0$ , we see that there will be a nonvanishing amplitude for spontaneous particle creation if and only if, classically, some solution which oscillates with purely positive frequency in the asymptotic past picks up a nonvanishing negative frequency part in the asymptotic future.

Note that if & is finite dimensional, conditions (a) and (b) of theorem 4.4.1 hold automatically, so unitary equivalence always holds. Thus, our results are consistent with the Stone-von Neumann

{84}------------------------------------------------

theorem. However, if & is infinite dimensional these conditions need not hold, and unitarily inequivalent constructions exist. particular, even if eq. (4.4.2) holds, eq. (4.4.21) is a nontrivial re-To show this—and, in particular, thereby demonstrate striction. explicitly the existence of unitarily inequivalent constructions-let  $\mu_1: A \times A \to \mathbb{R}$  satisfy eq. (4.2.7). (As discussed at the end of section 4.3, there is no difficulty in obtaining such a  $\mu_1$  in any globally hyperbolic, curved spacetime.) We complete & in this norm to obtain a real Hilbert space  $\&\mu_1$ . By a Gram-Schmidt type procedure, we may choose an orthonormal basis of  $\&\mu_1$  (in the inner product  $2\mu_1$ ) of the form  $\{\psi_1, \chi_1, \psi_2, \chi_2, \dots\}$  such that  $\Omega(\psi_i, \psi_i) = \Omega(\chi_i, \chi_i) = 0$  and  $\Omega(\psi_i, \chi_j) = \delta_{ij}$ . We write the basis expansion of any  $\psi \in \mathcal{A}_{\mu_1}$  as

$$\psi = \sum_{i} [\alpha_i \ \psi_i + \beta_i \ \chi_i] \tag{4.4.24}$$

Now, let {c<sub>i</sub>} be any bounded sequence of real numbers such that

$$\sum_{i} \sinh^2 c_i = \infty \tag{4.4.25}$$

Define  $\mu_2: A \times A \to \mathbb{R}$  by

$$\mu_2(\psi,\,\psi') = \sum_i \{\alpha_i\,\alpha_i'[\text{cosh } c_i + \,\text{sinh } c_i]^2 \,+\, \beta_i\,\beta_i'[\text{cosh } c_i - \,\text{sinh } c_i]^2\}\,(4.4.26)$$

for all  $\psi, \psi' \in \mathcal{S}$ . Then it is straightforward to verify that  $\mu_2$  satisfies eq. (4.2.7), that eq. (4.4.2) holds, but that eq. (4.4.21) fails. Thus, both  $\mu_1$  and  $\mu_2$  give rise to well defined quantum field theory constructions, but these quantum field theories are unitarily inequivalent.

As discussed at the end of section 4.2, there does not appear to be any natural choice of  $\mu$  in an arbitrary globally hyperbolic curved spacetime, nor does there appear to be any natural choice of unitary equivalence class of µ's in spacetimes with a noncompact Cauchy surface. It might seem that the existence of unitarily inequivalent constructions and the lack of a criterion as to which construction to choose would pose an insurmountable obstacle to the formulation of quantum field theory in curved spacetime. However, in the next section, we shall see how the algebraic formulation quantum field theory provides a completely satisfactory means of overcoming this apparent difficulty.

{85}------------------------------------------------

## 4.5 The Algebraic Approach

In the approach usually taken to the formulation of a quantum theory, one first constructs states as vectors in a Hilbert space \$\mathscr{S}\$ (or, more generally, as density matrices on \$\mathscr{S}\$). One then defines observables as operators on \$\mathscr{S}\$ which "act upon" the states. The basic strategy of the algebraic approach is, in essence, to reverse the roles played by states and observables in the following sense: One begins by constructing observables as elements of an abstract algebra. One then defines states as objects which "act upon" observables by associating a real number to each observable. This action corresponds to "taking expectation values" in the usual approach. The crucial advantage of the algebraic approach is that it thereby allows one to treat all states—in particular, states arising in unitarily inequivalent quantum field theory constructions—on an equal footing, thereby enabling one to define the theory without the need to select a preferred construction.

The key observation which makes the algebraic approach viable for quantum field theory in curved spacetime is that—although unitarily inequivalent field theory constructions exist—the algebraic structure of the field operators in the unitarily inequivalent constructions are still "the same". In other words, even when  $\{\mathfrak{F}_s(\mathfrak{K}_1),\,\widehat{\Omega}_1(\psi,\cdot)\}$  and  $\{\mathfrak{F}_s(\mathfrak{K}_2),\,\widehat{\Omega}_2(\psi,\cdot)\}$  are unitarily inequivalent, the algebraic relations satisfied by the collection of operators  $\{\widehat{\Omega}_1(\psi,\cdot)\}$  on  $\mathfrak{F}_s(\mathfrak{K}_1)$  are the same as those satisfied by the operators  $\{\widehat{\Omega}_2(\psi,\cdot)\}$  on  $\mathfrak{F}_s(\mathfrak{K}_2)$ . This assertion can be made mathematically precise as follows:

Let  $(\mathcal{S}, \Omega)$  be a symplectic vector space with inner product  $\mu: \mathcal{S} \times \mathcal{S} \to \mathbb{R}$  satisfying eq. (4.2.7). Perform the quantum field construction described in section 4.2 to obtain the Hilbert space  $\mathfrak{F} = \mathfrak{F}_s(\mathfrak{R})$  and self-adjoint operators  $\widehat{\Omega}(\psi, \cdot)$ . Define the unitary operators  $\widehat{W}(\psi)$  by

$$\widehat{W}(\psi) = \exp[i\widehat{\Omega}(\psi, \cdot)] \tag{4.5.1}$$

Then the  $\hat{W}(\psi)$  satisfy the Weyl relations:

$$\hat{W}(\psi_1) \ \hat{W}(\psi_2) = \exp[i\Omega(\psi_1, \psi_2)/2] \hat{W}(\psi_1 + \psi_2) \tag{4.5.2}$$

$$\hat{W}^{\dagger}(\psi) = \hat{W}(-\psi) \tag{4.5.3}$$

{86}------------------------------------------------

(see eqs. (2.2.6) and (2.2.7)). Now, the collection,  $\mathfrak{Z}(\mathfrak{F})$ , of all bounded linear maps on  $\mathfrak{F}$  has the natural structure of a C\*-algebra (defined in Appendix A.1), with the "\*-operation" corresponding to taking adjoints. The linear maps which can be expressed as finite, complex linear combinations of  $\hat{W}(\psi)$ 's comprise a subalgebra of  $\mathfrak{Z}(\mathfrak{F})$ . By taking the closure of this subalgebra in the norm provided by  $\mathfrak{Z}(\mathfrak{F})$ , we obtain a C\*-subalgebra,  $\mathcal{A}$ , of  $\mathfrak{Z}(\mathfrak{F})$ , known as the Weyl algebra. The key fact (Slawny 1972) about this construction is that  $\mathcal{A}$ —viewed as an abstract C\*-algebra—does not depend upon the choice of  $\mu$ . In other words, although two inner products  $\mu_1$  and  $\mu_2$  satisfying eq. (4.2.7) may define unitarily inequivalent quantum field theory constructions, the C\*-algebras,  $\mathcal{A}_1$  and  $\mathcal{A}_2$  to which they give rise are isomorphic.

This fact allows us to define the *fundamental observables* for quantum field theory in a curved spacetime to be elements of the Weyl algebra,  $\mathcal{A}$ , constructed from the symplectic vector space of classical solutions in the manner described above (choosing any  $\mu$  which satisfies eq. (4.2.7)). We then define a *state*,  $\omega$ , of the quantum field to be a linear map  $\omega \colon \mathcal{A} \to \mathbb{C}$  satisfying the positivity condition

$$\omega (A^*A) \stackrel{>}{=} 0$$
 (4.5.4)

for all A∈A, as well as the normalization condition

$$\omega\left(I\right)=1\tag{4.5.5}$$

where I denotes the identity element of A.

Several points concerning these definitions should be noted. First, although the properties of the Weyl algebra,  $\mathcal{A}$ , related to its C\*-algebra norm are useful for some purposes, for most applications only the \*-algebra structure is needed. Natural alternative choices for a \*-algebra of fundamental observables can be made (such as the algebra  $\mathcal{A}'$  described in Kay and Wald (1991)). Such alternative choices give rise to technically inequivalent notions of states.

Second, the two-point function of the quantum field in state  $\omega$  may be defined in terms of its action on Weyl algebra elements  $W(\psi)$  by

{87}------------------------------------------------

$$\langle \widehat{\Omega}(\psi_1, \cdot) | \widehat{\Omega}(\psi_2, \cdot) \rangle_{\omega} = -\frac{\partial^2}{\partial s \partial t} \left\{ \omega [W(s\psi_1 + t\psi_2)] \exp(ist\Omega(\psi_1, \psi_2)/2) \right\} \Big|_{s=t=0}$$

$$(4.5.6)$$

provided that the derivatives appearing on the right side of eq. (4.5.6) exist. (The two-point function is undefined if these derivatives do not exist.) Using the correspondence between solutions and test functions given by lemma 3.2.1, we may view the two-point function as a bi-distribution on spacetime, which we shall denote as  $<\phi(x_1)\phi(x_2)>_{\omega}$ . The higher n-point functions of the quantum field are defined similarly. The specification of a state,  $\omega$ , on  ${\cal A}$  corresponds, in essence, to the specification of all the smeared n-point functions of the quantum field.

Third, although  $\mathcal A$  thus encompasses a wide class of observables, it should be noted that there are other physically relevant observables in the theory besides these. In particular, the stressenergy tensor of the quantum field is not in any sense represented as an element of  $\mathcal A$ . Thus, one should not view  $\mathcal A$  as encompassing all observables of the theory; rather, one should view  $\mathcal A$  as encompassing a "minimal" collection of observables, which is sufficiently large to enable the theory to be formulated. One may later wish to enlarge  $\mathcal A$  and/or further restrict the notion of "state" in order to accommodate the existence of additional observables. Indeed, as we shall see in section 4.6, the restriction to states which satisfy the "Hadamard condition" appears necessary in order to define the expected stress-energy tensor.

Finally, it is worth commenting that the simple form of the positivity condition (4.5.4) on states is quite deceptive. Typically, it is highly nontrivial to check that a plausible candidate for a state actually satisfies eq. (4.5.4). In particular, since eq. (4.5.4) is nonlinear in A, it does *not* suffice to check that eq. (4.5.4) holds for a basis of A.

What is the relationship between the algebraic notion of states defined above and the notion of states arising from the quantum field theory constructions of section 4.2? A quantum field theory construction gives rise to the Hilbert space  $\mathfrak{F}_s(\mathfrak{X})$  and a representation of the Weyl algebra,  $\mathcal{A}$ , on  $\mathfrak{F}$ . However, given any density matrix,  $\rho: \mathfrak{F} \to \mathfrak{F}$  on any Hilbert space,  $\mathfrak{F}$ , which carries a representation,  $\pi: \mathcal{A} \to \mathfrak{X}(\mathfrak{F})$ , of  $\mathcal{A}$ , we obtain an algebraic state  $\omega: \mathcal{A} \to \mathbb{C}$  via

{88}------------------------------------------------

$$\omega(A) = tr[\rho \pi(A)] \tag{4.5.7}$$

Thus, in particular, all states arising in all quantum field theory constructions of section 4.2 give rise to algebraic states. A converse of this result is contained in the following theorem:

Theorem 4.5.1 (GNS construction): Let  $\mathcal{A}$  be a C\*-algebra with identity element and let  $\omega: \mathcal{A} \to \mathbb{C}$  be a state. Then there exists a Hilbert space  $\mathfrak{F}$ , a representation  $\pi: \mathcal{A} \to \mathfrak{F}$  ( $\mathfrak{F}$ ), and a vector  $|\Psi\rangle \in \mathfrak{F}$  such that

$$\omega(A) = \langle \Psi | \pi(A) | \Psi \rangle \tag{4.5.8}$$

satisfying the additional property that  $|\Psi\rangle$  is *cyclic*, i.e., the vectors  $\{\pi(A)|\Psi\rangle\}$  for all  $A\in\mathcal{A}$  comprise a dense subspace of  $\mathfrak{F}$ . Furthermore, the triple  $(\mathfrak{F},\pi,|\Psi\rangle)$  is uniquely determined (up to unitary equivalence) by these properties.

Sketch of the Construction of  $(\mathcal{F}, \pi, |\Psi\rangle)$ : We use the state  $\omega$  to define the bilinear map,

$$\langle A, B \rangle_{\mathcal{A}} \equiv \omega(A^* B) \tag{4.5.9}$$

taking  $\overline{\mathcal{A}} \times \mathcal{A} \to \mathbb{C}$ . This map is non-negative by eq. (4.5.4), so eq. (4.5.9) will define an inner product on  $\mathcal{A}$  unless it happens that  $\omega(A^*A) = 0$  for some  $A \neq 0$ . However, if that occurs, we can "factor out" by such A's, in which case eq. (4.5.9) defines a positive-definite inner product on the factor space. We then complete  $\mathcal{A}$  (or the factor space) in the norm defined by (4.5.9) to get a Hilbert space  $\mathfrak{F}$ . We then get a representation,  $\pi: \mathcal{A} \to \mathfrak{X}(\mathfrak{F})$ , by having  $\mathcal{A}$  act upon itself (or its factor space) by multiplication and extending this action to  $\mathfrak{F}$  by continuity. Finally, the desired cyclic vector  $|\Psi\rangle\in \mathfrak{F}$  simply corresponds to the identity element of  $\mathcal{A}$ . Further details of the proof of theorem 4.5.1 can be found, e.g., in Simon (1972).  $\square$ 

Given an algebraic state,  $\omega$ , we refer to the collection of all density matrices on its GNS Hilbert space as the *folium* of  $\omega$ .

To illustrate further the algebraic viewpoint on states and the nature of the GNS construction, let  $(\mathcal{A}, \Omega)$  denote the symplectic vector space of solutions to the Klein-Gordon equation on a globally hyperbolic spacetime, and let  $\mu: \mathcal{A} \times \mathcal{A} \to \mathbb{R}$  be an arbitrary (real) inner

{89}------------------------------------------------

product on  $\mathcal{S}$ . Define  $\omega: \mathcal{A} \to \mathbb{C}$  by the condition that

$$\omega[W(\psi)] = \exp(-\mu(\psi,\psi)/2)$$
 (4.5.10)

for all  $\psi \in \mathcal{A}$ ;  $\omega$  then uniquely extends to  $\mathcal{A}$  by linearity and continuity. Although  $\omega$  clearly satisfies the positivity condition (4.5.4) for the elements of the form  $W(\psi)$ , it does not automatically satisfy this condition for (complex) linear combinations of these elements. However, it turns out that the condition

$$\mu(\psi_1,\psi_1) \ \mu(\psi_2,\psi_2) \stackrel{\geq}{=} \frac{1}{4} [\Omega(\psi_1,\psi_2)]^2$$
 (4.5.11)

is necessary and sufficient for the positivity of  $\omega$  on  ${\cal A}$ . In particular, when  $\mu$  satisfies eq. (4.2.7),  $\omega$  is a state. The GNS construction for  $\omega$  in this case is equivalent to the construction given in section 4.2 of the Fock space,  ${\mathfrak F}_s({\mathfrak R})$ , with the field operators represented by eq. (4.2.8), and with  $|\Psi\rangle=|0\rangle$  serving as the cyclic vector. Thus, all states in all quantum field theory constructions of the type described in section 4.2 are encompassed by the folia of states of the form (4.5.10) with  $\mu$  satisfying (4.2.7).

The map  $\omega: \mathcal{A} \to \mathbb{C}$  determined by eq. (4.5.10) also defines a state when  $\mu$  merely satisfies eq. (4.5.11) without "saturating" this inequality, i.e., when eq. (4.2.7) fails to hold. Any state  $\omega$  of the form (4.5.10) with  $\mu$  satisfying (4.5.11) is referred to as a *quasi-free* state. The GNS construction for an arbitrary quasi-free state again possesses a natural Fock space structure (see, e.g., Kay and Wald (1991) for details). However, if  $\mu$  fails to satisfy eq. (4.2.7), then the quasi-free state fails to be a pure state (see below) and the representation of  $\mathcal A$  provided by the GNS construction is reducible. In stationary spacetimes, thermal equilibrium states at finite temperature are represented by quasi-free states which fail to satisfy eq. (4.2.7). In a spacetime with a noncompact Cauchy surface, states in the folium of any quasi-free state with  $\mu$  satisfying eq. (4.2.7).

Even the folia of all quasi-free states do not by any means encompass all algebraic states. Thus, the algebraic notion of states corresponds to an enlargement of the notion of states that goes significantly beyond that obtained by all possible quantum field theory constructions of the type considered in section 4.2. However, in my view, little, if any, harm is done by this enlargement. In par-