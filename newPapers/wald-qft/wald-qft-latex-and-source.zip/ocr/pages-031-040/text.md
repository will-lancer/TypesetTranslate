

{30}------------------------------------------------

position and momentum operators are represented in the standard way—no correspondence map "^" exists such that eq. (2.2.1) holds for all observables. However, it turns out that in the case where  $\mathfrak{N}=T_{\bullet}(\P_{\bullet})$  (where  $\P_{\bullet}$  need not have vector space structure), it is possible to choose  $\mathfrak{F}$  and a correspondence map "^" such that for the canonical coordinates  $(q_1,...,q_n; p_1,...,p_n)$  on  $\mathfrak{N}$  arising from any coordinates  $(q_1,...,q_n)$  on  $\P_{\bullet}$ , we have

$$[\hat{q}_{\mu}, \hat{q}_{\nu}] = 0, \ [\hat{p}_{\mu}, \hat{p}_{\nu}] = 0$$
 (2.2.2)

$$[\hat{q}_{\mu}, \hat{p}_{\nu}] = i \{q_{\mu}, p_{\nu}\} = i\delta_{\mu\nu}I$$
 (2.2.3)

where I denotes the identity operator (and we omit writing the "^" over it.). Equivalently (since this can be done for all choices of coordinates on 4), all observables which are at most linear in the momentum can be represented such that eq. (2.2.1) holds; see, e.g., Appendix C of Ashtekar (1991) for further discussion of this correspondence.

We now restrict attention to the case where property (1) of the definition of linear dynamical systems given in the previous section holds, so that  $\P$  (and, hence,  $\P$ ) has a natural vector space structure. (See Isham (1984) for a discussion of an approach applicable to some cases where  $\P$  does not have a natural vector space structure.) Then eqs. (2.2.2)-(2.2.3) for classical linear observables can be expressed as (see eq. (2.1.10))

$$[\hat{\Omega}(y_1,\cdot), \hat{\Omega}(y_2,\cdot)] = -i \Omega(y_1, y_2) I \qquad (2.2.4)$$

for all  $y_1,y_2\in \mathbb{N}$ . (Note that here and below, for typographical reasons, we insert the "^" over  $\Omega$  only rather than over the entire expression  $\Omega(y,\cdot)$ , as would be more logically consistent.)

Some technical difficulties arise when one attempts to work with relation (2.2.4) because the self-adjoint operators appearing in these equations are unbounded and, hence, only densely defined; thus, for example, their composition (and, hence, commutator) need not be well defined. For this reason it is convenient to work with the following "exponentiated version" of eq. (2.2.4): We write

$$W(y) = \exp[i \Omega(y, \cdot)] \qquad (2.2.5)$$

{31}------------------------------------------------

and seek a correspondence map "^" for which  $\hat{W}(y)$  is unitary, varies continuously with y in the "strong operator topology" (defined, e.g., in Reed and Simon (1980)), and satisfies,

$$\hat{W}(y_1) \hat{W}(y_2) = \exp(i\Omega(y_1, y_2)/2) \hat{W}(y_1 + y_2)$$
 (2.2.6)

as well as

$$\hat{\mathbf{W}}^{\dagger}(\mathbf{y}) = \hat{\mathbf{W}}(-\mathbf{y}) \tag{2.2.7}$$

Equations (2.2.6) and (2.2.7)—known as the *Weyl relations*—together with the requirement of strong continuity are formally equivalent to eq. (2.2.4), but, since the operator  $\hat{W}(y)$  is unitary, its action is well defined on all vectors, and "domain problems" are thereby avoided.

Thus, a key criterion we impose upon the construction of the quantum theory of a linear system is that our choice of  $\mathfrak F$  and the operators  $\hat{\mathbb W}(y)$  for all  $y\in \mathbb M$  be such that the Weyl relations (2.2.6)-(2.2.7) are satisfied. It might be thought that this would place only a relatively mild restriction upon the choice of Hilbert space  $\mathfrak F$  and unitary operators  $\hat{\mathbb W}(y)$ . Remarkably, this is not the case: The Weyl relations, in essence, uniquely determine  $(\mathfrak F, \hat{\mathbb W}(y))$ . Before stating the theorem which provides this result, we remind the reader of two basic definitions:

First, a Hilbert space  $\mathfrak F$  together with operators  $\hat{\mathbb W}(y)$  satisfying the Weyl relations (2.2.6)-(2.2.7) will be said to be an irreducible representation of the Weyl relations if no proper subspace of  $\mathfrak F$  is invariant under all  $\hat{\mathbb W}(y)$ ; equivalently, given any  $\Psi \in \mathfrak F$ , the span of all vectors of the form  $\hat{\mathbb W}(y)\Psi$  for  $y \in \mathfrak M$  comprises a dense subspace of  $\mathfrak F$ . It is natural to impose the requirement that  $(\mathfrak F,\hat{\mathbb W}(y))$  be irreducible, since, if not,  $\mathfrak F$  could be decomposed as a direct sum of irreducible representations, each of which could be analyzed separately.

Secondly, a Hilbert space  $\mathfrak F$  together with any collection of operators  $V_\alpha\colon \mathfrak F\to \mathfrak F$  will be said to be *unitarily equivalent* to  $(\mathfrak F',V'_\alpha)$  if there exists a unitary map  $U\colon \mathfrak F\to \mathfrak F'$  satisfying  $U^{-1}$   $V'_\alpha$   $U=V_\alpha$  for all  $\alpha$ . If the  $V_\alpha$  are the observables in a quantum theory, all physical predictions will be obtained by taking matrix elements of these operators. Hence, if  $(\mathfrak F,V_\alpha)$  and  $(\mathfrak F',V'_\alpha)$  are unitarily equivalent, the two quantum theories will be physically equivalent in the sense that given any  $\Psi\in \mathfrak F$ , the state  $U\Psi$  in the quantum theory  $(\mathfrak F',V'_\alpha)$  will have exactly the same physical properties as did state  $\Psi$  in the

{32}------------------------------------------------

quantum theory  $(\mathfrak{F}, V_{\alpha})$ .

The key theorem alluded to above is the following:

Theorem 2.2.1 (Stone-von Neumann theorem): Let  $(\mathfrak{M}, \Omega)$  be a finite dimensional symplectic vector space. Let  $(\mathfrak{F}, \hat{W}(y))$  and  $(\mathfrak{F}', \hat{W}'(y))$  be strongly continuous, irreducible, unitary representations of the Weyl relations (2.2.6)-(2.2.7). Then  $(\mathfrak{F}, \hat{W}(y))$  and  $(\mathfrak{F}', \hat{W}'(y))$  are unitarily equivalent.

A proof of the Stone-von Neumann theorem can be found, e.g., in Simon (1972) (see theorem 7.5 of that reference).

In ordinary Schrodinger quantum mechanics, the Hilbert space is taken to be  $\mathfrak{F}=L^2(\mathbb{R}^3)$ , the position operator,  $\hat{q}_{\mu}$ , is represented by multiplication by  $q_{\mu}$ , and the momentum operator,  $\hat{p}_{\mu}$ , is represented by  $-i \partial/\partial \hat{q}_{\mu}$ . The exponentiation of these operators yields an irreducible representation of the Weyl relations. Thus, the Stone-von Neumann theorem provides a powerful justification for the standard choices of Hilbert space and position and momentum operators used in Schrodinger quantum mechanics: Any other choice yielding an (irreducible) representation of the Weyl relations would yield a physically equivalent theory insofar as measurements of position and momentum are concerned. Note, however, that the Stone-von Neumann theorem does not give guidance as to how to represent observables besides position and momentum. As already stated above, a natural prescription (preserving the Poisson-bracket-commutator relationship (2.2.1)) exists for quantum observables corresponding to classical observables which are at most linear in the momentum. However, "factor ordering" ambiguities arise for more general observables and, as mentioned above, no choice of factor ordering can be made so as to satisfy the Poisson-bracket-commutator relationship. Thus, although considerable effort has been devoted to analysis of this issue (see, e.g., Woodhouse (1980)), the question of how to represent general observables in quantum theory remains largely Fortunately, these difficulties will not concern us here, since the only observable aside from position and momentum which we shall consider at this stage is a Hamiltonian operator of the form (2.1.11), for which no factor ordering ambiguities arise.

Finally, we emphasize that in the Stone-von Neumann theorem the hypothesis that  $\mathfrak M$  is finite dimensional is essential. As we shall see explicitly in section 4.4, for an infinite dimensional phase

{33}------------------------------------------------

space (i.e., for a field system), infinitely many unitarily inequivalent irreducible representations of the Weyl relations exist. For fields in flat spacetime, the additional criterion of Poincaré invariance can be imposed to obtain a preferred representation. However, in a general curved spacetime, no such additional criterion exists. Nevertheless, as we shall see, the algebraic framework will allow us to formulate quantum field theory in curved spacetime without the need of selecting a preferred representation.

## 2.3 Harmonic Oscillators

We turn our attention, now, to the quantum theory of a classical, linear, dynamical system of finitely many degrees of freedom, i.e., a collection of coupled harmonic oscillators (with possibly time-dependent masses and spring constants). Harmonic oscillators, of course, are among the most widely studied systems in quantum mechanics, and the reader undoubtedly will be very familiar with the standard construction of the quantum theory of time-independent The first task undertaken in this section will harmonic oscillators. be to suitably rewrite this standard quantum theory of time-independent oscillators in a manner that can be generalized to the case of infinitely many degrees of freedom. This reformulation then will be generalized to the case of a general, linear, dynamical system, with time-dependent Hamiltonian, thereby laying the foundation for our construction of quantum field theory in a general curved space-This final reformulation, of course, is equivalent to the standard Schrodinger quantum mechanics of time-dependent oscillators, but it is likely to look quite unfamiliar to the reader.

Consider, first, the standard, "textbook" single, time-independent, harmonic oscillator with Lagrangian

$$\mathcal{Z} = \frac{1}{2} \dot{q}^2 - \frac{1}{2} \omega^2 q^2 \tag{2.3.1}$$

and corresponding classical Hamiltonian given by

$$H = \frac{1}{2} p^2 + \frac{1}{2} \omega^2 q^2$$
 (2.3.2)

with  $\omega \neq 0$ . In accordance with the remarks following theorem 2.2.1 above, we can construct the quantum theory by taking the Hilbert space,  $\mathcal{F}$ , to be L<sup>2</sup>( $\mathbb{R}$ ) and representing q and p by operators on L<sup>2</sup>( $\mathbb{R}$ )

{34}------------------------------------------------

in the standard way. We define the Hamiltonian operator by eq. (2.3.2), with q and p replaced by their corresponding quantum operators. No factor ordering ambiguities occur here, and the operator version of eq. (2.3.2) uniquely defines a self-adjoint operator  $\hat{H}$ . Since we shall not consider other observables besides q, p, and H here, this completes the specification of the quantum theory of the classical oscillator (2.3.1).

Nevertheless, this quantum theory of a harmonic oscillator can be re-written in a very different looking manner, which will be of considerable importance for quantum field theory. The annihilation and creation operators (usually called lowering and raising operators in the context of harmonic oscillators) play a central role in this new description, and I shall now briefly review their construction within the context of the standard quantum theory. In addition, I shall give the Heisenberg form of the evolution equations, which also will be of considerable importance for field theory.

We define the "annihilation operator", a, by

$$a = \sqrt{\frac{\omega}{2}} q + i \sqrt{\frac{1}{2\omega}} p \qquad (2.3.3)$$

where, here and throughout the following, I shall omit writing "^" above quantum observables except in some cases where confusion with classical observables might arise. It then follows directly that we have

$$[a, a^{\dagger}] = I$$
 (2.3.4)

$$H = \omega (a^{\dagger} a + \frac{1}{2} I)$$
 (2.3.5)

and

$$[H, a] = -\omega a$$
 (2.3.6)

From eq. (2.3.6), we see immediately that in the Heisenberg representation, the annihilation operator satisfies

$$\frac{da_H}{dt} = i[H, a_H] = -i\omega a_H \qquad (2.3.7)$$

where the subscript "H" denotes Heisenberg representation, i.e.,

$$a_{H}(t) = U_{t}^{-1} a U_{t}$$
 (2.3.8)

{35}------------------------------------------------

where  $U_t$  is the time evolution operator, i.e.,  $U_t = \exp(-iHt)$ . Hence, we obtain

$$a_{H}(t) = \exp(-i\omega t) a \qquad (2.3.9)$$

and

$$\begin{aligned} q_H(t) &= \sqrt{\frac{1}{2\omega}} \; (a_H + a_H{}^\dagger) \\ &= \sqrt{\frac{1}{2\omega}} \; \left( \exp(-i\omega t) \; a \, + \, \exp \; (i\omega t) \; a^\dagger \right) \end{aligned} \quad (2.3.10) \end{aligned}$$

Thus, the annihilation operator, a, in the Schrodinger picture is precisely the "positive frequency part" of the Heisenberg position operator,  $q_H$ . The Heisenberg momentum operator,  $p_H$ , is given by

$$p_{H} = \frac{dq_{H}}{dt} \tag{2.3.11}$$

It is worth noting that eqs. (2.3.10) and (2.3.11) uniquely determine the Hamiltonian operator up to a multiple of the identity operator. Namely, if two different Hamiltonians, H and H', give rise to the same formulas for  $q_H$  and  $p_H$ , then by the Heisenberg equation of motion, H-H' must commute with q and p, and hence must commute with all Weyl operators W(y). Since  $(\mathfrak{F}, W(y))$  is irreducible it then follows from Schur's lemma that H-H' is a multiple of the identity operator. Thus, eqs. (2.3.10) and (2.3.11) are equivalent to a specification of H up to a multiple of the identity operator. This means of specifying H is particularly convenient in field theory, where, as we shall see, analogs of eqs. (2.3.10) and (2.3.11) can be obtained straightforwardly, but an "infinite subtraction" would be needed to define H directly.

As is familiar to any student of quantum mechanics, the ground state,  $\Psi_0$ , of the harmonic oscillator satisfies

a 
$$\Psi_0 = 0$$
 (2.3.12)

The nth excited state,  $\Psi_n$ , is given by

$$\Psi_n = \sqrt{\frac{1}{n!}} (a^{\dagger})^n \Psi_0$$
 (2.3.13)

and it satisfies

$$H\Psi_n = (n + \frac{1}{2}) \omega \Psi_n$$
 (2.3.14)

{36}------------------------------------------------

Before rewriting the quantum theory in a new form, we generalize the above considerations to a collection of n decoupled, time-independent harmonic oscillators of frequencies  $\omega_1,...,\omega_n$ . According to the standard rules of quantum theory, the Hilbert space, F, of the combined system is taken to be the tensor product (see Appendix A.2) of the Hilbert spaces,  $\mathfrak{F}_1,...,\mathfrak{F}_n$ , of the individual oscillator systems,

$$\mathfrak{F} = \mathfrak{F}_1 \otimes \ldots \otimes \mathfrak{F}_n \cong L^2(\mathfrak{P}_n) \tag{2.3.15}$$

where & is the classical configuration space of the collection of oscillators. The operators  $q_i$ ,  $p_k$  of the individual oscillators extend to F in an obvious way and yield an irreducible representation of the Weyl relations (2.2.6), (2.2.7). Annihilation and creation operators ai, ait can be introduced for each oscillator as above, and analogs of all the results for the single harmonic oscillator carry over straightforwardly. In particular, the ground state,  $\Psi_0$ , satisfies  $a_i \Psi_0 = 0$  for all i, and the states obtained by applying arbitrary products of creation operators to  $\Psi_0$  span  $\Im$ .

We now give an alternate construction of the quantum theory of n decoupled, time independent harmonic oscillators. This construction will play a key role in our formulation of quantum field theory, since the tensor product construction (2.3.15) will not generalize suitably to the case of infinitely many degrees of freedom. In addition, this reformulation will be of importance for the development of a particle interpretation of quantum field theory.

We shall formulate the alternative construction in terms of the symplectic vector space  $(\mathcal{S}, \Omega)$  of classical solutions of the equations of motion (see the end of section 2.1 above) rather than in terms of phase space, M. (However, we will continue to pass freely between & and M, by identifying a solution with its initial data at t=0.) Our first step in the construction is to complexify &, thereby obtaining a 2n-complex dimensional vector space, denoted & C. We extend  $\Omega$  to  $\mathcal{S}^{\mathbb{C}}$  by (complex) linearity in each variable. Now, consider the map (,):  $\mathcal{S}^{\mathbb{C}} \times \mathcal{S}^{\mathbb{C}} \to \mathbb{C}$  defined by

$$(y_1, y_2) = -i\Omega(\overline{y}_1, y_2)$$
 (2.3.16)

where the bar denotes complex conjugation. Then ( , ) satisfies all the properties of an inner product (see Appendix A.1) on & C, except

{37}------------------------------------------------

that it fails to be positive definite. However, let % denote the n-complex dimensional subspace of % spanned by the (complex) solutions of the classical equations of motion which oscillate with purely positive frequency:

$$q_i(t) = \alpha_i \exp(-i\omega_i t)$$
 (2.3.17)

Then, it is easily verified that (,) is positive definite on  $\Re$ , thus making  $\Re$  into an n-dimensional complex Hilbert space. Additional key properties of  $\Re$  will be pointed out below.

Let  $\mathfrak{F}_s(\mathfrak{K})$  denote the symmetric Fock space associated with  $\mathfrak{K}$ , constructed in the manner explained in Appendix A.2. Let  $\xi_{i\in}\mathfrak{K}$  denote the (complex) positive frequency solution of the classical equations of motion in which only the  $i^{th}$  harmonic oscillator is excited, with  $\xi_i$  normalized so that  $|I|\xi_i|I|^2=(\xi_i,\,\xi_i)=1$ . Then  $\{\xi_i\}$  comprises an orthonormal basis of  $\mathfrak{K}$ . Let  $a_i$  denote the annihilation operator on  $\mathfrak{F}_s(\mathfrak{K})$  associated with  $\overline{\xi_i}$  (see Appendix A.3).

The new formulation of the quantum theory of our collection of n harmonic oscillators is defined as follows: We choose the Hilbert space to be  $\mathfrak{F}'=\mathfrak{F}_s(\mathfrak{R})$ . We define the Heisenberg position and momentum operators on  $\mathfrak{F}'$  by

$$q'_{iH}(t) = \xi_i(t)a_i + \overline{\xi}_i(t)a_i^{\dagger}$$
 (2.3.18)

$$p'_{iH}(t) = dq'_{iH}/dt$$
 (2.3.19)

As pointed out above, eqs. (2.3.18) and (2.3.19) are equivalent to specifying the Schrodinger position and momentum operators together with a specification of the Hamiltonian, H', up to a (physically irrelevant) multiple of the identity operator. Thus, our construction of the Hilbert space  $\mathfrak{F}'$  together with eqs. (2.3.18)-(2.3.19) define a quantum theory of the system of harmonic oscillators.

Although our construction of  $(\mathfrak{F}';\,q_i',\,p_j',\,H')$  is rather different in appearance from the preceding construction of  $(\mathfrak{F};\,q_i,\,p_j,\,H)$ , it can be readily verified that the two constructions are unitarily equivalent. First, note that from the commutation relations for annihilation and creation operators on Fock space, it may be verified directly that the Schrodinger position and momentum operators determined by this construction satisfy the canonical commutation

{38}------------------------------------------------

relations (2.2.2)-(2.2.3). The unitary equivalence of  $(\mathfrak{F}'; q_i', p_j')$  with  $(\mathfrak{F}; q_i, p_j)$  then follows immediately from the Stone-von Neumann theorem, since it is easily seen that both constructions yield an irreducible representation of the Weyl relations. Since, by eqs. (2.3.10)-(2.3.11) and (2.3.18)-(2.3.19), this unitary correspondence also maps the Heisenberg position and momentum operators into each other, it follows that it must also carry H into H' (up to a multiple of the identity). Indeed, it is easily seen that the unitary correspondence,  $U:\mathfrak{F}\to\mathfrak{F}'$ , of the two constructions is given explicitly by  $U\Psi_0=|0>$ ,  $U\Psi_{1i}=a_i\dagger |0>$ , etc., where |0> denotes the "vacuum vector" of the Fock space.

We now rewrite eqs. (2.3.18) and (2.3.19) in a basis-independent manner as follows. Let  $\overline{\mathfrak{K}}$  denote the complex conjugate space to  $\Re$  (see Appendix A.2). Then  $\overline{\Re}$  may be identified with the subspace of negative frequency (complex) solutions to the classical harmonic oscillator equations of motion. Since  $\Re$  and  $\overline{\Re}$  are ncomplex-dimensional subspaces of  $\mathcal{S}^{\,\mathbb{C}}$  with no nonzero vectors in common, it follows that every  $z \in \mathcal{S}^{\mathbb{C}}$  can be expressed uniquely as z = $z^+ + z^-$ , with  $z^+ \in \mathcal{H}$ ,  $z^- \in \overline{\mathcal{H}}$ . This fact allows us to "project" any vector in & C onto %. In particular, it follows that there exists a reallinear, one-to-one, and onto "projection map" K:  $\& \to \Im$ , defined by the operation of extracting the "positive frequency part" of any real The (basis independent) information correclassical solution. sponding to that contained in eq. (2.3.3) for a single oscillator now can be stated as follows: For each y∈ & the (Schrodinger picture) operator representing the classical observable  $\Omega(y,\cdot)$  (see section 2.1) is given by

$$\widehat{\Omega}(y,\cdot) = ia(\overline{Ky}) - ia^{\dagger}(Ky)$$
 (2.3.20)

where  $a(\overline{Ky})$  denotes the annihilation operator associated with  $Ky \in \Re$  (see Appendix A.3). Equations (2.3.18) and (2.3.19) then can be reexpressed as the statement that the Heisenberg operator at time t corresponding to the Schrodinger operator (2.3.20) is

$$\widehat{\Omega}_{H}(y,\cdot) = ia(\overline{Ky_t}) - ia^{\dagger}(Ky_t)$$
 (2.3.21)

where  $y_t$  denotes the solution whose initial data at time t is the same as the initial data of y at time t=0 (i.e.,  $y_t$  is the "time translate" of y by t).

{39}------------------------------------------------

We turn our attention, now, to the quantum theory of a general, linear, dynamical system, described classically by the Hamiltonian (2.1.11). When H is time-independent, we can decouple the degrees of freedom by a normal mode decomposition and apply our prescription above, so our concern here is in the generalization of the above constructions to the time-dependent case. There is no difficulty whatsoever in straightforwardly applying the standard, Schrodinger quantum mechanical construction of (F; qi, pi, H) to the case of a general linear dynamical system with time-dependent Hamiltonian. However, this will not be useful for our construction of quantum field theory, since, as we remarked above, the tensor product construction (2.3.15) does not generalize suitably to the case of infinitely many degrees of freedom. On the other hand, it is not immediately obvious how to generalize our construction (F'; q'i, p'i, H'), since that construction made essential use of the time translation symmetry present in the classical theory: fails to be time-independent, solutions which oscillate with purely positive frequency (see eq. (2.3.17)) will not exist, so it is not at all clear how to define an analog of the subspace, \$\%, of \$\&\circ\$. It is essential that we reformulate our alternate construction without making use of time translation symmetry if we wish to treat a quantum field in a general, nonstationary, curved spacetime. We now shall proceed to do so.

Let  $(\mathcal{A},\Omega)$  be the symplectic vector space of solutions to the equations of motion of a general, linear classical system with time-dependent Hamiltonian, H, of the form eq. (2.1.11). As in the case of a time-independent Hamiltonian, we complexify  $\mathcal{A}$  and define a (non-positive-definite) inner product on  $\mathcal{A}^{\mathbb{C}}$  by eq. (2.3.16). However, as already noted above, in the case of a time-dependent Hamiltonian, solutions do not oscillate harmonically, and there is no natural, unique analog of the subspace of positive frequency solutions used above. Nevertheless, we can proceed by choosing any subspace,  $\mathfrak{R}$ , of  $\mathcal{A}^{\mathbb{C}}$  which satisfies the following properties:

- (i) The "inner product", eq. (2.3.16), is positive definite on  $\Re$ , thus making  $\Re$  into a Hilbert space over  $\mathbb{C}$ .
- (ii)  $\underline{\mathcal{S}}^{\mathbb{C}}$  is equal to the span of  $\Re$  and its complex conjugate space,  $\overline{\Re}$ .
- (iii) For all  $z^+ \in \mathcal{K}$  and  $z^- \in \overline{\mathcal{K}}$ , we have  $(z^+, z^-) = 0$ .