

{200}------------------------------------------------

# Appendix: Some Basic Definitions and Constructions Pertaining to Hilbert Spaces

The main purpose of this Appendix is to review some basic definitions and constructions relevant to Hilbert spaces and to introduce an index notation, which is very useful for representing operations in Fock space in a basis independent manner. The definition of a C\*-algebra also will be given.

#### A.1 Some Basic Definitions

First, we recall that a vector space, V, over the complex numbers,  $\mathbb{C}$ , is a set on which is defined an operation of "addition" (which is a map  $+: V \times V \to V$ ) and an operation of "scalar multiplication" (which is a map  $\times: \mathbb{C} \times V \to V$ ) such that (1) V is an abelian group with respect to addition, with identity element denoted  $\underline{0}$ . (The bar under  $\underline{0}$  will be dropped when there is no danger of confusion with  $0 \in \mathbb{C}$ .) (2) The scalar multiplication and addition operations satisfy

$$c_{1} \times (c_{2} \times \psi) = (c_{1} c_{2}) \times \psi \qquad (A.1.1)$$

$$C\times(\psi_1+\psi_2) = C\times\psi_1+C\times\psi_2 \tag{A.1.2}$$

$$(c_1 + c_2)x\psi = c_1x\psi + c_2x\psi$$
 (A.1.3)

$$1\times\psi = \psi \tag{A.1.4}$$

for all  $c,c_1,c_2\in\mathbb{C}$  and  $\psi,\psi_1,\psi_2\in V$ . (Hereafter, the "x" generally will be dropped.)

If V and W are vector spaces, a map  $f:V \to W$  is said to be *linear* if  $f(c_1\psi_1+c_2\psi_2)=c_1f(\psi_1)+c_2f(\psi_2)$  for all  $c_1,c_2\in \mathbb{C}$  and  $\psi_1,\psi_2\in V$ . Similarly, f is said to be *antilinear* if  $f(c_1\psi_1+c_2\psi_2)=\overline{c}_1f(\psi_1)+\overline{c}_2f(\psi_2)$ , where the bar denotes complex conjugation on  $\mathbb{C}$ .

A normed vector space consists of a vector space, V, together with a map  $|| \ || \ || \ V \rightarrow \mathbb{C}$  (called a *norm*) satisfying

{201}------------------------------------------------

$$||c\psi|| = |c| ||\psi|| \tag{A.1.5}$$

$$||\psi_1 + \psi_2|| \le ||\psi_1|| + ||\psi_2||$$
 (A.1.6)

for all  $c \in \mathbb{C}$  and  $\psi, \psi_1, \psi_2 \in V$ . If V, W are normed vector spaces, a map  $f: V \to W$  is said to be bounded if there exists  $C \in \mathbb{R}$  such that  $||f(\psi)||_W \le C||\psi||_V$  for all  $\psi \in V$ .

An inner product on a vector space V is a map < , > : V×V  $\rightarrow \mathbb{C}$  which is linear in its second argument and satisfies  $\langle \overline{\psi_1}, \overline{\psi_2} \rangle = \langle \psi_2, \psi_1 \rangle$  for all  $\psi_1, \psi_2 \in V$  (so that < , > is antilinear in its first argument) and  $\langle \psi, \psi \rangle > 0$  for all  $\psi \neq 0$ . If < , > is an inner product on V, then an associated norm on V can be defined by  $||\psi|| = (\langle \psi, \psi \rangle)^{1/2}$ .

If V is a normed vector space, a sequence  $\{\psi_n\}$  of elements of V is said to be a *Cauchy sequence* if given  $\epsilon > 0$  there exists  $N \in \mathbb{Z}$  such that  $||\psi_n - \psi_m|| < \epsilon$  for all n,m > N. If every Cauchy sequence in V converges then V is said to be *complete* and V is called a *Banach space*. An inner product space which is complete in the associated norm defined above is called a *Hilbert space*.

If V is an inner product space which is not necessarily complete, we can construct the metric space completion,  $\Re$ , of V by taking equivalence classes of Cauchy sequences in V (see, e.g., Reed and Simon (1980)). The inner product space structure of V naturally extends to  $\Re$  in such a way as to provide  $\Re$  with the structure of a Hilbert space, with V naturally identified with a dense subspace of  $\Re$ .  $\Re$  is called the *Hilbert space completion* of V.

An algebra,  $\mathcal{A}$ , over  $\mathbb C$  is a vector space over  $\mathbb C$  with an additional "multiplication map"  $\mathcal{A} \times \mathcal{A} \to \mathcal{A}$  which is bilinear (i.e., linear in each variable) and satisfies the associative law. We will denote the action of this map on  $(A_1,A_2) \in \mathcal{A} \times \mathcal{A}$  by  $A_1A_2$ , so the associative law can be expressed as  $A_1(A_2A_3) = (A_1A_2)A_3$ . An element  $I \in \mathcal{A}$  will be said to be an identity element of  $\mathcal{A}$  if AI = IA = A for all  $A \in \mathcal{A}$ .

An algebra,  $\mathcal{A}$ , will be said to be a \*-algebra if it possesses an antilinear map \*: $\mathcal{A} \to \mathcal{A}$  satisfying A\*\*= A and  $(A_1A_2)^* = A_2^*A_1^*$  for all  $A,A_1,A_2 \in \mathcal{A}$ .

An algebra,  $\mathcal{A}$ , will be called a *normed algebra* if it possesses a vector space norm,  $||\ ||\ |$  (defined above) which, in addition, satisfies  $||A_1A_2|| \le ||A_1|| ||A_2||$  for all  $A_1, A_2 \in \mathcal{A}$ . A normed algebra which also is complete is called a *Banach algebra*.

If an algebra A has the structure of both a \*-algebra and a

{202}------------------------------------------------

Banach algebra and if, in addition, we have  $||A^*|| = ||A||$  for all  $A \in \mathcal{A}$ , then  $\mathcal{A}$  is called a *Banach \*-algebra*. Finally, a  $C^*$ -algebra  $\mathcal{A}$ , is a Banach \*-algebra which also satisfies  $||A^*A|| = ||A||^2$  for all  $A \in \mathcal{A}$ .

### A.2 Some Basic Constructions

Let  $(V,+,\times)$  denote a set, V, together with an "addition map", +, and "scalar multiplication map",  $\times$ , which satisfy the vector space axioms given above. Define a new "scalar multiplication map"  $\overline{\times}: \mathbb{C} \times V \to V$  by

$$C \overline{x} \Psi = \overline{C} x \Psi$$
 (A.2.1)

Then it is easily checked that  $(V,+,\bar{x})$  also satisfies the vector space axioms. The resulting vector space is called the *complex conjugate space* to the original vector space. If the original vector space is denoted simply as V, the complex conjugate space usually is denoted as  $\overline{V}$ . (Note, however, that the notation is potentially confusing since the two vector spaces differ in their scalar multiplication maps rather than their underlying sets. Note, also, that the natural one-to-one, onto correspondence between V and  $\overline{V}$ —resulting from their being constructed from the same underlying set—is antilinear.) If  $\psi \in V$ , we denote the vector in  $\overline{V}$  associated with  $\psi$  via this correspondence by  $\overline{\psi}$ . If  $A:V \to W$  is a linear map, we denote by  $\overline{A}$  the corresponding linear map from  $\overline{V}$  to  $\overline{W}$ . Finally, if <, > is an inner product on  $\overline{V}$ , then an inner product on  $\overline{V}$  can be defined by

$$\langle \overline{\psi}_1, \overline{\psi}_2 \rangle = \langle \psi_2, \psi_1 \rangle_V$$
 (A.2.2)

Let V be a normed vector space. The *dual space* to V—denoted as  $V^*$ —is defined as the set of all bounded linear maps from V into  $\mathbb{C}$ . The natural notion of addition and scalar multiplication of linear maps gives  $V^*$  a natural vector space structure.

Now, let  $\Re$  be a Hilbert space. A key result in the theory of Hilbert spaces is the Riesz lemma (see, e.g., Reed and Simon (1980)), which states that every element of  $\Re$  can be uniquely expressed in the form  $<\psi$ ,  $\cdot$  for some  $\psi\in\Re$ , i.e. every bounded linear map from  $\Re$  into  $\mathbb C$  is of the form of "take the inner product with some fixed vector in  $\Re$ ." The Riesz lemma thereby provides a one-to-one, onto, antilinear correspondence between  $\Re$  and  $\Re$  . Consequently, we obtain a natural isomorphism (i.e., a one-to-one, onto, linear map)

{203}------------------------------------------------

between  $\Re$  \* and the complex conjugate space  $\overline{\Re}$ . Similarly,  $\Re$  and  $\overline{\Re}$  \* are naturally isomorphic. The Riesz lemma also guarantees that if  $A:\Re_1 \to \Re_2$  is a bounded linear map between Hilbert spaces  $\Re_1$  and  $\Re_2$ , then there exists a bounded linear map  $A^{\dagger}:\Re_2 \to \Re_1$ , called the adjoint of A, such that

$$\langle \psi_2, A\psi_1 \rangle_2 = \langle A^{\dagger}\psi_2, \psi_1 \rangle_1$$
 (A.2.3)

for all  $\psi_1 \in \mathcal{H}_1$ ,  $\psi_2 \in \mathcal{H}_2$ .

Next, we define the direct sum of Hilbert spaces. Let  $\{\mathfrak{K}_{\alpha}\}$  be an arbitrary collection of Hilbert spaces, indexed by  $\alpha$ . (We will be interested only with the case where there are at most a countable number of Hilbert spaces, but no such restriction need be made for this construction.) The elements of the Cartesian product,  $\overset{\vee}{\alpha}$   $\mathfrak{K}_{\alpha}$ , consist of collections of vectors  $\{\psi_{\alpha}\}$  with each  $\psi_{\alpha} \in \mathfrak{K}_{\alpha}$ . Consider, now, the subset,  $V \subset \overset{\vee}{\alpha} \mathfrak{K}_{\alpha}$ , composed of elements for which all but finitely many of the  $\psi_{\alpha}$  vanish. Then V has the natural structure of an inner product space. We define the *direct sum Hilbert space*—denoted  $\overset{\oplus}{\alpha} \mathfrak{K}_{\alpha}$ —to be the Hilbert space completion of V. It follows that in the case of a countably infinite collection of Hilbert spaces  $\{\mathfrak{K}_i\}$ , each  $\Psi \in \overset{\oplus}{\mathfrak{K}}_i$  consists of arbitrary sequences  $\{\psi_i\}$  such that each  $\psi_i \in \mathfrak{K}_i$  and  $\sum ||\psi_i||_i^2 < \infty$ .

The tensor product,  $\Re_1 \otimes \Re_2$ , of two Hilbert spaces,  $\Re_1$  and  $\Re_2$ , may be defined as follows. Let V denote the set of linear maps  $A:\overline{\Re}_1 \rightarrow \Re_2$  which have finite rank, i.e., such that the range of A is a finite dimensional subspace of  $\Re_2$ . Then V has a natural vector space structure. Define an inner product on V by

$$\langle A,B\rangle_V = tr(A^{\dagger}B)$$
 (A.2.4)

(The right side of eq. (A.2.4) is well defined, since  $A^{\dagger}B:\overline{\mathbb{X}}_{1}\to\overline{\mathbb{X}}_{1}$  has finite rank.) We define  $\mathfrak{X}_{1}\otimes\mathfrak{X}_{2}$  to be the Hilbert space completion of V. It follows that  $\mathfrak{X}_{1}\otimes\mathfrak{X}_{2}$  consists of all linear maps,  $A:\overline{\mathbb{X}}_{1}\to\mathfrak{X}_{2}$ , which satisfy the Hilbert-Schmidt condition, tr  $A^{\dagger}A<\infty$ . Equivalently, by the Riesz lemma,  $\mathfrak{X}_{1}\otimes\mathfrak{X}_{2}$  consists of all bilinear maps  $\alpha:\overline{\mathfrak{X}}_{1}\times\overline{\mathfrak{X}}_{2}\to\mathbb{C}$  such that

$$\sum_{i \mid i} |\alpha(\overline{e}_{1i}, \overline{e}_{2j})|^2 < \infty \tag{A.2.5}$$

{204}------------------------------------------------

where  $\{\overline{e}_{1i}\}$  and  $\{\overline{e}_{2i}\}$  are orthonormal bases of  $\overline{\mathfrak{X}}_1$  and  $\overline{\mathfrak{X}}_2$ , respectively.

By induction, the above construction can be extended to define the tensor product,  $\Re_1 \otimes \cdots \otimes \Re_n$ , of finitely many Hilbert spaces,  $\Re_1, ..., \Re_n$ . It follows that  $\Re_1 \otimes ... \otimes \Re_n$  consists of all multilinear maps  $\alpha: \overline{\mathcal{H}}_1 \times \cdots \times \overline{\mathcal{H}}_n \to \mathbb{C}$  satisfying

$$\sum |\alpha(\overline{e}_{1i_1},...,\overline{e}_{ni_n})|^2 < \infty$$
 (A.2.6)

If  $\Re_1 = \Re_2 = \cdots = \Re_n = \Re$ , we define the symmetrized tensor product denoted  $\overset{"}{\otimes}_s \mathcal{H}$ —to be the subspace of the n-fold tensor product space,  $\stackrel{n}{\otimes}$  %, consisting of the maps,  $\alpha$ , which are totally symmetric in the n-The antisymmetrized tensor product—denoted  $\overset{\circ}{\otimes}_a \mathfrak{R}$ —is defined similarly. A notion of tensor product applicable to infinitely many Hilbert spaces has been given by von Neumann (1938).

An important application of the above direct sum and tensor product constructions is the definition of Fock spaces. Let % be a Hilbert space. Then the Fock space associated with % is defined to be the Hilbert space

$$\mathfrak{F}(\mathfrak{K}) = \bigoplus_{n=0}^{\infty} (\stackrel{n}{\otimes} \mathfrak{K})$$
 (A.2.7)

where we define  $\overset{0}{\otimes} \mathfrak{H} = \mathbb{C}$ . The symmetric Fock space,  $\mathfrak{F}_{s}(\mathfrak{H})$ , and antisymmetric Fock space,  $\mathfrak{F}_{a}(\mathfrak{K})$ , associated with  $\mathfrak{K}$  are defined by

$$\mathfrak{F}_{s}(\mathfrak{K}) = \bigoplus_{n=0}^{\infty} (\overset{n}{\otimes}_{s} \mathfrak{K})$$
 (A.2.8)

$$\mathfrak{F}_{s}(\mathfrak{H}) = \bigoplus_{n=0}^{\infty} (\bigotimes_{s}^{n} \mathfrak{H})$$

$$\mathfrak{F}_{a}(\mathfrak{H}) = \bigoplus_{n=0}^{\infty} (\bigotimes_{a}^{n} \mathfrak{H})$$
(A.2.8)

### A.3 Index Notation

In analyses involving tensors over a finite dimensional vector space, it is very useful at times to employ an abstract index notation. The same is true for analyses involving tensors over an infinite dimensional Hilbert space (Geroch, unpublished) and the purpose of this section is to introduce this notation. It is assumed that the reader is familiar with the abstract index notation in the 

{205}------------------------------------------------

finite dimensional case (see, e.g., Wald (1984a)).

Given a Hilbert space  $\Re$ , we can construct the associated Hilbert spaces  $\overline{\Re}$ ,  $\Re^*$ , and  $\overline{\Re}^*$  as in the previous section. In analogy with the index notation commonly employed for spinors (see, e.g., Wald (1984a)), it is natural to use an index notation wherein elements of  $\Re$  are denoted as  $\psi^a$ , elements of  $\overline{\Re}$  are denoted as  $\phi^a$ , elements of  $\overline{\Re}^*$  are denoted as  $\phi^a$ , elements of  $\overline{\Re}^*$  are denoted as  $\phi^a$ , and elements of  $\overline{\Re}^*$  are denoted as  $\phi^a$ , with  $\phi^a$  are as noted above, using the Riesz lemma, we may identify  $\overline{\Re}$  with  $\phi^a$  and we may identify  $\phi^a$  with  $\overline{\Re}^*$ . We shall make these identifications, and thereby eliminate the need for the introduction of primed indices. Thus, in particular, if  $\phi^a \in \Re$ , we shall denote the corresponding element of  $\overline{\Re}$  as  $\overline{\psi}_a$ .

In analogy with the finite dimensional case, an element  $\psi \in \stackrel{n}{\otimes} \mathfrak{R}$  will be denoted as  $\psi^{a_1 \cdots a_n}$ . The subspace  $\stackrel{n}{\otimes}_{s} \mathfrak{R}$  then consists of those elements satisfying

$$\psi^{a_1...a_n} = \psi^{(a_1...a_n)} \tag{A.3.1}$$

where the round brackets denote symmetrization. An element  $\phi \in \mathfrak{B}^n$  will be denoted as  $\phi_{a_1 \cdots a_n}$ . Similarly, if, for example,  $\chi \in \mathfrak{R} \otimes \mathfrak{R}^*$ , then  $\chi$  will be denoted as  $\chi^a{}_b$ . Outer products and contractions of tensors over  $\mathfrak{R}$  are denoted as in the finite dimensional case. Thus, in particular, the inner product of vectors  $\phi, \psi \in \mathfrak{R}$  may be denoted as

$$\langle \phi, \psi \rangle = \overline{\phi}_a \psi^a$$
 (A.3.2)

It should be noted that in the finite dimensional case,  $\Re \Re \Re$  is isomorphic to the space of linear maps from  $\Re$  into  $\Re$ , so in that case any linear map  $A:\Re \to \Re$  can be represented in the index notation as  $A^a{}_b$ . However, in the infinite dimensional case, only the Hilbert-Schmidt linear maps (satisfying  $tr A^\dagger A < \infty$ ) define tensors, so index notation will be used only for such Hilbert-Schmidt maps.

An important difference occurring in the infinite dimensional case is that contractions over an upper and lower index involve infinite sums and thus need not always exist. In particular, even if  $A: \mathfrak{R} \to \mathfrak{R}$  is Hilbert-Schmidt—and thus defines a tensor,  $A^a{}_b$ —its trace need not exist. However, the condition (A.2.6) guarantees that compositions of tensors—i.e., contractions over upper and lower indices occurring on different tensors—always is well defined. Thus, for example, although  $A^a{}_a$  need not exist, a contraction of the

{206}------------------------------------------------

form  $A^a{}_{bc}B^{bd}$  or  $A^a{}_{bc}B^{bc}$  always is well defined for any  $A \in \mathcal{H} \otimes \mathcal{H}^* \otimes \mathcal{H}^*$ ,  $B \in \mathcal{H} \otimes \mathcal{H}$ .

We conclude this Appendix by giving the general definition of annihilation and creation operators on a symmetric Fock space, thereby providing a good illustration of the use of the index notation. Let  $\mathfrak R$  be a Hilbert space and let  $\mathfrak F_s(\mathfrak R)$  be its associated symmetric Fock space, as defined at the end of the previous section. In the index notation, a vector  $\Psi \in \mathfrak F_s(\mathfrak R)$  can be represented as

$$\Psi = (\psi, \psi^{a_1}, \psi^{a_1 a_2}, \dots, \psi^{a_1 \dots a_n}, \dots)$$
 (A.3.3)

where, for all n, we have  $\psi^{a_1...a_n} = \psi^{(a_1...a_n)}$ . Now, let  $\xi^a \in \mathfrak{X}$  and let  $\overline{\xi}_a$  denote the corresponding element of  $\overline{\mathfrak{X}}$ . The annihilation operator  $a(\overline{\xi}): \mathfrak{F}_s(\mathfrak{X}) \to \mathfrak{F}_s(\mathfrak{X})$  associated with  $\overline{\xi}$  is defined by

$$a(\overline{\xi})\Psi = (\overline{\xi}_a \psi^a, \sqrt{2} \overline{\xi}_a \psi^{aa_1}, \sqrt{3} \overline{\xi}_a \psi^{aa_1a_2}, \dots)$$
 (A.3.4)

(Note that we chose to view the annihilation operator as a function of vectors in  $\overline{\mathfrak{R}}$  rather than  $\mathfrak{R}$  in order to make its dependence upon these vectors be linear rather than antilinear. Note also that we dropped the index on  $\overline{\xi}_a$  when writing  $a(\overline{\xi})$  since its presence in that expression could cause confusion.) Similarly, the creation operator  $a^{\dagger}(\xi):\mathfrak{F}_s(\mathfrak{R})\to\mathfrak{F}_s(\mathfrak{R})$  associated with  $\xi^a$  is defined by

$$a^{\dagger}(\xi)\Psi = (0, \psi \xi^{a_1}, \sqrt{2} \xi^{(a_1}\psi^{a_2}), \sqrt{3} \xi^{(a_1}\psi^{a_2a_3}), \dots) \tag{A.3.5}$$

If the domains of  $a(\bar{\xi})$  and  $a^{\dagger}(\xi)$  are defined to be the subspaces of  $\mathfrak{F}_s(\mathfrak{R})$  such that the norms of the right sides of eqs. (A.3.4) and (A.3.5), respectively, are finite, then it may be verified that  $a^{\dagger}(\xi)$  is, indeed, the adjoint of  $a(\bar{\xi})$  (see, e.g., Reed and Simon (1980) for the definition of the adjoint of an unbounded operator). It also may be readily verified that  $a(\bar{\xi})$  and  $a^{\dagger}(\eta)$  satisfy the commutation relation,

$$[a(\overline{\xi}),a^{\dagger}(\eta)] = \overline{\xi}_a \eta^a I \tag{A.3.6}$$

{207}------------------------------------------------

## References

- Allen, B. (1985), "Vacuum States in deSitter Space", Phys. Rev. D32, 3136.
- Arnold, V.I. (1989), *Mathematical Methods of Classical Mechanics* (Springer-Verlag, New York).
- Ashtekar, A. (1991), Lectures on Non-Perturbative Canonical Gravity (World Scientific Press, Singapore).
- Ashtekar, A., and Magnon, A. (1975), "Quantum Fields in Curved Space-Times", Proc. Roy. Soc. Lond. **A346**, 375.
- Banks, T. Susskind, L., and Peskin, M.E. (1984), "Difficulties for the Evolution of Pure States into Mixed States", Nucl. Phys. **B244**, 125.
- Bardeen, J.M., Carter, B., and Hawking, S.W. (1973), "The Four Laws of Black Hole Mechanics", Commun. Math. Phys. **31**, 161.
- Bekenstein, J.D. (1974), "Generalized Second Law of Thermodynamics in Black Hole Physics", Phys. Rev. **D9**, 3292.
- Bekenstein, J.D. (1981), "Universal Upper Bound on the Entropy-to-Energy Ratio for Bounded Systems", Phys. Rev. **D23**, 287.
- Bombelli, L., Koul, R.K., Lee, J., and Sorkin, R.D.(1986), "Quantum Source of Entropy for Black Holes", Phys. Rev. **D34**, 373.
- Birrell, N.D., and Davies, P.C.W. (1982), *Quantum Fields in Curved Space* (Cambridge University Press, Cambridge)
- Bisognano, J.J., and Wichmann, E.H. (1976), "On the Duality Condition for Quantum Fields", J. Math. Phys. 17, 303.
- Braden, H.W., Whiting, B.F., and York, J.W. (1987), "Density of States for the Gravitational Field in Black Hole Topologies", Phys. Rev. **D36**, 3614.
- Bratteli, O., and Robinson, D.W. (1981) *Operator Algebras and Quantum Statistical Mechanics II* (Springer-Verlag, New York).
- Brown, J.D., Comer, G.L., Martinez, E.A., Melmed, J., Whiting, B.F., and York, J.W. (1990), "Thermodynamic Ensembles and Gravitation", Class. Quantum Grav. 7, 1433.
- Brown, J.D., and York, J.W. (1993a), "Quasilocal Energy and Conserved Charges Derived from the Gravitational Action", Phys. Rev. **D47**, 1407.
- Brown, J.D., and York, J.W. (1993b), "Microcanonical Functional Integral for the Gravitational Field", Phys. Rev. **D47**, 1420.
- Callen, C.G., Giddings, S.B, Harvey, J.A., and Strominger, A. (1992), "Evanescent Black Holes", Phys. Rev. **D45**, 1005.
- Chernoff, P.R. (1981), "Mathematical Obstructions to Quantization", Hadronic Journal 4, 879.
- Chmielowski, P. (1994), "States of a Scalar Field on Spacetimes with Two Isometries with Timelike Orbits", Class. Quant. Grav. 11, 41.
- Christodoulou, D. (1994), "Examples of Naked Singularity Formation in the Gravitational Collapse of a Scalar Field", Ann. Math. (in press).

{208}------------------------------------------------

- DeWitt, B.S. (1975), "Quantum Field Theory in Curved Spacetime", Phys. Rep. 19, 295.
- Dieckmann, J. (1988), "Cauchy Surfaces in Globally Hyperbolic Spacetimes", J. Math. Phys. **29**, 578.
- Dimock, J. (1980), "Algebras of Local Observables on a Manifold", Commun. Math. Phys. 77, 219.
- Dimock, J. (1982), "Dirac Quantum Fields on a Manifold", Trans. Amer. Math. Soc. **269**, 133.
- Dimock, J. (1985), "Scattering for the Wave Equation on the Schwarzschild Metric", Gen. Rel. and Grav. 17, 353.
- Dimock, J. (1992), "Quantized Electromagnetic Field on a Manifold", Rev. Math. Phys. 4, 223.
- Dimock, J., and Kay, B.S. (1987), "Classical and Quantum Scattering Theory for Linear Scalar Fields on the Schwarzschild Metric. I", Ann. Phys. 175, 366.
- Fell, J.M. (1960), "The Dual Spaces of C\*-Algebras", Trans. Am. Math. Soc. 94, 365.
- Fredenhagen, K., and Haag, R. (1990), "On the Derivation of the Hawking Radiation Associated with the Formation of a Black Hole", Commun. Math. Phys. **127**, 273.
- Frolov, V.P. (1992), "Two-Dimensional Black Hole Physics", Phys. Rev. **D46**, 5383.
- Frolov, V.P., and Page, D.N. (1993), "Proof of the Generalized Second Law for Quasistationary Semiclassical Black Holes", Phys. Rev. Lett. **71**, 3902.
- Fulling, S.A. (1973), "Nonuniqueness of Canonical Field Quantization in Riemannian Space-Time", Phys Rev. **D7**, 2850.
- Fulling, S.A. (1989), Aspects of Quantum Field Theory in Curved Spacetime (Cambridge University Press, Cambridge).
- Fulling, S.A., Narcowich, F., and Wald, R.M. (1981), "Singularity Structure of the Two-Point Function in Quantum Field Theory in Curved Spacetime. II", Ann. Phys. **136**, 243.
- Fulling, S.A., and Ruijsenaars (1987), "Temperature, Periodicity, and Horizons", Phys. Rep. **152**, 135.
- Fulling, S.A., Sweeny, M., and Wald, R.M. (1978), "Singularity Structure of the Two-Point Function in Quantum Field Theory in Curved Spacetime", Commun. Math. Phys. **63**, 257.
- Garabedian, P.R. (1964), Partial Differential Equations (Wiley, New York).
- Geroch, R. (1970), "Domain of Dependence", J. Math. Phys. 11, 437.
- Gibbons, G.W., and Hawking, S.W. (1977a), "Cosmological Event Horizons, Thermodynamics, and Particle Creation", Phys. Rev. **D15**, 2738.
- Gibbons, G.W., and Hawking, S.W. (1977b), "Action Integrals and Partitiion Functions in Quantum Gravity", Phys. Rev. **D15**, 2752.
- Gibbons, G.W., and Perry, M.J. (1978), "Black Holes and Thermal Green's Functions", Proc. Roy. Soc. Lond. **A358**, 467.
- Gotay, M.J. (1980), "Functorial Geometric Quantization and Van Hove's Theorem", Int. J. Theor. Phys. **19**, 139.
- Haag, R. (1992), Local Quantum Physics (Springer-Verlag, Berlin).
- Haag, R., and Kastler, D. (1964), "An Algebraic Approach to Quantum Field Theory", J. Math. Phys. 5, 848.

{209}------------------------------------------------

- Hadamard, J. (1923), Lectures on Cauchy's Problem in Linear Partial Differential Equations (Yale University Press, New Haven).
- Hartle, J.B., and Hawking, S.W. (1976), "Path-Integral Derivation of Black Hole Radiance", Phys. Rev. **D13**, 2188.
- Hawking, S. (1971), "Gravitational Radiation From Colliding Black Holes", Phys. Rev. Lett. **26**, 1344.
- Hawking, S.W. (1975), "Particle Creation by Black Holes", Commun. Math. Phys. 43, 199.
- Hawking, S.W. (1976), "Breakdown of Predictability in Gravitational Collapse", Phys. Rev. **D14**, 2460.
- Hawking, S.W., and Ellis. G.F.R. (1973), *The Large Scale Structure of Space-Time* (Cambridge University Press, Cambridge).
- Hawking, S.W., and Hartle, J. (1972), "Energy and Angular Momentum Flow into a Black Hole", Commun. Math. Phys. 27, 283.
- Huang, K. (1963), Statistical Mechanics (Wiley, New York).
- Isham, C.J. (1984), "Topological and Global Aspects of Quantum Theory", in *Relativity, Groups, and Topology II*, ed. B.S. DeWitt and R. Stora (North-Holland, Amsterdam).
- Israel, W. (1976), "Thermo-Field Dynamics of Black Holes", Phys. Lett. **57A**, 107.
- Israel, W. (1986), "Third Law of Black Hole Dynamics: A Formulation and Proof", Phys. Rev. Lett. **57**, 397.
- Iyer, V. and Wald, R.M. (1994), "Some Properties of Noether Charge and a Proposal for Dynamical Black Hole Entropy", Phys. Rev. D (in press).
- Jacobson, T.A. (1993), "Black Hole Radiation in the Presence of a Short Distance Cutoff", Phys. Rev. **D48**, 728.
- Jacobson, T.A., and Kang, G. (1993), "Conformal Invariance of Black Hole Temperature", Class. Quant. Grav. 10, L1.
- Kay, B.S. (1978), "Linear Spin-Zero Quantum Fields in External Gravitational and Scalar Fields", Commun. Math. Phys. **62**, 55.
- Kay, B.S. (1985), "The Double-Wedge Algebra for Quantum Fields on Schwarzschild and Minkowski Spacetimes", Commun. Math. Phys. **100**, 57.
- Kay, B.S. (1988), "Quantum Field Theory in Curved Spacetime", in *Differential Geometrical Methods in Theoretical Physics*, ed. K. Bleuler and M. Werner (Reidel, Dordrecht).
- Kay, B.S. (1992), "The Principle of Locality and Quantum Field Theory on (Non Globally Hyperbolic) Curved Spacetimes", Reviews in Mathematical Physics (Special Issue), 167.
- Kay, B.S. (1993), "Sufficient Conditions for Quasifree States and an Improved Uniqueness Theorem for Quantum Fields on Spacetimes with Horizons", J. Math. Phys. 34, 4519.
- Kay, B.S., and Wald, R.M. (1991), "Theorems on the Uniqueness and Thermal Properties of Stationary, Nonsingular, Quasifree States on Spacetimes with a Bifurcate Killing Horizon", Phys. Rep. **207**, 49.
- Lansford, O.E. (1971), "Selected Topics in Functional Analysis", in *Statistical Mechanics and Quantum Field Theory*, ed. C. DeWitt and R. Stora (Gordon and Breach, New York).
- Lee, J., and Wald, R.M. (1990), "Local Symmetries and Constraints", J. Math. Phys. **31**, 725.