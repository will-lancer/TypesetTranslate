Robert M. Wald
Quantum Field Theory in Curved Spacetime and Black Hole Thermodynamics

CONTENTS

wald-qft-jhep.pdf: the revised 159-page reading copy.
wald-qft-source.pdf: all 218 scanned pages, with chapter bookmarks.
typeset/wald.tex: the complete editable LaTeX document.
typeset/figures/: seven diagrams drawn in TikZ.
typeset/jheppub.sty: the JHEP style used for this edition.
ocr/: the original OCR text, retained for reference.
source-metadata.json: source-file metadata.
review-checks.json: build and navigation checks for the revised PDF.

NOTATION AND NAVIGATION

The reading copy uses calligraphic H for one-particle Hilbert spaces and
calligraphic F for Fock spaces. Configuration space is calligraphic Q;
phase space is calligraphic M. Vectors use bold Latin letters and gradients
use an ordinary nabla. Bra-ket notation uses angle delimiters. Trace and
exponential functions use upright operators; in/out subscripts are upright.
Simple pairs, commutators, and inner products use ordinary-size delimiters.
Automatic sizing is retained for tall expressions. Equation-reference numbers
are blue and clickable, while their surrounding parentheses remain black.

Least upper bounds are written as suprema. Equation (5.1.26) uses a sum over
modes, consistent with the two-particle tensor defined by (5.1.24)-(5.1.25).
Equation (4.7.2) uses an absolute square for its complex-valued numerator.
Canonical momenta are differentiated with respect to the velocity of the
field, consistently with the Lagrangian notation used in this edition.

The contents and equation, section, and figure references are clickable.
General-index page numbers point to the corresponding source-page anchors
inside the reading copy. Abbreviated page ranges have been expanded.

REVIEW

The book-wide pass reviewed the displayed equations and repaired OCR damage
in the prose, including missing operators, tensor indices, the evaporation
time, and the appendix's definitions of dual and conjugate spaces.
Thirty-nine scan pages were rendered for targeted comparisons during this
pass, in addition to the earlier checks of the requested passages.

All seven TikZ figures were compared with their scanned originals and
inspected in the rendered reading copy. Figure 5.1 now uses hyperbolic
Killing orbits within their wedges. Figure 7.2 has a clearer M=0 annotation.

The typography revision also checked pages 21-23 and representative equations
from the later chapters. The gap after i in (2.3.7) has been removed.

Page contact sheets were inspected across the book, with detailed rendering
of selected equations, all figures, and the revised indexes. The final build
has 356 unique equation labels, 210 source-page anchors, and 1,229 internal
links with valid destinations. It reports no overfull boxes, undefined
references, missing characters, or font warnings.

This is a reviewed OCR edition. The pass does not constitute a word-for-word
collation or an independent verification of every proof. The original scan
is included for reference.

REBUILDING

From the typeset directory, run:

    xelatex -interaction=nonstopmode -halt-on-error wald.tex
    xelatex -interaction=nonstopmode -halt-on-error wald.tex

A current TeX Live installation with Latin Modern fonts, TikZ, fontspec,
mathtools, multicol, and the other packages named in the preamble is required.

The source material is copyright 1994 by The University of Chicago.
