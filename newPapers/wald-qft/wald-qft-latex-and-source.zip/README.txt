Robert M. Wald
Quantum Field Theory in Curved Spacetime and Black Hole Thermodynamics

CONTENTS

wald-qft-jhep.pdf: the 154-page reading edition.
wald-qft-source.pdf: the 218-page original scan, with chapter bookmarks.
typeset/wald.tex: editable LaTeX source.
typeset/figures/: seven TikZ diagrams.
typeset/jheppub.sty: the JHEP style used for this edition.
ocr/: original OCR text.
source-metadata.json: source-file metadata.
review-checks.json: checks for the current PDF.

NOTATION AND NAVIGATION

One-particle Hilbert spaces use calligraphic H; Fock spaces use calligraphic F.
Vectors use bold Latin letters, with an ordinary nabla for gradients.
Trace and exponential functions are upright operators. In/out subscripts
are upright. Simple pairs and commutators use ordinary-size delimiters.
Equation-reference numbers are clickable and blue, with black parentheses.
Contents, section, and figure references are clickable. General-index page
numbers link to the corresponding source-page locations in this edition.
Source-page markers preserve continuous prose.

Least upper bounds use sup. Equation (5.1.26) sums over modes, consistent
with the two-particle tensor defined by (5.1.24)-(5.1.25). Equation (4.7.2)
uses an absolute square for its complex-valued numerator. The partial trace
following (5.1.27) is over the region-II Fock space. Canonical momenta are
differentiated with respect to the field velocity.

REVIEW

The displayed equations have been checked for transcription and notation
consistency across all chapters and the appendix. Targeted comparisons with
the scan address damaged formulas and incomplete prose. All seven diagrams
have been inspected in the rendered edition and compared with the scan.
The current checks include rendered pages around the corrected passages,
all figure pages, equation numbering, and internal links.

This pass does not constitute a word-for-word collation or independent
verification of every proof. The original scan remains available in this
bundle for reference.

REBUILDING

From the typeset directory, run:

    latexmk -xelatex wald.tex

Alternatively, run xelatex -interaction=nonstopmode -halt-on-error wald.tex
until cross-references stabilize. Keep jheppub.sty and figures/ beside the
source. The required packages and Latin Modern fonts are named in the preamble.

The source material is copyright 1994 by The University of Chicago.
